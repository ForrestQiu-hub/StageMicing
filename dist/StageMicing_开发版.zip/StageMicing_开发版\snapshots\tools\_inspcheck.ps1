# Hard regression check for the scrollable right inspector AND the 01 项目信息 page.
#
# Reads the --dump audit block (lines "insp panel ..." / "p1 panel ...",
# "fld <name> lab .. box .. edt .. win .. rgn .. vis ..") and proves, per field:
#   * the native EDIT sits at EXACTLY the rect the layout derives from the same
#     FieldBox the painter fills (no label / box / EDIT drift),
#   * a label never overlaps its own box, and never sits on ANOTHER field's box or
#     on a visible EDIT window (that is the "ghosted 1.50 behind KM 184" bug),
#   * a visible EDIT never paints outside the checked panel: either it is fully
#     inside, or its window region clips it to win ∩ panel,
#   * no two visible EDITs overlap each other,
#   * the panel content fits: content height <= panel height (no scrolling needed).
param(
  [string]$Dump,
  [string]$Label = "",
  [string]$Panel = "insp"      # "insp" = right inspector, "p1" = 项目信息 page
)

$fail = New-Object System.Collections.ArrayList
$lines = Get-Content -Path $Dump -Encoding Unicode
$insp = $null
$p1 = $null
$scroll = 0; $content = 0
$flds = New-Object System.Collections.ArrayList
$flown = $null
$cbm = $null

foreach ($ln in $lines) {
    if ($ln -match '^insp panel (-?\d+) (-?\d+) (-?\d+) (-?\d+) scroll (-?\d+) content (-?\d+)') {
        $insp = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
        $scroll = [int]$Matches[5]; $content = [int]$Matches[6]
    }
    elseif ($ln -match '^p1 panel (-?\d+) (-?\d+) (-?\d+) (-?\d+)') {
        $p1 = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
    }
    elseif ($ln -match '^fld (\S+) lab (-?\d+) (-?\d+) (-?\d+) (-?\d+) box (-?\d+) (-?\d+) (-?\d+) (-?\d+) edt (-?\d+) (-?\d+) (-?\d+) (-?\d+) win (-?\d+) (-?\d+) (-?\d+) (-?\d+) rgn (-?\d+) (-?\d+) (-?\d+) (-?\d+) vis (\d+)') {
        $o = [pscustomobject]@{
            name = $Matches[1]
            lab  = @([int]$Matches[2], [int]$Matches[3], [int]$Matches[4], [int]$Matches[5])
            box  = @([int]$Matches[6], [int]$Matches[7], [int]$Matches[8], [int]$Matches[9])
            edt  = @([int]$Matches[10], [int]$Matches[11], [int]$Matches[12], [int]$Matches[13])
            win  = @([int]$Matches[14], [int]$Matches[15], [int]$Matches[16], [int]$Matches[17])
            rgn  = @([int]$Matches[18], [int]$Matches[19], [int]$Matches[20], [int]$Matches[21])
            vis  = [int]$Matches[22]
        }
        [void]$flds.Add($o)
    }
    elseif ($ln -match '^flown row (-?\d+) (-?\d+) (-?\d+) (-?\d+) check (-?\d+) (-?\d+) (-?\d+) (-?\d+)') {
        $flown = [pscustomobject]@{
            row   = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
            check = @([int]$Matches[5], [int]$Matches[6], [int]$Matches[7], [int]$Matches[8])
        }
    }
    elseif ($ln -match '^cbm i title (-?\d+) (-?\d+) (-?\d+) (-?\d+) info (-?\d+) (-?\d+) (-?\d+) (-?\d+)') {
        $cbm = [pscustomobject]@{
            title = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
            info  = @([int]$Matches[5], [int]$Matches[6], [int]$Matches[7], [int]$Matches[8])
        }
    }
}

function Say($msg) { Write-Output $msg }

$panelRect = $insp
if ($Panel -eq "p1") { $panelRect = $p1 }
if ($null -eq $panelRect) { Say "$Label FAIL: no '$Panel panel' line in $Dump"; exit 1 }
if ($flds.Count -eq 0) { Say "$Label FAIL: no 'fld' lines in $Dump"; exit 1 }

function Intersect($a, $b) {
    $l = [math]::Max($a[0], $b[0]); $t = [math]::Max($a[1], $b[1])
    $r = [math]::Min($a[2], $b[2]); $bo = [math]::Min($a[3], $b[3])
    if ($r -le $l -or $bo -le $t) { return $null }
    return @($l, $t, $r, $bo)
}
function Empty2($a) { return ($a[2] -le $a[0] -or $a[3] -le $a[1]) }
function SameRect($a, $b, $tol) {
    return ([math]::Abs($a[0] - $b[0]) -le $tol -and [math]::Abs($a[1] - $b[1]) -le $tol -and
            [math]::Abs($a[2] - $b[2]) -le $tol -and [math]::Abs($a[3] - $b[3]) -le $tol)
}
function Overlap($a, $b) {
    $i = Intersect $a $b
    return ($null -ne $i)
}

$visible = New-Object System.Collections.ArrayList
foreach ($f in $flds) {
    $hasBox = -not (Empty2 $f.box)
    # 1. label above its box, never on top of it
    if ($hasBox -and -not (Empty2 $f.lab)) {
        if ($f.lab[3] -gt $f.box[1]) {
            [void]$fail.Add("$($f.name): label bottom $($f.lab[3]) overlaps box top $($f.box[1])")
        }
    }
    # 2. the EDIT rect lives inside the painted box
    if ($hasBox -and -not (Empty2 $f.edt)) {
        if ($f.edt[0] -lt $f.box[0] -or $f.edt[1] -lt $f.box[1] -or
            $f.edt[2] -gt $f.box[2] -or $f.edt[3] -gt $f.box[3]) {
            [void]$fail.Add("$($f.name): EDIT rect outside the painted box")
        }
    }
    if ($f.vis -eq 1) {
        # 3. the window really is at the layout rect
        if (-not (SameRect $f.win $f.edt 1)) {
            [void]$fail.Add("$($f.name): window [$($f.win -join ',')] != layout EDIT rect [$($f.edt -join ',')]")
        }
        # 4. nothing paints outside the panel: full containment, or clipped by rgn
        $clip = Intersect $f.win $panelRect
        if ($null -eq $clip) {
            [void]$fail.Add("$($f.name): visible EDIT [$($f.win -join ',')] is outside the panel [$($panelRect -join ',')]")
        }
        elseif (Empty2 $f.rgn) {
            if (-not (SameRect $f.win $clip 0)) {
                [void]$fail.Add("$($f.name): unclipped EDIT [$($f.win -join ',')] sticks out of the panel [$($panelRect -join ',')]")
            }
        }
        else {
            $abs = @(($f.rgn[0] + $f.win[0]), ($f.rgn[1] + $f.win[1]),
                     ($f.rgn[2] + $f.win[0]), ($f.rgn[3] + $f.win[1]))
            if (-not (SameRect $abs $clip 1)) {
                [void]$fail.Add("$($f.name): region [$($abs -join ',')] != win∩panel [$($clip -join ',')]")
            }
        }
        [void]$visible.Add($f)
    }
}

# 4b. a field's label or EDIT must never sit on ANOTHER field's box / label: this
#     is exactly the "ghosted 1.50 behind KM 184" overlap
foreach ($a in $flds) {
    if (Empty2 $a.box) { continue }
    foreach ($b in $flds) {
        if ($a.name -eq $b.name) { continue }
        if (-not (Empty2 $b.box) -and (Overlap $a.lab $b.box)) {
            [void]$fail.Add("$($a.name): label [$($a.lab -join ',')] overlaps $($b.name) box [$($b.box -join ',')]")
        }
        if ($b.vis -eq 1 -and (Overlap $a.lab $b.win)) {
            [void]$fail.Add("$($a.name): label [$($a.lab -join ',')] is covered by the $($b.name) EDIT [$($b.win -join ',')]")
        }
        if ($b.vis -eq 1 -and $a.vis -eq 1 -and (Overlap $a.win $b.win)) {
            # reported once, under the alphabetically first name
            if ([string]::CompareOrdinal($a.name, $b.name) -lt 0) {
                [void]$fail.Add("visible EDITs overlap: $($a.name) [$($a.win -join ',')] / $($b.name) [$($b.win -join ',')]")
            }
        }
        if ($b.vis -eq 1 -and (Overlap $a.box $b.win)) {
            [void]$fail.Add("$($a.name): box [$($a.box -join ',')] is covered by the $($b.name) EDIT [$($b.win -join ',')]")
        }
    }
}

# 5. the checked panel must fit its content: no scrolling needed
$panelH = $panelRect[3] - $panelRect[1]
$contentH = $content - $panelRect[1]
if ($Panel -eq "insp" -and $content -gt 0) {
    if ($contentH -gt $panelH) {
        [void]$fail.Add("content height $contentH > panel height $panelH (the inspector needs scrolling)")
    }
    if ($scroll -ne 0) {
        [void]$fail.Add("scroll offset is $scroll, it must be 0 (nothing to scroll)")
    }
}

# 6. the 05 mic panel: the 吊装 checkbox sits on the 名称 row (top of the panel),
#    and the 吊装高度 field, when present, is below that row and inside the panel
if ($null -ne $cbm -and -not (Empty2 $cbm.info)) {
    if ($null -ne $flown -and -not (Empty2 $flown.row)) {
        if ($flown.row[1] -lt $cbm.title[3] - 2) {
            [void]$fail.Add("flown toggle row top $($flown.row[1]) is above the mic title bottom $($cbm.title[3])")
        }
        if ($flown.row[1] -gt $cbm.info[1] + 24) {
            [void]$fail.Add("flown toggle row top $($flown.row[1]) is not on the 名称 row (info top $($cbm.info[1]))")
        }
    }
    $fy = $flds | Where-Object { $_.name -eq 'flyh' }
    if ($fy -and -not (Empty2 $fy.box)) {
        if ($fy.box[3] -gt $panelRect[3] -or $fy.box[1] -lt $panelRect[1]) {
            [void]$fail.Add("flyh field box [$($fy.box -join ',')] is not inside the panel")
        }
        if ($fy.box[1] -lt $cbm.info[3] - 2) {
            [void]$fail.Add("flyh field overlaps the mic info block")
        }
    }
}

$shown = $visible.Count
if ($fail.Count -gt 0) {
    Say "$Label FAIL  panel=$Panel scroll=$scroll content=$content contentH=$contentH panelH=$panelH shown=$shown"
    foreach ($m in $fail) { Say "  - $m" }
    exit 1
}
Say "$Label PASS  panel=$Panel scroll=$scroll contentH=$contentH panelH=$panelH fields=$($flds.Count) shown=$shown"
exit 0
