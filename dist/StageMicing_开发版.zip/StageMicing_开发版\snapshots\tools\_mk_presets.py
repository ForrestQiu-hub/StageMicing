# -*- coding: utf-8 -*-
# One-shot generator: rebuild the four PresetRow tables in src/Presets.cpp from
# the user's own --dump-layout dumps (verbatim rows, dump order).
import io
import re
import sys

ROOT = r"E:\Stage Micing Scene"
SRC = ROOT + r"\src\Presets.cpp"
CATALOG = ROOT + r"\src\Catalog.cpp"

ROWPAT = re.compile(r'^\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                    r'\s*(-?[0-9.]+)\s*\}')

TABLES = [
    ("kEu", r"\tools\_rows_demoEuropeansmproj.txt", "demo1 European.smproj"),
    ("kUs", r"\tools\_rows_demoAmericansmproj.txt", "demo1 American.smproj"),
    ("kEuPiano", r"\tools\_rows_demoEuropeanpianosmproj.txt", "demo1 European+piano.smproj"),
    ("kUsPiano", r"\tools\_rows_demoAmericanpianosmproj.txt", "demo1 American+piano.smproj"),
]

# ------------------------------------------------ catalogue ids (for the check)
cat_text = io.open(CATALOG, encoding="utf-8").read()
known = set()
for m in re.finditer(
        r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"[^"]*"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
        r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}', cat_text):
    known.add(m.group(1))
if not known:
    raise SystemExit("no catalogue rows parsed")

# ------------------------------------------------ read + verify the dumps
rows = {}
for var, path, proj in TABLES:
    text = io.open(ROOT + path, encoding="utf-8").read()
    lines = [ln.rstrip("\r") for ln in text.splitlines()]
    body = [ln for ln in lines if ROWPAT.match(ln)]
    bad = [ln for ln in lines if ln.strip() and not ln.lstrip().startswith("//")
           and not ROWPAT.match(ln)]
    if bad:
        raise SystemExit("unparsed row in %s: %r" % (path, bad[0]))
    ids = [ROWPAT.match(ln).group(1) for ln in body]
    unknown = sorted(set(i for i in ids if i not in known))
    rows[var] = (body, ids, proj, unknown)
    print("%-9s %3d rows  %s  unknown=%s" % (var, len(body), proj, unknown or "none"))
    if unknown:
        raise SystemExit("unknown defId(s) in %s: %s" % (path, unknown))

# ------------------------------------------------ new header comment
HEADER = """// ---------------------------------------------------------------------------
// BUILT-IN ORCHESTRA PRESETS（预设）:
//     三管编制 · 欧式 / 三管编制 · 美式 / 欧式钢协 / 美式钢协
// A preset is a table of players in NORMALISED stage space, so it can be
// instantiated on whatever stage the project has:
//     x = nx * stage.w            y = ny * stage.d
// nx = 0 is the left stage edge, nx = 1 the right one.  ny = 0 is the BACK edge
// and ny = 1 the FRONT (audience) edge, because the app's world y axis grows
// toward the audience: StageView draws cy = oy + y * ppm, so the front edge is
// at the bottom of the screen.
//
// ANGLE CONVENTION — read off dr::Icon and the icon art, and the convention the
// dumps below were written with:
//   * dr::Icon rotates the icon by "angle" degrees about its centre with GDI+
//     RotateTransform, i.e. a POSITIVE angle turns CLOCKWISE on screen;
//   * at angle 0 the icon's "front" (its up axis) points UP the screen, i.e.
//     toward the BACK of the stage: the main-microphone symbol is built with
//     forward = (sin a, -cos a), and the conductor icon's baton points up and
//     to the right at angle 0;
//   * the FRENCH HORN is held with its bell turned away from the conductor, so a
//     horn row carries the facing angle + 180 degrees and the bell faces the
//     audience.
//
// THE FOUR TABLES ARE THE USER'S OWN PLACEMENTS.  Each one was dumped from one
// of their saved projects with the --dump-layout hook and pasted back VERBATIM,
// in the order the dump wrote it (defId, then y, then x):
//     三管编制 · 欧式   demo1 European.smproj          86 rows
//     三管编制 · 美式   demo1 American.smproj          85 rows
//     欧式钢协          demo1 European+piano.smproj    87 rows
//     美式钢协          demo1 American+piano.smproj    86 rows
// Nothing here is generated, re-spaced, re-centred or re-faced: the positions
// and the angles are THEIRS.  Do NOT "tidy" a table — a second --dump-layout
// has to reproduce the source dump byte for byte.
//
// Loading a preset REPLACES the PLACEMENT and starts from an EMPTY stage: every
// item is dropped (instruments AND microphones), together with the mic groups,
// the main pair and every cable that ends on a microphone.  Cabling devices and
// their device -> device trunks stay, as do the project fields.  The app never
// reads or writes preset files — these tables ARE the presets.
// ---------------------------------------------------------------------------
"""

COMMENTS = {
    "kEu": """// 三管编制 · 欧式 / Triple Wind · European (86 players incl. the conductor) —
// dumped from the user's own project "demo1 European.smproj" with the
// --dump-layout hook.  Positions and angles are THEIRS: do NOT "tidy" them.
""",
    "kUs": """// 三管编制 · 美式 / Triple Wind · American (85 players incl. the conductor) —
// dumped from the user's own project "demo1 American.smproj" with the
// --dump-layout hook.  Positions and angles are THEIRS: do NOT "tidy" them.
""",
    "kEuPiano": """// 欧式钢协 / European Piano Concerto (87 players: 欧式 + the grand piano) —
// dumped from the user's own project "demo1 European+piano.smproj" with the
// --dump-layout hook.  Positions and angles are THEIRS: do NOT "tidy" them.
""",
    "kUsPiano": """// 美式钢协 / American Piano Concerto (86 players: 美式 + the grand piano) —
// dumped from the user's own project "demo1 American+piano.smproj" with the
// --dump-layout hook.  Positions and angles are THEIRS: do NOT "tidy" them.
""",
}


def block(var):
    body, ids, proj, _ = rows[var]
    out = [COMMENTS[var], "static const PresetRow %s[] = {\n" % var]
    out.extend(ln + "\n" for ln in body)
    out.append("};\n")
    return "".join(out)


src = io.open(SRC, encoding="utf-8").read()

# ---- header comment: from the first "// ----" banner through "namespace {"
hs = src.index("// ---------------------------------------------------------------------------\n"
               "// BUILT-IN ORCHESTRA PRESETS")
he = src.index("namespace {", hs)
src = src[:hs] + HEADER + "\n" + src[he:]

# ---- the four table bodies: kEu declaration .. the PresetDef struct
ts = src.index("// 欧式 / European")
te = src.index("struct PresetDef {")
tables_text = "\n".join(block(v) for v, _, _ in TABLES) + "\n"
src = src[:ts] + tables_text + src[te:]

# ---- kPresets[]: four entries in the requested order
old = """const PresetDef kPresets[] = {
    {S::PresetEu, kEu, (int)(sizeof(kEu) / sizeof(kEu[0]))},
    {S::PresetUs, kUs, (int)(sizeof(kUs) / sizeof(kUs[0]))},
    {S::PresetUsPiano, kUsPiano, (int)(sizeof(kUsPiano) / sizeof(kUsPiano[0]))},
};
"""
new = """const PresetDef kPresets[] = {
    {S::PresetEu, kEu, (int)(sizeof(kEu) / sizeof(kEu[0]))},
    {S::PresetUs, kUs, (int)(sizeof(kUs) / sizeof(kUs[0]))},
    {S::PresetEuPiano, kEuPiano, (int)(sizeof(kEuPiano) / sizeof(kEuPiano[0]))},
    {S::PresetUsPiano, kUsPiano, (int)(sizeof(kUsPiano) / sizeof(kUsPiano[0]))},
};
"""
if old not in src:
    raise SystemExit("kPresets[] block not found verbatim")
src = src.replace(old, new)

with io.open(SRC, "w", encoding="utf-8", newline="\n") as f:
    f.write(src)
print("wrote", SRC, "counts:", {v: len(rows[v][1]) for v, _, _ in TABLES})
