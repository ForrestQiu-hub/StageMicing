# -*- coding: utf-8 -*-
"""Quick PNG preview of a PresetRow table body (dev aid, not shipped logic).

    python tools/preview_table.py BODY.txt OUT.png [W D] [--arcs CX CY]

Draws the same rotated icon box presetcheck.py measures, the stage rectangle
and (optionally) the concentric arcs used by the fan generator.
"""
import io
import math
import re
import sys

from PIL import Image, ImageDraw

ROOT = r"E:\Stage Micing Scene"
CATALOG = ROOT + r"\src\Catalog.cpp"

SCALE = 46.0     # pixels per metre
SHORT = {
    "conductor": "C", "violin": "1", "violin2": "2", "viola": "V", "cello": "Cv",
    "bass": "B", "harp": "H", "celesta": "Ce", "flute": "Fl", "oboe": "Ob",
    "clarinet": "Cl", "bassoon": "Fg", "horn": "Hn", "trumpet": "Tp",
    "trombone": "Tb", "tuba": "Tu", "timpani": "Ti", "bassdrum": "Bd",
    "cymbal": "Cy", "snare": "Sn", "xylophone": "Xy", "glockenspiel": "Gl",
    "gong": "Go", "percussion": "Pc",
}


def main():
    path, out = sys.argv[1], sys.argv[2]
    w = float(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3][0].isdigit() else 18.0
    d = float(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[4][0].isdigit() else 12.0
    arcs = None
    if "--arcs" in sys.argv:
        i = sys.argv.index("--arcs")
        arcs = (float(sys.argv[i + 1]), float(sys.argv[i + 2]))

    cat = {}
    for m in re.finditer(
            r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"[^"]*"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
            r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}',
            io.open(CATALOG, encoding="utf-8").read()):
        cat[m.group(1)] = (float(m.group(2)) * 0.90, float(m.group(3)) * 0.90)
    cat["grand_piano"] = (1.60, 2.70)

    rows = []
    for ln in io.open(path, encoding="utf-8"):
        m = re.match(r'\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                     r'\s*(-?[0-9.]+)\s*\}', ln)
        if m:
            rows.append((m.group(1), float(m.group(2)), float(m.group(3)),
                         float(m.group(4))))

    pad = 40
    W = int(w * SCALE) + 2 * pad
    H = int(d * SCALE) + 2 * pad
    img = Image.new("RGB", (W, H), (24, 25, 28))
    g = ImageDraw.Draw(img)
    # stage: world y grows toward the audience = down the picture
    def px(x, y):
        return (pad + x * SCALE, pad + y * SCALE)

    g.rectangle([px(0, 0), px(w, d)], outline=(120, 200, 255), width=2)
    if arcs:
        cx, cy = arcs
        for r in range(2, 11):
            g.ellipse([px(cx - r, cy - r), px(cx + r, cy + r)],
                      outline=(60, 60, 66))
        g.ellipse([px(cx - 0.25, cy - 0.25), px(cx + 0.25, cy + 0.25)],
                  fill=(255, 120, 80))
    for defid, nx, ny, ang in rows:
        x, y = nx * w, ny * d
        iw, ih = cat[defid]
        a = math.radians(ang)
        ca, sa = math.cos(a), math.sin(a)
        pts = []
        for sx, sy in ((-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)):
            dx, dy = sx * iw, sy * ih
            pts.append(px(x + dx * ca - dy * sa, y + dx * sa + dy * ca))
        g.polygon(pts, outline=(230, 200, 120), fill=(70, 62, 40))
        # the icon's front axis: at angle 0 it points up the screen (world -y),
        # rotated clockwise by `angle` => forward = (sin a, -cos a)
        fx, fy = px(x, y)
        g.line([(fx, fy), (fx + sa * 0.55 * SCALE, fy - ca * 0.55 * SCALE)],
               fill=(255, 90, 90), width=2)
        g.text((fx - 3, fy - 3), SHORT.get(defid, defid[:3]), fill=(240, 240, 240))
    img.save(out)
    print("saved %s  %dx%d  %d players" % (out, W, H, len(rows)))


main()
