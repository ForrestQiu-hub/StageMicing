$ErrorActionPreference = "Stop"
$ui = "E:\Stage Micing Scene\tools\uiinput.ps1"
$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"

Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 600
Start-Process -FilePath $exe -ArgumentList '--layer','1'
Start-Sleep -Seconds 3

# 1) select by clicking the OUTER capsule: 18 px right of the item centre, i.e.
#    outside the unscaled item box (half-width 13.5 px) but on the drawn symbol.
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ui -Script "l 898 836" -Out "E:\Stage Micing Scene\tools\_acp_v_capsule.png"
Start-Sleep -Milliseconds 300

# 2) drag it 30 px up (layer 1 is the draggable mic layer)
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ui -Script "d 880 836 880 806" -Out "E:\Stage Micing Scene\tools\_acp_v_drag.png"
Start-Sleep -Milliseconds 300

# 3) rotate with the round handle that sits above the selection: after the drag the
#    mic centre is at (880, 806), the handle at ~(880, 769)
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ui -Script "d 880 769 940 800" -Out "E:\Stage Micing Scene\tools\_acp_v_rot.png"
Write-Output "sequence done"
