param(
    [string]$Out = "E:\Stage Micing Scene\tools\_shot.png",
    [int]$Wait = 2
)

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class WinShot {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
}
'@

Add-Type -AssemblyName System.Drawing

# make this process per-monitor aware so GetWindowRect returns physical pixels
try { [WinShot]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch { }

$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) {
    $proc = Start-Process -FilePath "E:\Stage Micing Scene\build\Release\StageMicing.exe" -PassThru
    Start-Sleep -Seconds $Wait
}
if ($proc.HasExited) { Write-Output "process exited: $($proc.ExitCode)"; exit 1 }

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class FindWnd {
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern IntPtr FindWindowW(string cls, string title);
}
'@
$h = [FindWnd]::FindWindowW("StageMicingWnd", $null)
if ($h -eq [IntPtr]::Zero) { $h = $proc.MainWindowHandle }
if ($h -eq [IntPtr]::Zero) {
    Start-Sleep -Milliseconds 800
    $proc.Refresh()
    $h = $proc.MainWindowHandle
}
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }

[WinShot]::ShowWindow($h, 9) | Out-Null
[WinShot]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 600

$r = New-Object WinShot+RECT
[WinShot]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.Right - $r.Left
$ht = $r.Bottom - $r.Top
if ($w -le 0 -or $ht -le 0) { Write-Output "bad rect"; exit 1 }

$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
[WinShot]::PrintWindow($h, $hdc, 2) | Out-Null
$g.ReleaseHdc($hdc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out  ${w}x${ht}"
