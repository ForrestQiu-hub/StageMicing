#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Deeper analysis of a StageMicing PNG export: dominant colours, stage rect, text ink."""
import sys
from PIL import Image
import numpy as np


def main(path):
    im = Image.open(path).convert("RGB")
    a = np.asarray(im)
    h, w, _ = a.shape
    flat = a.reshape(-1, 3)
    # pack colours
    packed = (flat[:, 0].astype(np.int32) << 16) | (flat[:, 1].astype(np.int32) << 8) | flat[:, 2]
    vals, counts = np.unique(packed, return_counts=True)
    order = np.argsort(-counts)[:8]
    print(f"file={path} size={w}x{h}")
    print("top colours:")
    for o in order:
        v = int(vals[o])
        print("   #%06X  %10d  %.2f%%" % (v, counts[o], 100.0 * counts[o] / len(packed)))

    # "dark ink" = text / drawings (much darker than the page)
    lum = a.astype(np.int32).sum(axis=2) / 3.0
    dark = lum < 150
    xs = np.where(dark.any(axis=0))[0]
    ys = np.where(dark.any(axis=1))[0]
    if len(xs):
        print(f"dark-ink bbox x=[{xs[0]},{xs[-1]}] y=[{ys[0]},{ys[-1]}]  margins L={xs[0]} R={w-1-xs[-1]} T={ys[0]} B={h-1-ys[-1]}")
    # border check with a stricter ink threshold
    for thr in (200, 180, 150):
        d = lum < thr
        l40 = int(d[:, :40].sum()); r40 = int(d[:, w - 40:].sum())
        t40 = int(d[:40, :].sum()); b40 = int(d[h - 40:, :].sum())
        print(f"  thr={thr}: border ink L={l40} R={r40} T={t40} B={b40}")
    # stage rectangle = area of the stage fill colour (2nd/3rd most common)
    stage_c = None
    for o in np.argsort(-counts):
        v = int(vals[o])
        rgb = ((v >> 16) & 255, (v >> 8) & 255, v & 255)
        if v == int(vals[order[0]]):
            continue
        stage_c = rgb
        break
    print("candidate stage colour:", stage_c)
    m = (a[:, :, 0] == stage_c[0]) & (a[:, :, 1] == stage_c[1]) & (a[:, :, 2] == stage_c[2])
    xs = np.where(m.any(axis=0))[0]
    ys = np.where(m.any(axis=1))[0]
    if len(xs):
        print(f"stage-colour bbox x=[{xs[0]},{xs[-1]}] y=[{ys[0]},{ys[-1]}] (w={xs[-1]-xs[0]+1} h={ys[-1]-ys[0]+1})")


if __name__ == "__main__":
    main(sys.argv[1])
