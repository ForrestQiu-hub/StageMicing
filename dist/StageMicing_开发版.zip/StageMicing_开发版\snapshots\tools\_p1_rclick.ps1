param(
    [int[]]$Clicks = @(),      # flat client-coordinate list, right-clicked in order
    [string]$Out = "E:\Stage Micing Scene\tools\_shot_rclick.png"
)

Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class RClicker {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
}
'@
try { [RClicker]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
[RClicker]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 400

$origin = New-Object RClicker+POINT
[RClicker]::ClientToScreen($h, [ref]$origin) | Out-Null

for ($i = 0; $i + 1 -lt $Clicks.Count; $i += 2) {
    $x = $origin.X + $Clicks[$i]
    $y = $origin.Y + $Clicks[$i + 1]
    [RClicker]::SetCursorPos($x, $y) | Out-Null
    Start-Sleep -Milliseconds 150
    [RClicker]::mouse_event(8, 0, 0, 0, [IntPtr]::Zero)    # right down
    Start-Sleep -Milliseconds 70
    [RClicker]::mouse_event(16, 0, 0, 0, [IntPtr]::Zero)   # right up
    Start-Sleep -Milliseconds 500
}

$wr = New-Object RClicker+RECT
[RClicker]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L; $ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[RClicker]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out ${w}x${ht}"
