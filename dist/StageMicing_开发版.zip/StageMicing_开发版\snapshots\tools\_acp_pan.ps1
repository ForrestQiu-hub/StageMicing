param(
  [Parameter(Mandatory=$true)][string]$Out,
  [string]$Extra = "--layer 1 --zoom 2.5"
)
$X1 = 700; $Y1 = 500; $X2 = 780; $Y2 = 590
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class AcpPan {
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
}
"@
[AcpPan]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null
$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"
$all = @($Extra -split '\s+' | Where-Object { $_ -ne "" })
$p = Start-Process -FilePath $exe -ArgumentList $all -PassThru
$h = [IntPtr]::Zero
for ($i = 0; $i -lt 16; $i++) {
    Start-Sleep -Milliseconds 400
    if ($p.HasExited) { throw "app exited" }
    $p.Refresh(); $h = $p.MainWindowHandle
    if ($h -ne [IntPtr]::Zero) { break }
}
if ($h -eq [IntPtr]::Zero) { throw "no window" }
Start-Sleep -Milliseconds 500
function LP([int]$x, [int]$y) { return [IntPtr](($y -shl 16) -bor ($x -band 0xFFFF)) }
# middle-button pan: WM_MBUTTONDOWN=0x207, WM_MOUSEMOVE=0x200, WM_MBUTTONUP=0x208
[AcpPan]::PostMessage($h, 0x207, [IntPtr]1, (LP $X1 $Y1)) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan]::PostMessage($h, 0x200, [IntPtr]0, (LP (($X1+$X2)/2) (($Y1+$Y2)/2))) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan]::PostMessage($h, 0x200, [IntPtr]0, (LP $X2 $Y2)) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan]::PostMessage($h, 0x208, [IntPtr]0, (LP $X2 $Y2)) | Out-Null
Start-Sleep -Milliseconds 600
$r = New-Object AcpPan+RECT
[AcpPan]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.R - $r.L; $ht = $r.B - $r.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[AcpPan]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc); $g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Stop-Process -Id $p.Id -Force
Write-Output ("saved {0} {1}x{2}" -f $Out, $w, $ht)
