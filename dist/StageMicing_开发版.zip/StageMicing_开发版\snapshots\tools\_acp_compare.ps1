$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$before = [System.Drawing.Bitmap]::FromFile("E:\Stage Micing Scene\tools\_acp_before_L1.png")
$after  = [System.Drawing.Bitmap]::FromFile("E:\Stage Micing Scene\tools\_acp_final_1x.png")
$rx = 809; $ry = 819; $rw = 160; $rh = 110; $sc = 5
$dst = New-Object System.Drawing.Bitmap ($rw * $sc * 2), ($rh * $sc)
$g = [System.Drawing.Graphics]::FromImage($dst)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($before, (New-Object System.Drawing.Rectangle 0, 0, ($rw*$sc), ($rh*$sc)), (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), [System.Drawing.GraphicsUnit]::Pixel)
$g.DrawImage($after,  (New-Object System.Drawing.Rectangle ($rw*$sc), 0, ($rw*$sc), ($rh*$sc)), (New-Object System.Drawing.Rectangle $rx, $ry, $rw, $rh), [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$dst.Save("E:\Stage Micing Scene\tools\_acp_mic_compare.png", [System.Drawing.Imaging.ImageFormat]::Png)
$dst.Dispose(); $before.Dispose(); $after.Dispose()
"saved compare"
