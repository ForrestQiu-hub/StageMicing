# -*- coding: utf-8 -*-
# Verifier for the built-in orchestra presets in src/Presets.cpp.
#
# Reads every PresetRow table of src/Presets.cpp (欧式 / 美式 / 欧式钢协 /
# 美式钢协 — the list is discovered, never hard-coded) and the catalogue
# footprints straight out of the sources, rebuilds every player's footprint and
# reports
#     * icons that leave the stage rectangle,
#     * pairs whose ROTATED rectangles really overlap (exact separating-axis
#       test = what the app draws), and
#     * pairs whose conservative axis-aligned BOUNDS overlap (the box test this
#       checker used to rely on; it also fires on staggered rows whose icons are
#       far apart, so it is reported separately and never hides a real clash).
#
# Usage:
#     python tools/presetcheck.py                # 18 x 12, the 音乐厅 hall
#     python tools/presetcheck.py 14 10          # another stage size
#     python tools/presetcheck.py 14 10 <root>   # another checkout
import io
import math
import re
import sys

W, D = 18.0, 12.0            # the 音乐厅 hall stage (see TopBar 音乐厅 button)
ROOT = r"E:\Stage Micing Scene"
if len(sys.argv) >= 4:
    ROOT = sys.argv[3]
if len(sys.argv) >= 3:
    W, D = float(sys.argv[1]), float(sys.argv[2])
CATALOG = ROOT + r"\src\Catalog.cpp"
PRESETS = ROOT + r"\src\Presets.cpp"

# ---- catalogue: id -> (w, h) in metres, already scaled ---------------------
cat = {}
text = io.open(CATALOG, encoding="utf-8").read()
for m in re.finditer(
        r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"[^"]*"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
        r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}', text):
    cat[m.group(1)] = (float(m.group(2)), float(m.group(3)))
# CatScale(): the grand piano keeps its size, everything else is 90 %
for k in cat:
    s = 1.0 if k == "grand_piano" else 0.90
    cat[k] = (cat[k][0] * s, cat[k][1] * s)
if not cat:
    raise SystemExit("no catalogue rows parsed from " + CATALOG)

# ---- the preset tables ----------------------------------------------------
lines = io.open(PRESETS, encoding="utf-8").read().splitlines()
tables = {}
cur = None
for ln in lines:
    m = re.search(r"static const PresetRow (k\w+)\[\]", ln)
    if m:
        cur = tables.setdefault(m.group(1), [])
        continue
    if cur is not None:
        if ln.strip() == "};":
            cur = None
            continue
        m = re.match(r'\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                     r'\s*(-?[0-9.]+)\s*\}', ln)
        if m:
            cur.append((m.group(1), float(m.group(2)), float(m.group(3)),
                        float(m.group(4))))


def corners(defid, x, y, deg):
    w, h = cat[defid]
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    out = []
    for sx, sy in ((-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)):
        dx, dy = sx * w, sy * h
        out.append((x + dx * ca - dy * sa, y + dx * sa + dy * ca))
    return out


def aabb(defid, x, y, deg):
    w, h = cat[defid]
    a = math.radians(deg)
    bw = w * abs(math.cos(a)) + h * abs(math.sin(a))
    bh = w * abs(math.sin(a)) + h * abs(math.cos(a))
    return (x - bw / 2, y - bh / 2, x + bw / 2, y + bh / 2)


def sat_hit(qa, qb):
    """Exact test for two rotated rectangles: True when they overlap."""
    for quad in (qa, qb):
        for i in range(4):
            x1, y1 = quad[i]
            x2, y2 = quad[(i + 1) % 4]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n < 1e-9:
                continue
            ax, ay = ax / n, ay / n
            amin = min(px * ax + py * ay for px, py in qa)
            amax = max(px * ax + py * ay for px, py in qa)
            bmin = min(px * ax + py * ay for px, py in qb)
            bmax = max(px * ax + py * ay for px, py in qb)
            if min(amax, bmax) - max(amin, bmin) <= 0.0:
                return False
    return True


print("stage %.2f x %.2f m   (%s)" % (W, D, PRESETS))
total_out = total_sat = total_box = 0
for name, rows in tables.items():
    out = sat = box = 0
    boxes = []
    for defid, nx, ny, angle in rows:
        if defid not in cat:
            print("  UNKNOWN id %s" % defid)
            out += 1
            continue
        x, y = nx * W, ny * D
        b = aabb(defid, x, y, angle)
        boxes.append((defid, x, y, angle, b))
        if b[0] < -0.01 or b[1] < -0.01 or b[2] > W + 0.01 or b[3] > D + 0.01:
            print("  OUT  %-11s (%.2f, %.2f) %.2f,%.2f..%.2f,%.2f"
                  % (defid, x, y, b[0], b[1], b[2], b[3]))
            out += 1
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if sat_hit(corners(a[0], a[1], a[2], a[3]),
                       corners(b[0], b[1], b[2], b[3])):
                print("  CLASH %-11s (%.2f,%.2f) x %-11s (%.2f,%.2f)"
                      % (a[0], a[1], a[2], b[0], b[1], b[2]))
                sat += 1
            ba, bb = a[4], b[4]
            if (min(ba[2], bb[2]) - max(ba[0], bb[0]) > 0.01 and
                    min(ba[3], bb[3]) - max(ba[1], bb[1]) > 0.01):
                box += 1
    print("%s: %d players  out %d  footprint-clash %d  aabb-pair %d  -> %s"
          % (name, len(rows), out, sat, box,
             "OK" if out == 0 and sat == 0 else "PROBLEMS"))
    print("  x %.2f..%.2f  y %.2f..%.2f"
          % (min(b[4][0] for b in boxes), max(b[4][2] for b in boxes),
             min(b[4][1] for b in boxes), max(b[4][3] for b in boxes)))
    total_out += out
    total_sat += sat
    total_box += box

print("problems: %d  (out %d, footprint-clash %d, aabb-pair %d)"
      % (total_out + total_sat, total_out, total_sat, total_box))
sys.exit(1 if (total_out or total_sat) else 0)
