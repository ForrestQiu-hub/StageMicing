# -*- coding: utf-8 -*-
# One-shot: append the two new L10n strings (欧式钢协 / 框选 N 个) to the four
# positional tables in src/L10n.cpp.
import io

P = r"E:\Stage Micing Scene\src\L10n.cpp"
src = io.open(P, encoding="utf-8").read()

EDITS = [
    # zh
    ('''    // 撤销 / 重做
    L"无可撤销", L"无可重做", L"已撤销", L"已重做", L"撤销失败",
};''',
     '''    // 撤销 / 重做
    L"无可撤销", L"无可重做", L"已撤销", L"已重做", L"撤销失败",
    // 欧式钢协（用户自己的欧式 + 三角钢琴编制）
    L"欧式钢协",
    // 框选（橡皮筋多选）
    L"框选 %d 个",
};'''),
    # en
    ('''    // undo / redo
    L"Nothing to undo", L"Nothing to redo", L"Undone", L"Redone", L"Undo failed",
};''',
     '''    // undo / redo
    L"Nothing to undo", L"Nothing to redo", L"Undone", L"Redone", L"Undo failed",
    // European Piano Concerto
    L"European Piano Concerto",
    // rubber-band multi-select
    L"Marquee selected %d",
};'''),
    # de
    ('''    // Rückgängig / Wiederholen
    L"Nichts rückgängig zu machen", L"Nichts zu wiederholen", L"Rückgängig gemacht",
    L"Wiederholt", L"Rückgängig fehlgeschlagen",
};''',
     '''    // Rückgängig / Wiederholen
    L"Nichts rückgängig zu machen", L"Nichts zu wiederholen", L"Rückgängig gemacht",
    L"Wiederholt", L"Rückgängig fehlgeschlagen",
    // Europäisches Klavierkonzert
    L"Europäisches Klavierkonzert",
    // Rahmenauswahl (Gummiband-Mehrfachauswahl)
    L"Rahmenauswahl: %d",
};'''),
    # fr
    ('''    // annuler / rétablir
    L"Rien à annuler", L"Rien à rétablir", L"Annulé", L"Rétabli",
    L"Échec de l'annulation",
};''',
     '''    // annuler / rétablir
    L"Rien à annuler", L"Rien à rétablir", L"Annulé", L"Rétabli",
    L"Échec de l'annulation",
    // concerto pour piano européen
    L"Concerto pour piano européen",
    // sélection rectangulaire (multi-sélection au lasso)
    L"Sélection rectangulaire : %d",
};'''),
]

for old, new in EDITS:
    if src.count(old) != 1:
        raise SystemExit("pattern count %d: %r" % (src.count(old), old[:60]))
    src = src.replace(old, new)

io.open(P, "w", encoding="utf-8", newline="\n").write(src)
print("ok")
