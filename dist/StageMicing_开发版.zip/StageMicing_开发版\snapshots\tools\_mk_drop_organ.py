# -*- coding: utf-8 -*-
# One-shot: retire the 管风琴 / organ instrument.
import io

ROOT = r"E:\Stage Micing Scene"


def edit(path, pairs):
    p = ROOT + "\\" + path
    src = io.open(p, encoding="utf-8").read()
    for old, new in pairs:
        if src.count(old) != 1:
            raise SystemExit("%s: pattern count %d for %r" % (path, src.count(old), old[:70]))
        src = src.replace(old, new)
    io.open(p, "w", encoding="utf-8", newline="\n").write(src)
    print("patched", path)


# 1) catalogue row -----------------------------------------------------------
edit(r"src\Catalog.cpp", [
    ('    {L"organ",       L"管风琴",   L"Organ",       L"keys", 2.45, 1.25},\n', ''),
])

# 2) loader declarations (out-param reports the items it had to drop) ---------
edit(r"src\Model.h", [
    ("bool LoadProjectFile(Project& pr, const std::wstring& path, std::wstring& err);",
     "bool LoadProjectFile(Project& pr, const std::wstring& path, std::wstring& err,\n"
     "                     int* skippedUnknown = nullptr);"),
    ("bool ParseProject(const std::wstring& text, Project& pr, std::wstring& err);",
     "bool ParseProject(const std::wstring& text, Project& pr, std::wstring& err,\n"
     "                  int* skippedUnknown = nullptr);"),
])

# 3) the loader: skip an item whose type the catalogue does not know ---------
P = r"src\ProjectIO.cpp"
src = io.open(ROOT + "\\" + P, encoding="utf-8").read()

reps = []

reps.append((
    "bool ParseProject(const std::wstring& text, Project& pr, std::wstring& err) {",
    "bool ParseProject(const std::wstring& text, Project& pr, std::wstring& err,\n"
    "                  int* skippedUnknown) {\n"
    "    if (skippedUnknown) *skippedUnknown = 0;"))

reps.append((
    "            if (it.id <= 0) it.id = np.nextId;\n"
    "            if (!it.defId.empty()) np.items.push_back(it);",
    "            if (it.id <= 0) it.id = np.nextId;\n"
    "            // An item whose type the catalogue no longer knows is SKIPPED on\n"
    "            // load (the app retired the 管风琴 / organ): nothing could draw it,\n"
    "            // click it or delete it, so keeping it would leave an invisible\n"
    "            // ghost on the stage.  `skippedUnknown` carries the count back to\n"
    "            // the caller, which reports it in the status bar.\n"
    "            if (!it.defId.empty() && !FindItem(it.defId)) {\n"
    "                if (skippedUnknown) ++*skippedUnknown;\n"
    "                continue;\n"
    "            }\n"
    "            if (!it.defId.empty()) np.items.push_back(it);"))

reps.append((
    "bool LoadProjectFile(Project& pr, const std::wstring& path, std::wstring& err) {",
    "bool LoadProjectFile(Project& pr, const std::wstring& path, std::wstring& err,\n"
    "                     int* skippedUnknown) {"))

reps.append((
    "    return ParseProject(FromU8(bytes), pr, err);",
    "    return ParseProject(FromU8(bytes), pr, err, skippedUnknown);"))

reps.append((
    "bool App::OpenProjectFrom(const std::wstring& path) {\n"
    "    Project np;\n"
    "    std::wstring err;\n"
    "    if (!LoadProjectFile(np, path, err)) {",
    "bool App::OpenProjectFrom(const std::wstring& path) {\n"
    "    Project np;\n"
    "    std::wstring err;\n"
    "    int skipped = 0;\n"
    "    if (!LoadProjectFile(np, path, err, &skipped)) {"))

reps.append((
    "    AfterProjectLoaded();\n"
    "    ResetUndoHistory();   // a freshly opened file / the demo is the UNDO baseline",
    "    AfterProjectLoaded();\n"
    "    // report what the loader dropped: AfterProjectLoaded clears the status\n"
    "    // line, so the note has to come after it\n"
    "    if (skipped > 0) StatusMsg(dr::Fmt(L10n::T(S::IgnoredFmt), skipped), true);\n"
    "    ResetUndoHistory();   // a freshly opened file / the demo is the UNDO baseline"))

for old, new in reps:
    if src.count(old) != 1:
        raise SystemExit("ProjectIO pattern count %d for %r" % (src.count(old), old[:70]))
    src = src.replace(old, new)
io.open(ROOT + "\\" + P, "w", encoding="utf-8", newline="\n").write(src)
print("patched", P)

# 4) the asset generator: no organ icon, no organ catalogue row ---------------
AN = io.open(ROOT + r"\tools\make_assets.py", encoding="utf-8").read()
a, b = AN.find("def organ(s):"), AN.find("def harp(s):")
if a < 0 or b < 0 or b < a:
    raise SystemExit("organ() draw function not found")
AN = AN[:a] + AN[b:]
row = '    ("organ", "管风琴", "Organ", "keys", 2.45, 1.25, organ),\n'
if AN.count(row) != 1:
    raise SystemExit("organ catalogue row count %d" % AN.count(row))
AN = AN.replace(row, "")
io.open(ROOT + r"\tools\make_assets.py", "w", encoding="utf-8", newline="\n").write(AN)
print("patched tools/make_assets.py")

# 5) the generated icon log (not read by the app) -----------------------------
edit(r"assets\vector_icons.txt", [
    ("icon organ 512 261\n", ""),
])
print("done")
