# -*- coding: utf-8 -*-
"""Conservative tidy-up of an IMPORTED PresetRow table (dev aid, not shipped).

    python tools/tidy_us.py IN.txt OUT_BODY.txt OUT.png [W D] [--src SW SD]

IN.txt is a `--dump-layout` dump (normalised nx, ny + angle) of the user's own
project; SW/SD are that project's stage size (default 14 x 14) and W/D the
stage the preset is meant for (default 18 x 12, the 音乐厅 hall).

The user's arrangement is kept section by section -- nothing is redesigned and
no section migrates:

  1. the dump is rebuilt in METRES on the user's own stage, so their fan keeps
     its exact shape (no aspect distortion from re-normalising),
  2. the whole ensemble is TRANSLATED so its average centre sits on the centre
     of the target stage (the user's own "stay centred" rule),
  3. each defId group is split into ROWS along the radius axis; inside a row
     the players are re-spaced with EQUAL angular steps over the row's own
     angular span and pulled onto the row's mean radius, so a ragged hand
     placed row reads as a clean arc -- its midpoint never moves,
  4. every player is re-faced at the conductor with the documented rule
     `angle = atan2(cx - x, y - cy)`, plus the +180 deg FRENCH HORN bell
     correction,
  5. a SAT (separating axis) separation pass -- the TRUE rotated footprint
     test, not the conservative AABB -- pushes apart only the pairs that
     really overlap, then the stage margin is re-applied,
  6. the result is reported with both tests: SAT overlaps (real footprint
     collisions) and the AABB pairs tools/presetcheck.py flags, plus the
     displacement from the user's own placement.

The body is written sorted by defId, then ny, then nx -- the order
DumpLayoutAsPresetRows emits -- so a dump of the loaded preset round-trips.
"""
import io
import math
import re
import sys

from PIL import Image, ImageDraw

ROOT = r"E:\Stage Micing Scene"
CATALOG = ROOT + r"\src\Catalog.cpp"

SHORT = {
    "conductor": "C", "violin": "1", "violin2": "2", "viola": "V", "cello": "Cv",
    "bass": "B", "harp": "H", "celesta": "Ce", "flute": "Fl", "oboe": "Ob",
    "clarinet": "Cl", "bassoon": "Fg", "horn": "Hn", "trumpet": "Tp",
    "trombone": "Tb", "tuba": "Tu", "timpani": "Ti", "bassdrum": "Bd",
    "cymbal": "Cy", "snare": "Sn", "xylophone": "Xy", "glockenspiel": "Gl",
    "gong": "Go", "percussion": "Pc",
}
NAMES = {
    "conductor": "指挥", "violin": "第一小提琴", "violin2": "第二小提琴",
    "viola": "中提琴", "cello": "大提琴", "bass": "低音提琴", "harp": "竖琴",
    "celesta": "钢片琴", "flute": "长笛", "oboe": "双簧管", "clarinet": "单簧管",
    "bassoon": "大管", "horn": "圆号", "trumpet": "小号", "trombone": "长号",
    "tuba": "大号", "timpani": "定音鼓", "bassdrum": "大鼓", "cymbal": "钹",
    "snare": "军鼓", "xylophone": "木琴", "glockenspiel": "钟琴", "gong": "锣",
    "percussion": "打击乐",
}
ROW_GAP = 0.55      # metres of radius gap that starts a new row
RING_GAP = 0.40     # metres of radius gap that starts a new RING
CLEAR = 0.012       # air gap the separator keeps (the table is rounded to mm)
MARGIN = 0.30       # metres of stage kept free around every rotated footprint
AABB_GAP = 0.05     # the free gap the AABB packer of tools/gen_fan.py keeps

cat = {}
_text = io.open(CATALOG, encoding="utf-8").read()
for m in re.finditer(
        r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"[^"]*"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
        r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}', _text):
    s = 1.0 if m.group(1) == "grand_piano" else 0.90
    cat[m.group(1)] = (float(m.group(2)) * s, float(m.group(3)) * s)

W, D = 18.0, 12.0
CX = CY = 0.0


def aabb(defid, x, y, deg):
    w, h = cat[defid]
    a = math.radians(deg)
    bw = w * abs(math.cos(a)) + h * abs(math.sin(a))
    bh = w * abs(math.sin(a)) + h * abs(math.cos(a))
    return (x - bw / 2, y - bh / 2, x + bw / 2, y + bh / 2)


def aabb_clash(a, b, gap=0.0):
    ox = min(a[2], b[2]) - max(a[0], b[0])
    oy = min(a[3], b[3]) - max(a[1], b[1])
    return ox > -gap and oy > -gap


def corners(defid, x, y, deg):
    w, h = cat[defid]
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    out = []
    for sx, sy in ((-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)):
        dx, dy = sx * w, sy * h
        out.append((x + dx * ca - dy * sa, y + dx * sa + dy * ca))
    return out


def sat_mtv(qa, qb, clear=0.0):
    """Minimum translation vector along the closest axis of two rotated
    rectangles.  Returns (axis_x, axis_y, depth) or None when the rectangles are
    further apart than `clear`; `depth` may be slightly negative, meaning they
    are separated by less than `clear` and still need to be pushed."""
    best = None
    for quad in (qa, qb):
        for i in range(4):
            x1, y1 = quad[i]
            x2, y2 = quad[(i + 1) % 4]
            ax, ay = -(y2 - y1), (x2 - x1)
            n = math.hypot(ax, ay)
            if n < 1e-9:
                continue
            ax, ay = ax / n, ay / n
            amin = min(px * ax + py * ay for px, py in qa)
            amax = max(px * ax + py * ay for px, py in qa)
            bmin = min(px * ax + py * ay for px, py in qb)
            bmax = max(px * ax + py * ay for px, py in qb)
            depth = min(amax, bmax) - max(amin, bmin)
            if depth <= -clear:
                return None            # far enough apart
            if best is None or depth < best[2]:
                # point the axis from a to b
                ca = sum(px for px, _ in qa) / 4.0
                cb = sum(px for px, _ in qb) / 4.0
                sa_ = sum(py for _, py in qa) / 4.0
                sb_ = sum(py for _, py in qb) / 4.0
                if (cb - ca) * ax + (sb_ - sa_) * ay < 0:
                    ax, ay = -ax, -ay
                best = (ax, ay, depth)
    return best


def inside(b, m=MARGIN):
    return b[0] >= m and b[1] >= m and b[2] <= W - m and b[3] <= D - m


def at(r, th):
    return CX + r * math.sin(math.radians(th)), CY - r * math.cos(math.radians(th))


def face(x, y):
    return math.degrees(math.atan2(CX - x, y - CY)) % 360.0


def icon_angle(defid, x, y):
    a = face(x, y)
    if defid == "horn":
        a = (a + 180.0) % 360.0
    return a


def polar(x, y):
    dx, dy = x - CX, y - CY
    return math.hypot(dx, dy), math.degrees(math.atan2(dx, -dy))


def read_rows(path):
    rows = []
    for ln in io.open(path, encoding="utf-8"):
        m = re.match(r'\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                     r'\s*(-?[0-9.]+)\s*\}', ln)
        if m:
            rows.append((m.group(1), float(m.group(2)), float(m.group(3)),
                         float(m.group(4))))
    return rows


def regularise(pts):
    """Split the ensemble into RINGS (radial clusters) and re-space every
    contiguous same-section RUN inside a ring with EQUAL angular steps over that
    run's own angular span.  Nothing changes radius, nothing changes section
    order, and no section migrates."""
    players = [p for p in pts if p["id"] != "conductor"]
    if not players:
        return pts
    players.sort(key=lambda p: (p["r"], p["th"]))
    rings, cur = [], [players[0]]
    for prev, now in zip(players, players[1:]):
        if now["r"] - prev["r"] > RING_GAP:
            rings.append(cur)
            cur = []
        cur.append(now)
    rings.append(cur)
    for ring in rings:
        ring.sort(key=lambda p: p["th"])
        runs, run = [], [ring[0]]
        for prev, now in zip(ring, ring[1:]):
            if now["id"] != prev["id"]:
                runs.append(run)
                run = []
            run.append(now)
        runs.append(run)
        for run in runs:
            if len(run) < 2:
                continue
            lo, hi = run[0]["th"], run[-1]["th"]
            rbar = sum(p["r"] for p in run) / len(run)
            for i, p in enumerate(run):
                p["th"] = lo + (hi - lo) * i / (len(run) - 1)
                if "--snap-radius" in sys.argv:
                    p["r"] = rbar
    return pts


def fix_angles(pts):
    for p in pts:
        p["x"], p["y"] = frame(p)
        p["ang"] = 0.0 if p["id"] == "conductor" else icon_angle(p["id"], p["x"], p["y"])
    return pts


def frame(p):
    if p["id"] == "conductor":
        return CX, CY
    return at(p["r"], p["th"])


def sat_overlaps(pts, verbose=False):
    bad = 0
    quads = [corners(p["id"], p["x"], p["y"], p["ang"]) for p in pts]
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            mtv = sat_mtv(quads[i], quads[j])
            if mtv:
                if verbose:
                    print("  SAT  %-11s (%.2f,%.2f) x %-11s (%.2f,%.2f) %.2f"
                          % (pts[i]["id"], pts[i]["x"], pts[i]["y"],
                             pts[j]["id"], pts[j]["x"], pts[j]["y"], mtv[2]))
                bad += 1
    return bad


def aabb_overlaps(pts, verbose=False):
    bad = 0
    bs = [(p["id"], p["x"], p["y"], aabb(p["id"], p["x"], p["y"], p["ang"])) for p in pts]
    for i in range(len(bs)):
        for j in range(i + 1, len(bs)):
            if aabb_clash(bs[i][3], bs[j][3]):
                if verbose:
                    print("  AABB %-11s x %-11s" % (bs[i][0], bs[j][0]))
                bad += 1
    return bad


def outside(pts, verbose=False):
    bad = 0
    for p in pts:
        b = aabb(p["id"], p["x"], p["y"], p["ang"])
        if b[0] < 0 or b[1] < 0 or b[2] > W or b[3] > D:
            if verbose:
                print("  OUT  %-11s (%.2f, %.2f) %.2f,%.2f..%.2f,%.2f"
                      % (p["id"], p["x"], p["y"], b[0], b[1], b[2], b[3]))
            bad += 1
    return bad


def separate(pts, sweeps=6000):
    """Push apart only the pairs whose TRUE rotated footprints overlap.  The
    conductor never moves: when a pair involves him the other player takes the
    whole displacement."""
    for sweep in range(sweeps):
        fix_angles(pts)            # the facing depends on the position: re-face
        moved = 0.0
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                a, b = pts[i], pts[j]
                mtv = sat_mtv(corners(a["id"], a["x"], a["y"], a["ang"]),
                              corners(b["id"], b["x"], b["y"], b["ang"]), CLEAR)
                if not mtv:
                    continue
                ax, ay, depth = mtv
                step = (depth + CLEAR + 0.01) * 0.55
                if a["id"] == "conductor":
                    moves = ((b, 1.0),)
                elif b["id"] == "conductor":
                    moves = ((a, -1.0),)
                else:
                    moves = ((a, -1.0), (b, 1.0))
                for p, sgn in moves:
                    p["x"] += ax * step * sgn
                    p["y"] += ay * step * sgn
                    if p["id"] != "conductor":
                        p["r"], p["th"] = polar(p["x"], p["y"])
                moved += step
        for p in pts:
            if p["id"] == "conductor":
                continue
            b = aabb(p["id"], p["x"], p["y"], icon_angle(p["id"], p["x"], p["y"]))
            dx = dy = 0.0
            if b[0] < MARGIN:
                dx = MARGIN - b[0]
            elif b[2] > W - MARGIN:
                dx = (W - MARGIN) - b[2]
            if b[1] < MARGIN:
                dy = MARGIN - b[1]
            elif b[3] > D - MARGIN:
                dy = (D - MARGIN) - b[3]
            if dx or dy:
                p["x"] += dx
                p["y"] += dy
                p["r"], p["th"] = polar(p["x"], p["y"])
                moved += abs(dx) + abs(dy)
        if moved < 0.001:
            print("  separation converged after %d sweeps" % (sweep + 1))
            break
    fix_angles(pts)
    return pts


def emit(pts, path, counts):
    lines = []
    for p in pts:
        nx, ny = round(p["x"] / W, 3), round(p["y"] / D, 3)
        ang = 0.0 if p["id"] == "conductor" else icon_angle(p["id"], nx * W, ny * D)
        lines.append((p["id"], nx, ny, round(ang, 1)))
    lines.sort(key=lambda t: (t[0], t[2], t[1]))   # defId, ny, nx -- dump order
    body = u""
    for defid, nx, ny, ang in lines:
        body += (u'    { L"%s", %.3f, %.3f, %.1f },   // %s x%d\n'
                 % (defid, nx, ny, ang, NAMES.get(defid, defid), counts.get(defid, 1)))
    io.open(path, "w", encoding="utf-8", newline="\n").write(body)
    print("wrote %s (%d rows)" % (path, len(lines)))
    return lines


def render(lines, path):
    sc, pad = 46.0, 40
    img = Image.new("RGB", (int(W * sc) + 2 * pad, int(D * sc) + 2 * pad),
                    (24, 25, 28))
    g = ImageDraw.Draw(img)

    def px(x, y):
        return (pad + x * sc, pad + y * sc)

    g.rectangle([px(0, 0), px(W, D)], outline=(120, 200, 255), width=2)
    for r in range(2, 12):
        g.ellipse([px(CX - r, CY - r), px(CX + r, CY + r)], outline=(58, 58, 64))
    g.ellipse([px(CX - 0.25, CY - 0.25), px(CX + 0.25, CY + 0.25)],
              fill=(255, 120, 80))
    for defid, nx, ny, ang in lines:
        x, y = nx * W, ny * D
        g.polygon([px(*c) for c in corners(defid, x, y, ang)],
                  outline=(230, 200, 120), fill=(70, 62, 40))
        a = math.radians(ang)
        ca, sa = math.cos(a), math.sin(a)
        fx, fy = px(x, y)
        g.line([(fx, fy), (fx + sa * 0.55 * sc, fy - ca * 0.55 * sc)],
               fill=(255, 90, 90), width=2)
        g.text((fx - 3, fy - 3), SHORT.get(defid, defid[:3]), fill=(240, 240, 240))
    img.save(path)
    print("saved %s" % path)


def quantise(pts):
    """Snap every player onto the values the emitted table can carry: nx/ny to
    a millimetre, the facing angle to 0.1 deg -- so what we verify is exactly
    what the app loads."""
    for p in pts:
        p["x"] = round(round(p["x"] / W, 3) * W, 6)
        p["y"] = round(round(p["y"] / D, 3) * D, 6)
        if p["id"] == "conductor":
            p["ang"] = 0.0
        else:
            p["ang"] = round(icon_angle(p["id"], p["x"], p["y"]), 1)
            p["r"], p["th"] = polar(p["x"], p["y"])
    return pts


def main():
    src, out_body, out_png = sys.argv[1], sys.argv[2], sys.argv[3]
    global W, D, CX, CY
    W = float(sys.argv[4]) if len(sys.argv) > 4 else 18.0
    D = float(sys.argv[5]) if len(sys.argv) > 5 else 12.0
    sw, sd = 14.0, 14.0
    if "--src" in sys.argv:
        i = sys.argv.index("--src")
        sw, sd = float(sys.argv[i + 1]), float(sys.argv[i + 2])

    raw = read_rows(src)

    # ---- 1. metres on the user's own stage, 2. centre on the target stage --
    native = [(defid, nx * sw, ny * sd) for defid, nx, ny, _ in raw]
    cx0 = sum(p[1] for p in native) / len(native)
    cy0 = sum(p[2] for p in native) / len(native)
    dx, dy = W * 0.5 - cx0, D * 0.5 - cy0

    before = [{"id": d, "x": x + dx, "y": y + dy} for d, x, y in native]
    cond = [p for p in before if p["id"] == "conductor"][0]
    CX, CY = cond["x"], cond["y"]
    for p in before:
        p["r"], p["th"] = polar(p["x"], p["y"])
    c0 = [p for p in before if p["id"] == "conductor"][0]
    c0["r"], c0["th"] = 0.0, 0.0
    fix_angles(before)

    print("ensemble centre (%.2f, %.2f) -> stage centre (%.2f, %.2f); shift %+.2f, %+.2f m"
          % (cx0, cy0, W * 0.5, D * 0.5, dx, dy))
    print("conductor lands at (%.2f, %.2f) on %.0f x %.0f" % (CX, CY, W, D))
    print("BEFORE  sat=%d  aabb=%d  out=%d"
          % (sat_overlaps(before), aabb_overlaps(before), outside(before)))

    # ---- 3. rows -> clean arcs, 4. facing -------------------------------
    pts = [dict(p) for p in before]
    regularise(pts)
    fix_angles(pts)
    print("TIDY    sat=%d  aabb=%d  out=%d"
          % (sat_overlaps(pts), aabb_overlaps(pts), outside(pts)))

    # ---- 5. SAT separation ---------------------------------------------
    # ---- 5. SAT separation, then quantise to the emitted mm / 0.1 deg -----
    separate(pts, sweeps=6000)
    fix_angles(pts)
    for round_ in range(6):
        quantise(pts)
        q_sat, q_out = sat_overlaps(pts), outside(pts)
        if not q_sat and not q_out:
            break
        separate(pts, sweeps=3000)
        fix_angles(pts)
    nat_sat, nat_aabb, nat_out = sat_overlaps(pts), aabb_overlaps(pts), outside(pts)
    print("FINAL   sat=%d  aabb=%d  out=%d  (rounded table)" % (nat_sat, nat_aabb, nat_out))
    if nat_sat or nat_out:
        sat_overlaps(pts, verbose=True)
        outside(pts, verbose=True)

    disp = [math.hypot(p["x"] - q["x"], p["y"] - q["y"]) for p, q in zip(pts, before)]
    print("displacement from the user's placement: mean %.2f m, max %.2f m"
          % (sum(disp) / len(disp), max(disp)))

    counts = {}
    for p in pts:
        counts[p["id"]] = counts.get(p["id"], 0) + 1

    # ---- 6. emit -------------------------------------------------------
    lines = emit(pts, out_body, counts)
    render(lines, out_png)
    if "--before" in sys.argv:
        i = sys.argv.index("--before")
        before_lines = emit(before, sys.argv[i + 1], counts)
        render(before_lines, sys.argv[i + 2])

    # ---- 7. PNG preview, read back exactly as the app will load ---------
    sc, pad = 46.0, 40
    img = Image.new("RGB", (int(W * sc) + 2 * pad, int(D * sc) + 2 * pad),
                    (24, 25, 28))
    g = ImageDraw.Draw(img)

    def px(x, y):
        return (pad + x * sc, pad + y * sc)

    g.rectangle([px(0, 0), px(W, D)], outline=(120, 200, 255), width=2)
    for r in range(2, 12):
        g.ellipse([px(CX - r, CY - r), px(CX + r, CY + r)], outline=(58, 58, 64))
    g.ellipse([px(CX - 0.25, CY - 0.25), px(CX + 0.25, CY + 0.25)],
              fill=(255, 120, 80))
    for defid, nx, ny, ang in lines:
        x, y = nx * W, ny * D
        g.polygon([px(*c) for c in corners(defid, x, y, ang)],
                  outline=(230, 200, 120), fill=(70, 62, 40))
        a = math.radians(ang)
        ca, sa = math.cos(a), math.sin(a)
        fx, fy = px(x, y)
        g.line([(fx, fy), (fx + sa * 0.55 * sc, fy - ca * 0.55 * sc)],
               fill=(255, 90, 90), width=2)
        g.text((fx - 3, fy - 3), SHORT.get(defid, defid[:3]), fill=(240, 240, 240))
    img.save(out_png)
    print("saved %s" % out_png)


main()
