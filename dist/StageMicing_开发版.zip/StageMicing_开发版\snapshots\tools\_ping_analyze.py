#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analyse a StageMicing PNG export: margins, ink bands, border text columns."""
import sys
from PIL import Image
import numpy as np


def bg_of(arr):
    # background = most common colour (corner pixel)
    return arr[0, 0]


def main(path):
    im = Image.open(path).convert("RGB")
    a = np.asarray(im).astype(np.int16)
    h, w, _ = a.shape
    bg = a[0, 0].astype(np.int16)
    diff = np.abs(a - bg[None, None, :]).sum(axis=2)
    ink = diff > 6
    cols = ink.any(axis=0)
    rows = ink.any(axis=1)
    xs = np.where(cols)[0]
    ys = np.where(rows)[0]
    print(f"file={path} size={w}x{h} bg={tuple(bg.tolist())}")
    if len(xs) == 0:
        print("no ink at all")
        return
    print(f"ink bbox x=[{xs[0]},{xs[-1]}] y=[{ys[0]},{ys[-1]}]")
    print(f"margins L={xs[0]} R={w-1-xs[-1]} T={ys[0]} B={h-1-ys[-1]}")
    # ink pixel counts per column near borders
    for edge, sl in (("left", slice(0, 40)), ("right", slice(w - 40, w))):
        sub = ink[:, sl]
        print(f"  {edge} 40px ink px={int(sub.sum())} cols_with_ink={int(sub.any(axis=0).sum())}")
    for edge, sl in (("top", slice(0, 40)), ("bottom", slice(h - 40, h))):
        sub = ink[sl, :]
        print(f"  {edge} 40px ink px={int(sub.sum())} rows_with_ink={int(sub.any(axis=1).sum())}")
    # column profile of ink density (to find big empty bands)
    colsum = ink.sum(axis=0)
    rowsum = ink.sum(axis=1)
    # find runs of empty columns
    def runs(prof, n):
        out = []
        i = 0
        while i < n:
            if prof[i] == 0:
                j = i
                while j < n and prof[j] == 0:
                    j += 1
                if j - i >= 20:
                    out.append((i, j - 1, j - i))
                i = j
            else:
                i += 1
        return out
    print("  empty column runs (>=20px):", runs(colsum, w))
    print("  empty row runs (>=20px):", runs(rowsum, h))
    print(f"  densest column={int(colsum.max())} at {int(colsum.argmax())}; densest row={int(rowsum.max())} at {int(rowsum.argmax())}")
    # report ink-column profile in 100px buckets
    b = 100
    prof = [int(colsum[i:i + b].sum()) for i in range(0, w, b)]
    print("  col ink per 100px:", prof)
    prof2 = [int(rowsum[i:i + b].sum()) for i in range(0, h, b)]
    print("  row ink per 100px:", prof2)


if __name__ == "__main__":
    main(sys.argv[1])
