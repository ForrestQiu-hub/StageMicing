param(
    [string]$Out = "E:\Stage Micing Scene\tools\_p1.png",
    [string[]]$AppArgs = @(),
    [string]$CropRect = "",   # "l,t,r,b" in client coords, "" = whole client area
    [int]$Wait = 4
)
# TEMPORARY verification helper (delete after use): launch the app with args,
# wait, bring it to the foreground and grab the SCREEN (PrintWindow returns a
# stale DWM frame for this app because it does not handle WM_PRINT), crop to the
# requested client rect, then kill the process.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class Sh {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  public delegate bool EnumProc(IntPtr h, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lp);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int x, y; }
}
'@
Add-Type -AssemblyName System.Drawing
[Sh]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null

Get-Process StageMicing -ErrorAction SilentlyContinue | ForEach-Object { $_.Kill(); }
Start-Sleep -Milliseconds 600
$proc = Start-Process -FilePath "E:\Stage Micing Scene\build\Release\StageMicing.exe" -ArgumentList $AppArgs -PassThru
Start-Sleep -Seconds $Wait
if ($proc.HasExited) { Write-Output "process exited: $($proc.ExitCode)"; exit 1 }

$script:targetPid = $proc.Id
$script:h = [IntPtr]::Zero
$cb = [Sh+EnumProc]{
    param($w, $lp)
    $pp = [uint32]0
    [Sh]::GetWindowThreadProcessId($w, [ref]$pp) | Out-Null
    if ($pp -ne $script:targetPid) { return $true }
    $sb = New-Object System.Text.StringBuilder 256
    [Sh]::GetClassNameW($w, $sb, 256) | Out-Null
    if ($sb.ToString() -ne "StageMicingWnd") { return $true }
    $rc = New-Object Sh+RECT
    [Sh]::GetClientRect($w, [ref]$rc) | Out-Null
    if ($rc.R -gt 200) { $script:h = $w; return $false }
    return $true
}
[Sh]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null
$h = $script:h
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }

$cr = New-Object Sh+RECT; [Sh]::GetClientRect($h, [ref]$cr) | Out-Null
$co = New-Object Sh+POINT; [Sh]::ClientToScreen($h, [ref]$co) | Out-Null
[Sh]::ShowWindow($h, 9) | Out-Null
[Sh]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 900

$scr = New-Object -TypeName System.Drawing.Bitmap -ArgumentList @(1920, 1200)
$gs = [System.Drawing.Graphics]::FromImage($scr)
$gs.CopyFromScreen(0, 0, 0, 0, (New-Object System.Drawing.Size 1920, 1200))
$gs.Dispose()

$cl = 0; $ct = 0; $crr = $cr.R; $cbb = $cr.B
if ($CropRect -ne "") {
    $p = $CropRect.Split(",")
    $cl = [int]$p[0]; $ct = [int]$p[1]; $crr = [int]$p[2]; $cbb = [int]$p[3]
}
$cl = [math]::Min($cl, $cr.R); $crr = [math]::Min($crr, $cr.R)
$ct = [math]::Min($ct, $cr.B); $cbb = [math]::Min($cbb, $cr.B)
$w = $crr - $cl; $ht = $cbb - $ct
if ($w -le 0 -or $ht -le 0) { Write-Output "bad crop"; exit 1 }
$dst = New-Object -TypeName System.Drawing.Bitmap -ArgumentList @($w, $ht)
$gd = [System.Drawing.Graphics]::FromImage($dst)
$gd.DrawImage($scr, (New-Object System.Drawing.Rectangle 0, 0, $w, $ht),
              ($co.x + $cl), ($co.y + $ct), $w, $ht, [System.Drawing.GraphicsUnit]::Pixel)
$gd.Dispose()
$dst.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$dst.Dispose(); $scr.Dispose()
Write-Output "saved $Out crop ${w}x${ht} client=$($cr.R)x$($cr.B) dpi=$([Sh]::GetDpiForWindow($h))"
$proc.Kill()
Write-Output "sha256 $((Get-FileHash $Out -Algorithm SHA256).Hash)"
