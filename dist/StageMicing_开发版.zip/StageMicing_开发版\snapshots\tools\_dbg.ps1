param([string]$Dump,[string]$Label="",[string]$Panel="insp")
$lines = Get-Content -Path $Dump -Encoding Unicode
$insp = $null; $p1 = $null
foreach ($ln in $lines) {
  if ($ln -match '^insp panel (-?\d+) (-?\d+) (-?\d+) (-?\d+) scroll (-?\d+) content (-?\d+)') {
    $insp = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
  } elseif ($ln -match '^p1 panel (-?\d+) (-?\d+) (-?\d+) (-?\d+)') {
    $p1 = @([int]$Matches[1], [int]$Matches[2], [int]$Matches[3], [int]$Matches[4])
  }
}
$panel = if ($Panel -eq "p1") { $p1 } else { $insp }
Write-Output ("panel=" + ($panel -join ",") + " count=" + $panel.Count + " H=" + ($panel[3] - $panel[1]))