param(
  [Parameter(Mandatory=$true)][string]$Out,
  [string]$Extra = "",
  [int]$SleepMs = 2500
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class AcpDpi {
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
}
"@
# per-monitor-v2, so the child inherits a DPI-aware context and lays out at 1.25
[AcpDpi]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null

$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"
$all = @($Extra -split '\s+' | Where-Object { $_ -ne "" })
$p = Start-Process -FilePath $exe -ArgumentList $all -PassThru
$h = [IntPtr]::Zero
for ($i = 0; $i -lt 16; $i++) {
    Start-Sleep -Milliseconds 400
    if ($p.HasExited) { throw "app exited, code $($p.ExitCode)" }
    $p.Refresh()
    $h = $p.MainWindowHandle
    if ($h -ne [IntPtr]::Zero) { break }
}
if ($h -eq [IntPtr]::Zero) { throw "no window for pid $($p.Id)" }
Start-Sleep -Milliseconds 600
$r = New-Object AcpDpi+RECT
[AcpDpi]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.R - $r.L; $ht = $r.B - $r.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[AcpDpi]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc); $g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Stop-Process -Id $p.Id -Force
Write-Output ("saved {0} {1}x{2}" -f $Out, $w, $ht)
