"""Probe: why the current palette ordering is weak and what a max-min path gives.

Reuses palette_design.py's colour maths (no duplicated constants) and searches a
permutation of the 40 frozen colours that maximises the MINIMUM CIELab distance
between CONSECUTIVE slots.  Prints the candidate orders + their min consecutive
dE so the best one can be folded into palette_design.py / StageView.cpp.
"""
import itertools
import random
import sys

sys.path.insert(0, r"E:\Stage Micing Scene\tools")
import palette_design as pd


def main():
    palette, kbd = pd.build(pd.DEFAULT_LEVELS)
    n = len(palette)
    S = [[pd.sep(a, b) for b in palette] for a in palette]

    def score(order):
        return min(S[order[i]][order[i + 1]] for i in range(n - 1))

    # 1) the CURRENT (hue-wheel) order, for reference
    cur = list(range(n))
    print("current wheel order   min consecutive dE = %5.2f" % score(cur))

    def worst(order):
        i = min(range(n - 1), key=lambda k: S[order[k]][order[k + 1]])
        return order[i], order[i + 1]

    a, b = worst(cur)
    print("   worst consecutive pair: slot %d %s <-> slot %d %s  dE %.2f" % (
        cur.index(a), palette[a].hx, cur.index(b), palette[b].hx, S[a][b]))

    # 2) greedy "always jump to the node farthest from the current endpoint"
    def greedy_far(start, noise=0.0, rnd=None):
        used = {start}
        order = [start]
        while len(order) < n:
            last = order[-1]
            cand = [j for j in range(n) if j not in used]
            def key(j):
                base = S[last][j]
                if noise and rnd:
                    base += rnd.uniform(-noise, noise)
                return base
            j = max(cand, key=key)
            order.append(j)
            used.add(j)
        return order

    # 3) local search: 2-opt / segment reversal + single-node move, keeping the
    #    objective max-min
    def improve(order, tries=4000, rnd=None):
        order = list(order)
        bestv = score(order)
        for _ in range(tries):
            i = rnd.randrange(n - 1)
            j = rnd.randrange(n - 1)
            if i == j:
                continue
            cand = list(order)
            # move node j right after i (Or-opt, segment length 1)
            node = cand.pop(j)
            k = cand.index(order[i])
            cand.insert(k + 1, node)
            v = score(cand)
            if v > bestv + 1e-9:
                order, bestv = cand, v
        return order, bestv

    rnd = random.Random(12345)
    best, bestv = None, -1.0
    for trial in range(300):
        start = trial % n
        o = greedy_far(start, noise=6.0 if trial else 0.0, rnd=rnd)
        o, v = improve(o, 1500, rnd)
        if v > bestv:
            best, bestv = o, v
    print("\nbest greedy+local-search max-min consecutive dE = %.2f" % bestv)
    print("order slots:", best)
    a, b = worst(best)
    print("worst pair dE %.2f  %s <-> %s" % (S[a][b], palette[a].hx, palette[b].hx))

    # report the full consecutive table
    print("\nslot  hex     next-hex  icon dE  ink dE  sep")
    for i in range(n - 1):
        x, y = best[i], best[i + 1]
        print("%3d  %s  %s  %6.2f  %6.2f  %6.2f" % (
            i, palette[x].hx, palette[y].hx,
            pd.de(palette[x].lab, palette[y].lab),
            pd.de(palette[x].ilab, palette[y].ilab), S[x][y]))


if __name__ == "__main__":
    main()
