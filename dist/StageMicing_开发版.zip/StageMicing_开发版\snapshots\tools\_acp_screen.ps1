param(
  [string]$Out = "E:\Stage Micing Scene\tools\_acp_screen.png"
)
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class WinR {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X, Y; }
}
'@
Add-Type -AssemblyName System.Drawing
$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
$cr = New-Object WinR+RECT
[WinR]::GetClientRect($h, [ref]$cr) | Out-Null
$pt = New-Object WinR+POINT
$pt.X = 0; $pt.Y = 0
[WinR]::ClientToScreen($h, [ref]$pt) | Out-Null
$w = $cr.Right - $cr.Left
$hh = $cr.Bottom - $cr.Top
$bmp = New-Object System.Drawing.Bitmap $w, $hh
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($pt.X, $pt.Y, 0, 0, (New-Object System.Drawing.Size $w, $hh))
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "screen saved $Out ${w}x${hh} at $($pt.X),$($pt.Y)"
