# -*- coding: utf-8 -*-
"""Generate the EUROPEAN (欧式) fan preset table for src/Presets.cpp.

The orchestra is a FAN: every player sits on a circular arc centred on the
conductor at the front centre of the stage, and the sections follow arcs of
increasing radius (strings inner, woodwinds next, brass further, timpani /
percussion outermost).

Usage:
    python tools/gen_fan.py                # print the table body
    python tools/gen_fan.py --out F        # write the table body to F
    python tools/gen_fan.py --check F [W D]  # AABB-check a table body
The AABB rule is exactly the one tools/presetcheck.py uses (the icon is a
w x h rectangle rotated by `angle` about its centre; its axis-aligned bounds
must stay inside the stage and must not overlap another player's bounds).
"""
import io
import math
import re
import sys

ROOT = r"E:\Stage Micing Scene"
CATALOG = ROOT + r"\src\Catalog.cpp"

W, D = 18.0, 12.0        # the 音乐厅 hall stage (18 x 12 m)
CX, CY = 9.0, 11.3       # the conductor: front centre, 0.7 m off the front edge
GAP = 0.05               # required free gap between two listed footprints

# --------------------------------------------------------------------------
# catalogue: id -> (w, h) in metres, already scaled by CatScale()
# --------------------------------------------------------------------------
cat, zh = {}, {}
_text = io.open(CATALOG, encoding="utf-8").read()
for m in re.finditer(
        r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"([^"]*)"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
        r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}', _text):
    cat[m.group(1)] = (float(m.group(3)) * 0.90, float(m.group(4)) * 0.90)
    zh[m.group(1)] = m.group(2)
cat["grand_piano"] = (1.60, 2.70)
if not cat:
    raise SystemExit("catalogue parse failed")

TH_MAX = 88.0            # no player is ever further round the fan than this


def face(x, y):
    """The documented facing rule: angle = atan2(cx - x, y - cy), degrees."""
    return math.degrees(math.atan2(CX - x, y - CY)) % 360.0


def aabb(defid, x, y, deg):
    w, h = cat[defid]
    a = math.radians(deg)
    bw = w * abs(math.cos(a)) + h * abs(math.sin(a))
    bh = w * abs(math.sin(a)) + h * abs(math.cos(a))
    return (x - bw / 2, y - bh / 2, x + bw / 2, y + bh / 2)


def clash(a, b, gap=GAP):
    ox = min(a[2], b[2]) - max(a[0], b[0])
    oy = min(a[3], b[3]) - max(a[1], b[1])
    return ox > -gap and oy > -gap


def inside(b, m=0.02):
    return b[0] >= m and b[1] >= m and b[2] <= W - m and b[3] <= D - m


def at(r, th):
    """Polar around the conductor: th = 0 straight upstage, +th to the right."""
    return CX + r * math.sin(math.radians(th)), CY - r * math.cos(math.radians(th))


def icon_angle(defid, x, y):
    """Documented facing angle; the horn bell gets the +180° special case."""
    a = face(x, y)
    if defid == "horn":
        a = (a + 180.0) % 360.0
    return a


# --------------------------------------------------------------------------
# The layout: one row per arc, left -> right as seen from the conductor
# (th < 0 is the screen-left = the conductor's left side).
#
#  strings   : 一提 + 大提 on the left (cello behind the first violins), basses
#              behind the cellos; 中提 + 二提 on the right; harp at the side of
#              the strings.
#  woodwinds : centre, TWO rows (fl + ob in front, cl + fg behind = the doubles)
#  brass     : horns behind-left, trumpets right, trombones + tuba centre-back
#  percussion: timpani far back right + bass drum / cymbals, celesta beside them
# --------------------------------------------------------------------------
ROWS = [
    # (radius, [defId, ...], pinned start in degrees or None = centre the row)
    (2.40, ["violin", "violin", "violin", "viola", "viola"], None),
    (3.45, ["violin", "violin", "violin", "violin", "viola", "viola", "violin2"],
     None),
    (4.50, ["violin", "violin", "violin", "violin", "violin",   # 12 x 第一小提琴
            "viola", "viola", "violin2", "violin2"], None),
    (5.55, ["cello", "cello", "cello",                          # cellos behind
            "viola", "viola", "violin2", "violin2", "violin2", "violin2"], None),
    (6.60, ["cello", "cello", "cello", "bass", "bass",          # basses behind
            "violin2", "violin2", "violin2"], None),
    (7.70, ["bass", "bass",                                     # basses continue
            "flute", "flute", "flute", "oboe", "oboe", "oboe"], None),
    (8.75, ["clarinet", "clarinet", "clarinet",
            "bassoon", "bassoon", "bassoon"], None),
    (9.80, ["horn", "horn", "horn", "horn",                 # horns behind-left
            "trombone", "trombone", "trombone", "tuba",     # trombones + tuba centre
            "trumpet", "trumpet", "trumpet",                # trumpets right
            "timpani", "timpani", "bassdrum", "cymbal",     # percussion far right
            "celesta"], None),
    # the harp sits at the side of the strings on the front-left flank, where the
    # fan leaves room for its big footprint
    (7.50, ["harp"], -85.0),
]

COND = ("conductor", 0.0)


def fit_row(r, items, placed, start):
    """Place `items` left->right on the arc of radius r, as tightly as the AABB
    rule allows.  `placed` collects every footprint already on the stage."""
    thetas = []
    th = start
    for defid in items:
        while True:
            x, y = at(r, th)
            b = aabb(defid, x, y, icon_angle(defid, x, y))
            if inside(b) and not any(clash(b, q) for q in placed):
                break
            th += 0.10
            if th > TH_MAX:
                raise SystemExit("row r=%.2f: %s does not fit (th=%.1f)"
                                 % (r, defid, th))
        thetas.append(th)
        placed.append(b)
    return thetas


def build(passes=6):
    """Fit every row, then re-fit it with a start angle corrected so the row's
    angular midpoint sits on th = 0.  Repeats the whole layout so a later row is
    always checked against the final positions of the earlier ones.  A row with
    a pinned start (the harp) is never re-centred."""
    starts = [-62.0] * len(ROWS)
    for k, (r, items, pin) in enumerate(ROWS):
        if pin is not None:
            starts[k] = pin
    rows = []
    for _ in range(passes):
        placed = [aabb(COND[0], CX, CY, COND[1])]
        rows = [(COND[0], 0.0, 0.0)]
        new_starts, worst = [], 0.0
        for k, (r, items, pin) in enumerate(ROWS):
            th = fit_row(r, items, placed, starts[k])
            if pin is not None:
                new_starts.append(pin)
            else:
                mid = 0.5 * (th[0] + th[-1])
                worst = max(worst, abs(mid))
                new_starts.append(starts[k] - mid)
            rows.extend((d, t, r) for d, t in zip(items, th))
        starts = new_starts
        if worst < 0.15:
            break
    return rows, starts


def emit(rows):
    total = {}
    for d, _, _ in rows:
        total[d] = total.get(d, 0) + 1
    lines = []
    for d, th, r in rows:
        x, y = (CX, CY) if d == "conductor" else at(r, th)
        nx, ny = round(x / W, 3), round(y / D, 3)
        lines.append("    { L\"%s\", %.3f, %.3f, %.1f },   // %s x%d"
                     % (d, nx, ny, icon_angle(d, x, y), zh.get(d, d), total[d]))
    return lines


def check(rows, w=W, d=D, verbose=True):
    """AABB check of the FINAL table (i.e. of the rounded normalised values)."""
    bad = 0
    boxes = []
    for defid, nx, ny, ang in rows:
        x, y = nx * w, ny * d
        b = aabb(defid, x, y, ang)
        boxes.append((defid, x, y, b))
        if b[0] < -0.01 or b[1] < -0.01 or b[2] > w + 0.01 or b[3] > d + 0.01:
            if verbose:
                print("  OUT  %-11s (%.2f, %.2f) %.2f,%.2f..%.2f,%.2f"
                      % (defid, x, y, b[0], b[1], b[2], b[3]))
            bad += 1
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if clash(boxes[i][3], boxes[j][3], gap=0.0):
                a, b = boxes[i], boxes[j]
                if verbose:
                    print("  OVER %-11s (%.2f,%.2f) x %-11s (%.2f,%.2f)"
                          % (a[0], a[1], a[2], b[0], b[1], b[2]))
                bad += 1
    return bad


def parse_body(path):
    rows = []
    for ln in io.open(path, encoding="utf-8"):
        m = re.match(r'\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                     r'\s*(-?[0-9.]+)\s*\}', ln)
        if m:
            rows.append((m.group(1), float(m.group(2)), float(m.group(3)),
                         float(m.group(4))))
    return rows


if __name__ == "__main__":
    if "--check" in sys.argv:
        i = sys.argv.index("--check")
        p = sys.argv[i + 1]
        w = float(sys.argv[i + 2]) if len(sys.argv) > i + 2 else W
        d = float(sys.argv[i + 3]) if len(sys.argv) > i + 3 else D
        rows = parse_body(p)
        n = check(rows, w, d)
        print("%s: %d players, problems: %d" % (p, len(rows), n))
        raise SystemExit(1 if n else 0)
    rows, starts = build()
    body = emit(rows)
    if "--out" in sys.argv:
        p = sys.argv[sys.argv.index("--out") + 1]
        io.open(p, "w", encoding="utf-8", newline="\n").write(
            "\n".join(body) + "\n")
        print("wrote %s: %d rows" % (p, len(body)))
    else:
        print("\n".join(body))
