"""Item 2 — 1:1 metre scale audit from a PrintWindow screenshot + the app dump.

The marker circles are measured with SUBPIXEL edge interpolation:

  * the outer edge along the side axis is the clean one (the link bar can only
    reach the INNER side, the M mark stays inside the ring),
  * the perpendicular extent of the same ring is clean too,
  * so each centre = clean outer edge +/- half the measured perpendicular extent,
    and the stroke (centred on the path) cancels exactly.

Usage: measure_scale.py <png> <dump> <micId> <ab|decca|pair>
"""
import math
import sys

import numpy as np
from PIL import Image


def parse_dump(path):
    txt = open(path, encoding='utf-16-le', errors='replace').read().lstrip('\ufeff')
    out = {'cap': {}, 'link': []}
    for line in txt.splitlines():
        f = line.split()
        if not f:
            continue
        k = f[0]
        if k == 'dpi':
            out['dpi'] = float(f[1]); out['uiScale'] = float(f[3])
            out['ppm'] = float(f[5]); out['ox'] = float(f[7]); out['oy'] = float(f[9])
        elif k == 'clientoff':
            out['coff'] = (int(f[1]), int(f[2]))
        elif k == 'cap':
            out['cap'].setdefault(int(f[1]), []).append(
                (float(f[3]), float(f[4]), float(f[5]), float(f[6])))
        elif k == 'micshape':
            out.setdefault('shape', {})[int(f[1])] = {
                'tech': int(f[3]), 'spacing': float(f[5]), 'center': float(f[7])}
        elif k == 'micradius':
            if len(f) == 5:
                out.setdefault('radius', {})[int(f[1])] = (float(f[2]), float(f[3]))
        elif k == 'micw':
            out.setdefault('micw', {})[int(f[1])] = (float(f[2]), float(f[3]), float(f[4]))
        elif k == 'link':
            out['link'].append(line)
    return out


def cap_radius_px(ppm):
    return max(5.0, 0.066 * ppm) * 1.6


def bilinear(arr, x, y):
    h, w = arr.shape
    x = min(max(x, 0.0), w - 1.001)
    y = min(max(y, 0.0), h - 1.001)
    x0, y0 = int(math.floor(x)), int(math.floor(y))
    fx, fy = x - x0, y - y0
    a = arr[y0, x0] * (1 - fx) + arr[y0, x0 + 1] * fx
    b = arr[y0 + 1, x0] * (1 - fx) + arr[y0 + 1, x0 + 1] * fx
    return a * (1 - fy) + b * fy


def sample(arr, cx, cy, du, dv, span, step=0.1):
    ts = np.arange(-span, span + 1e-9, step)
    vs = np.array([bilinear(arr, cx + t * du, cy + t * dv) for t in ts])
    return ts, vs


def edge(ts, vs, from_low):
    bg = float(np.percentile(vs, 92))
    fg = float(np.percentile(vs, 8))
    thr = 0.5 * (bg + fg)
    idx = np.nonzero(vs <= thr)[0]
    if len(idx) == 0:
        return None
    if from_low:
        a = idx[0]
        while a > 0 and vs[a - 1] <= thr:
            a -= 1
        if a == 0:
            return float(ts[0])
        b = a - 1
    else:
        a = idx[-1]
        while a < len(vs) - 1 and vs[a + 1] <= thr:
            a += 1
        if a == len(vs) - 1:
            return float(ts[-1])
        b = a + 1
    v0, v1 = vs[a], vs[b]
    t0, t1 = ts[a], ts[b]
    if abs(v1 - v0) < 1e-6:
        return float(t0)
    return float(t0 + (thr - v0) / (v1 - v0) * (t1 - t0))


def main():
    png, dump, mid, mode = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
    d = parse_dump(dump)
    ppm = d['ppm']
    coff = d.get('coff', (0, 0))
    arr = np.array(Image.open(png).convert('L'), dtype=float)
    rad = cap_radius_px(ppm)
    shape = d['shape'][mid]
    ang = d['micw'][mid][2]
    a = math.radians(ang)
    u = (math.cos(a), math.sin(a))
    v = (math.sin(a), -math.cos(a))
    print('ppm %.4f  dpi %.3f  nominal cap radius %.3f px  angle %.1f  tech %d  '
          'spacing %.4f m  center %.4f m' %
          (ppm, d['dpi'], rad, ang, shape['tech'], shape['spacing'], shape['center']))

    span = rad + 5.0

    def measure(cap, side_sign):
        cx = cap[2] + coff[0]
        cy = cap[3] + coff[1]
        t1, v1 = sample(arr, cx, cy, v[0], v[1], span)
        lo = edge(t1, v1, True)
        hi = edge(t1, v1, False)
        extent = (hi - lo) if (lo is not None and hi is not None) else 2.0 * rad
        t2, v2 = sample(arr, cx, cy, u[0], u[1], span)
        e = edge(t2, v2, side_sign < 0)
        if e is None:
            raise SystemExit('edge not found near (%.1f,%.1f)' % (cx, cy))
        cc = (e + extent * 0.5) if side_sign < 0 else (e - extent * 0.5)
        return {'x': cx + cc * u[0], 'y': cy + cc * u[1], 'ext': extent,
                'outer': e, 'cc': cc}

    caps = d['cap'][mid]
    if mode in ('ab', 'decca'):
        L = measure(caps[0], -1)
        R = measure(caps[-1], +1)
        print('ring 0 : outer %+.3f  perp extent %.3f -> centre offset %+.3f '
              '(client px %.2f,%.2f)' %
              (L['outer'], L['ext'], L['cc'], L['x'] - coff[0], L['y'] - coff[1]))
        print('ring %d : outer %+.3f  perp extent %.3f -> centre offset %+.3f '
              '(client px %.2f,%.2f)' %
              (len(caps) - 1, R['outer'], R['ext'], R['cc'], R['x'] - coff[0],
               R['y'] - coff[1]))
        du = (R['x'] - L['x']) * u[0] + (R['y'] - L['y']) * u[1]
        exp = shape['spacing'] * ppm
        name = 'AB L-R' if mode == 'ab' else 'Decca L-R'
        print('%-9s expected %.3f px (%.4f m)  measured %.3f px (%.4f m)  err %+.3f%%' %
              (name, exp, shape['spacing'], du, du / ppm, (du - exp) / exp * 100.0))
        if mode == 'decca':
            C = measure(caps[1], +1)
            vL = L['x'] * v[0] + L['y'] * v[1]
            vR = R['x'] * v[0] + R['y'] * v[1]
            vC = C['x'] * v[0] + C['y'] * v[1]
            meas = vC - 0.5 * (vL + vR)
            expo = shape['center'] * ppm
            print('%-9s expected %.3f px (%.4f m)  measured %.3f px (%.4f m)  err %+.3f%%'
                  % ('Decca C', expo, shape['center'], meas, meas / ppm,
                     (meas - expo) / expo * 100.0 if expo else 0.0))
    elif mode == 'pair2':
        # layer-03 markers: a horizontal cut through the model cy is clean (no
        # cable in this fixture), and it also yields the ring diameter; the TOP
        # edge of the vertical cut is clean (the name label is drawn BELOW).
        cs = []
        wanted = [int(v) for v in sys.argv[5:]] or sorted(d['cap'])
        for m in wanted:
            cap = d['cap'][m][0]
            cx, cy = cap[2] + coff[0], cap[3] + coff[1]
            t2, v2 = sample(arr, cx, cy, u[0], u[1], span)
            e1 = edge(t2, v2, True)
            e2 = edge(t2, v2, False)
            d_h = e2 - e1
            ccx = cx + 0.5 * (e1 + e2) * u[0]
            t1, v1 = sample(arr, ccx, cy, v[0], v[1], span)
            etop = edge(t1, v1, False)       # v points UP on screen
            ccy = cy - (etop - 0.5 * d_h)
            cs.append((m, ccx, ccy, d_h))
        print('marker diameters: ' +
              ', '.join('mic %d %.2f px' % (m, dh) for m, _, _, dh in cs))
        (m1, x1, y1, d1), (m2, x2, y2, d2) = cs[0], cs[1]
        meas = math.hypot(x2 - x1, y2 - y1)
        # the CAPSULE world positions: a main mic's cap sits beside the item
        c1, c2 = d['cap'][m1][0], d['cap'][m2][0]
        exp = math.hypot(c2[0] - c1[0], c2[1] - c1[1]) * ppm
        rr = d.get('radius', {})
        for m, dh in ((m1, d1), (m2, d2)):
            if m in rr:
                drawn = 0.5 * dh - 0.9       # pen 1.8 px is centred on the path
                print('mic %d drawn radius %.2f px (model %.2f px, %+.2f%%)' %
                      (m, drawn, rr[m][1], (drawn - rr[m][1]) / rr[m][1] * 100.0))
        print('pair %d/%d  expected %.3f px (%.4f m)  measured %.3f px (%.4f m)  '
              'err %+.3f%%' % (m1, m2, exp, exp / ppm, meas, meas / ppm,
                               (meas - exp) / exp * 100.0))
    elif mode == 'pair':
        cs = []
        wanted = [int(v) for v in sys.argv[5:]] or sorted(d['cap'])
        for m in wanted:
            cap = d['cap'][m][0]
            plus = measure(cap, +1)
            minus = measure(cap, -1)
            cs.append((m, (plus['x'] + minus['x']) * 0.5,
                       (plus['y'] + minus['y']) * 0.5,
                       0.5 * (plus['ext'] + minus['ext'])))
        print('marker outer diameters: ' +
              ', '.join('mic %d %.2f px' % (m, e) for m, _, _, e in cs))
        (m1, x1, y1, _), (m2, x2, y2, _) = cs[0], cs[1]
        meas = math.hypot(x2 - x1, y2 - y1)
        w1, w2 = d['micw'][m1], d['micw'][m2]
        exp = math.hypot(w2[0] - w1[0], w2[1] - w1[1]) * ppm
        print('pair %d/%d  expected %.3f px (%.4f m)  measured %.3f px (%.4f m)  '
              'err %+.3f%%' % (m1, m2, exp, exp / ppm, meas, meas / ppm,
                               (meas - exp) / exp * 100.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
