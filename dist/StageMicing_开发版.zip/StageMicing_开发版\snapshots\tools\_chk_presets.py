# -*- coding: utf-8 -*-
# Verify the four presets: dump counts, mic counts, round-trip bytes.
import io
import os
import sys

ROOT = r"E:\Stage Micing Scene"
TOOLS = ROOT + r"\tools"

# the four source dumps (UTF-8) and their round-trip output
SRC = [
    ("p0 三管编制·欧式", r"tools\_rows_demoEuropeansmproj.txt", r"tools\_rt_p0.txt"),
    ("p1 三管编制·美式", r"tools\_rows_demoAmericansmproj.txt", r"tools\_rt_p1.txt"),
    ("p2 欧式钢协", r"tools\_rows_demoEuropeanpianosmproj.txt", r"tools\_rt_p2.txt"),
    ("p3 美式钢协", r"tools\_rows_demoAmericanpianosmproj.txt", r"tools\_rt_p3.txt"),
]

print("== --dump of each preset ==")
for i in range(4):
    txt = io.open(os.path.join(TOOLS, "_o_p%d.txt" % i), "rb").read().decode("utf-16-le")
    inst = [ln for ln in txt.splitlines() if ln.startswith("inst ")]
    instw = [ln for ln in txt.splitlines() if ln.startswith("instw ")]
    mic = [ln for ln in txt.splitlines() if ln.startswith("mic ")]
    mics = [ln for ln in txt.splitlines() if ln.startswith("micw ")]
    msg = [ln for ln in txt.splitlines() if ln.startswith("msg ")]
    sel = [ln for ln in txt.splitlines() if ln.startswith("sel ")]
    stage = [ln for ln in txt.splitlines() if ln.startswith("stage ")]
    pres = [ln for ln in txt.splitlines() if ln.startswith("presetchip ")]
    print("p%d: inst %d  mic %d  %s  %s  %s" %
          (i, len(inst), len(mic), stage[0], sel[0], msg[0]))
    print("    %s" % pres[0])
    if len(inst) != len(instw):
        print("    !! inst/instw mismatch")

print()
print("== --dump-layout round-trip (byte identical?) ==")
ok = True
for name, src, rt in SRC:
    a = io.open(os.path.join(ROOT, src), "rb").read()
    b = io.open(os.path.join(ROOT, rt), "rb").read()
    same = a == b
    ok = ok and same
    print("%-22s %s   (%d vs %d bytes)" % (name, "IDENTICAL" if same else "DIFFER",
                                           len(a), len(b)))
    if not same:
        al = a.decode("utf-8").splitlines()
        bl = b.decode("utf-8").splitlines()
        for i, (x, y) in enumerate(zip(al, bl)):
            if x != y:
                print("    first diff line %d:\n      src %r\n      rt  %r" % (i, x, y))
                break
print("round-trip:", "ALL IDENTICAL" if ok else "FAILED")
sys.exit(0 if ok else 1)
