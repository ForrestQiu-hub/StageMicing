# Regression driver for the 01 项目信息 page + the slimmed right inspector.
# Runs the --dump hook for every selection state and audits each one (label/box/
# EDIT geometry, no overlapping EDITs, content fits without scrolling), then checks
# the six tab rects and the --layer -> page mapping.
#
# Usage:  powershell -NoProfile -ExecutionPolicy Bypass -File tools\_p1verify.ps1
param(
  [string]$Exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe",
  [string]$Dir = "E:\Stage Micing Scene\tools"
)
$ErrorActionPreference = "Continue"
$fail = 0

function Dump($name, $argv) {
  $out = Join-Path $Dir ("_pv_" + $name + ".txt")
  if (Test-Path $out) { Remove-Item $out -Force }
  $cmd = @($argv) + @("--dump", $out)
  & $Exe @cmd | Out-Null
  if (-not (Test-Path $out)) { Write-Output "$name FAIL: no dump written"; return $null }
  return $out
}
function Dumpline($path, $pattern) {
  $t = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::Unicode) -split "`n"
  return $t | Where-Object { $_ -match $pattern } | Select-Object -First 1
}

$states = @(
  @{ n = "l0-none";   a = @("--layer","0") },
  @{ n = "l0-inst";   a = @("--layer","0","--select","1") },
  @{ n = "l1-mic";    a = @("--layer","1","--select","5") },
  @{ n = "l1-main";   a = @("--layer","1","--select","4") },
  @{ n = "l1-tech1";  a = @("--layer","1","--select","4","--tech","1") },
  @{ n = "l1-tech3";  a = @("--layer","1","--select","4","--tech","3") },
  @{ n = "l2-mic";    a = @("--layer","2","--select","5") },
  @{ n = "l2-dev";    a = @("--layer","2","--select","device","1") },
  @{ n = "l3-table";  a = @("--layer","3") },
  @{ n = "l4-topo";   a = @("--layer","4") }
)

foreach ($s in $states) {
  $d = Dump $s.n $s.a
  if (-not $d) { $fail++; continue }
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Dir "_inspcheck.ps1") -Dump $d -Label $s.n
  if ($LASTEXITCODE -ne 0) { $fail++ }
}

# 01 项目信息: the fields live in the centred page panel
$d = Dump "l5-p1" @("--layer","5")
if ($d) {
  Write-Output ("--- l5-p1: " + (Dumpline $d '^p1 panel'))
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Dir "_inspcheck.ps1") -Dump $d -Label "l5-p1" -Panel p1
  if ($LASTEXITCODE -ne 0) { $fail++ }
}

# tab order + --layer mapping
$d = Dump "tabs" @("--layer","0")
if ($d) {
  Write-Output "--- six tabs (index, rect)"
  $t = [System.IO.File]::ReadAllText($d, [System.Text.Encoding]::Unicode) -split "`n"
  $t | Where-Object { $_ -match '^tab ' } | ForEach-Object { Write-Output ("  " + $_) }
}

Write-Output "--- --layer mapping (value -> ui_.layer opened)"
$map = @("5","0","1","3","4","2")
foreach ($k in $map) {
  $d = Dump ("map" + $k) @("--layer", $k)
  if (-not $d) { $fail++; continue }
  $dl = Dumpline $d '^dpi '
  $got = ($dl -split 'layer ')[1].Trim()
  if ($got -ne $k) { $fail++; Write-Output ("  --layer {0} -> layer {1}  MISMATCH" -f $k, $got) }
  else { Write-Output ("  --layer {0} -> layer {1}  OK" -f $k, $got) }
}

Write-Output ""
if ($fail -gt 0) { Write-Output "RESULT: $fail FAILED check(s)"; exit 1 }
Write-Output "RESULT: all checks passed"
exit 0
