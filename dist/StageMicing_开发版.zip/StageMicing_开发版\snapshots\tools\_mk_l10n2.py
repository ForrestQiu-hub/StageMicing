# -*- coding: utf-8 -*-
# One-shot: L10n string for the objects the loader skips (retired instrument).
import io

ROOT = r"E:\Stage Micing Scene"


def edit(path, pairs):
    p = ROOT + "\\" + path
    src = io.open(p, encoding="utf-8").read()
    for old, new in pairs:
        if src.count(old) != 1:
            raise SystemExit("%s: count %d for %r" % (path, src.count(old), old[:60]))
        src = src.replace(old, new)
    io.open(p, "w", encoding="utf-8", newline="\n").write(src)
    print("patched", path)


edit(r"src\L10n.h", [
    ("    BandSelFmt,\n    Count",
     "    BandSelFmt,\n"
     "    // objects the loader skipped while opening a project (an item type the\n"
     "    // app no longer knows, e.g. the retired 管风琴 / organ)\n"
     "    IgnoredFmt,\n"
     "    Count"),
])

edit(r"src\L10n.cpp", [
    ('    L"框选 %d 个",\n};',
     '    L"框选 %d 个",\n'
     '    // 载入项目时跳过的未知对象（已下线的乐器类型）\n'
     '    L"已忽略 %d 个无法识别的对象",\n};'),
    ('    L"Marquee selected %d",\n};',
     '    L"Marquee selected %d",\n'
     '    // objects skipped while opening a project (retired instrument type)\n'
     '    L"Ignored %d unknown object(s)",\n};'),
    ('    L"Rahmenauswahl: %d",\n};',
     '    L"Rahmenauswahl: %d",\n'
     '    // beim Öffnen übersprungene unbekannte Objekte\n'
     '    L"%d unbekannte Objekte ignoriert",\n};'),
    ('    L"Sélection rectangulaire : %d",\n};',
     '    L"Sélection rectangulaire : %d",\n'
     '    // objets inconnus ignorés à l\'ouverture du projet\n'
     '    L"%d objets inconnus ignorés",\n};'),
])
print("done")
