"""Drive one scripted StageMicing launch that is expected to open the OS colour
dialog (the 颜色 row of the item inspector), prove the dialog is really the
Win32 ChooseColor dialog, screenshot it, then cancel it with Esc.

usage: python _dlgshot.py <exe> <arg1> <arg2> ... --out <png> [--esc-after s]
Prints one line per top-level window found for the started process.
"""
import ctypes
import ctypes.wintypes as wt
import sys
import time

from PIL import Image

u32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32

args = sys.argv[1:]
out = None
esc_after = 2.5
exe, rest = args[0], args[1:]
clean = []
i = 0
while i < len(rest):
    if rest[i] == "--out":
        out = rest[i + 1]
        i += 2
        continue
    clean.append(rest[i])
    i += 1

import subprocess
proc = subprocess.Popen([exe] + clean)
time.sleep(esc_after)

WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
found = []


def cb(hwnd, lparam):
    pid = wt.DWORD()
    u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if pid.value != proc.pid:
        return True
    cls = ctypes.create_unicode_buffer(256)
    u32.GetClassNameW(hwnd, cls, 256)
    txt = ctypes.create_unicode_buffer(256)
    u32.GetWindowTextW(hwnd, txt, 256)
    vis = u32.IsWindowVisible(hwnd)
    found.append((hwnd, cls.value, txt.value, bool(vis)))
    return True


u32.EnumWindows(WNDENUMPROC(cb), 0)
print("pid", proc.pid, "windows:", len(found))
for hwnd, cls, txt, vis in found:
    print("  hwnd=%d cls=%r title=%r visible=%s" % (hwnd, cls, txt, vis))

dlg = [f for f in found if f[1] == "#32770" and f[3]]
if out and dlg:
    hwnd = dlg[0][0]
    r = wt.RECT()
    u32.GetWindowRect(wt.HWND(hwnd), ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    hdc = u32.GetWindowDC(wt.HWND(hwnd))
    mem = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    gdi32.SelectObject(mem, bmp)
    u32.PrintWindow(wt.HWND(hwnd), mem, 2)

    class BMI(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG),
                    ("biPlanes", wt.WORD), ("biBitCount", wt.WORD),
                    ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                    ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG),
                    ("biClrUsed", wt.DWORD), ("biClrImportant", wt.DWORD),
                    ("colors", wt.DWORD * 3)]

    bi = BMI()
    bi.biSize = 40
    bi.biWidth = w
    bi.biHeight = -h
    bi.biPlanes = 1
    bi.biBitCount = 32
    bi.biCompression = 0
    buf = ctypes.create_string_buffer(w * h * 4)
    gdi32.GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), 0)
    img = Image.frombuffer("RGBA", (w, h), buf.raw, "raw", "BGRA", 0, 1)
    img.convert("RGB").save(out)
    print("saved dialog shot", out, w, "x", h)
    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(mem)
    u32.ReleaseDC(wt.HWND(hwnd), hdc)

if dlg:
    # Esc = Cancel on the Win32 colour dialog
    u32.PostMessageW(wt.HWND(dlg[0][0]), 0x0100, 0x1B, 0)
    u32.PostMessageW(wt.HWND(dlg[0][0]), 0x0101, 0x1B, 0)
    print("sent ESC to the colour dialog")
else:
    print("NO #32770 dialog seen")

try:
    rc = proc.wait(timeout=20)
    print("process exit", rc)
except subprocess.TimeoutExpired:
    proc.kill()
    print("process had to be killed")
