"""Stage Micing - line-art asset generator.

Simple, recognisable stage-plot symbols drawn as white-on-transparent line art.
Run with the bundled python:  python tools/make_assets.py
"""
import math
import shutil
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ASSETS = os.path.join(ROOT, "assets")

SS = 4           # supersampling
SIZE = 512       # long side of the generated bitmap
W_MAIN = 6.0     # outline weight
W_DET = 4.0      # detail weight
WSCALE = [1.0]   # per-category stroke scale (instruments 1.1, mics 1.5)


# ----------------------------------------------------------------------------- helpers
VECTOR_OUT = []


# Per-symbol pen-weight multiplier (on top of WSCALE).  Instruments are drawn 1.2×
# heavier and the ORDINARY point microphone 1.5× heavier than the reference art;
# the lavalier, the intensity-difference pair glyphs and the main microphone keep
# their original weight (see STROKE_K setting in main()).
STROKE_K = [1.0]


class S:
    """Drawing surface using normalised (u,v) coordinates 0..1."""

    def __init__(self, w, h):
        if w >= h:
            self.W = SIZE
            self.H = max(64, int(round(SIZE * h / w)))
        else:
            self.H = SIZE
            self.W = max(64, int(round(SIZE * w / h)))
        self.img = Image.new("L", (self.W * SS, self.H * SS), 0)
        self.d = ImageDraw.Draw(self.img)

    def P(self, u, v):
        return (u * self.W * SS, v * self.H * SS)

    def line(self, pts, w=W_MAIN, closed=False, smooth=False):
        try:
            VECTOR_OUT.append(("s", w * WSCALE[0] * STROKE_K[0], list(pts)))
        except Exception:
            pass
        pp = [self.P(*p) for p in pts]
        if closed and pp[0] != pp[-1]:
            pp = pp + [pp[0]]
        if len(pp) < 2:
            return
        lw = max(1, int(round(w * WSCALE[0] * STROKE_K[0] * SS)))
        self.d.line(pp, fill=255, width=lw, joint="curve")

    def curve(self, pts, w=W_MAIN, closed=False):
        lw = max(1, int(round(w * WSCALE[0] * STROKE_K[0] * SS)))
        self.d.line([self.P(*p) for p in pts], fill=255, width=lw, joint="curve")
        if closed:
            self.line([pts[-1], pts[0]], w)

    def circle(self, cu, cv, ru, rv=None, w=W_MAIN):
        rv = ru if rv is None else rv
        try:
            VECTOR_OUT.append(("e", w * WSCALE[0] * STROKE_K[0], cu, cv, ru, rv))
        except Exception:
            pass
        x0, y0 = self.P(cu - ru, cv - rv)
        x1, y1 = self.P(cu + ru, cv + rv)
        self.d.ellipse([x0, y0, x1, y1], outline=255,
                       width=max(2, int(round(w * WSCALE[0] * STROKE_K[0] * SS))))

    def arc(self, cu, cv, ru, rv, a0, a1, w=W_DET):
        try:
            VECTOR_OUT.append(("a", w * WSCALE[0] * STROKE_K[0], cu, cv, ru, rv, a0, a1))
        except Exception:
            pass
        x0, y0 = self.P(cu - ru, cv - rv)
        x1, y1 = self.P(cu + ru, cv + rv)
        self.d.arc([x0, y0, x1, y1], a0, a1, fill=255,
                   width=max(2, int(round(w * WSCALE[0] * STROKE_K[0] * SS))))

    def dot(self, cu, cv, ru, rv=None):
        rv = ru if rv is None else rv
        x0, y0 = self.P(cu - ru, cv - rv)
        x1, y1 = self.P(cu + ru, cv + rv)
        self.d.ellipse([x0, y0, x1, y1], fill=255)

    def rect(self, x0, y0, x1, y1, w=W_DET):
        self.line([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], w, closed=True)


def bez(p0, p1, p2, p3, n=28):
    out = []
    for i in range(n + 1):
        t = i / n
        mt = 1.0 - t
        x = (mt ** 3) * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + (t ** 3) * p3[0]
        y = (mt ** 3) * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + (t ** 3) * p3[1]
        out.append((x, y))
    return out


def closed_smooth(pts, n=8):
    """Catmull-Rom through the points, wrapping around."""
    m = len(pts)
    res = []
    for i in range(m):
        p0 = pts[(i - 1) % m]
        p1 = pts[i]
        p2 = pts[(i + 1) % m]
        p3 = pts[(i + 2) % m]
        for j in range(n):
            t = j / n
            t2, t3 = t * t, t * t * t
            x = 0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t +
                       (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
                       (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            y = 0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t +
                       (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
                       (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            res.append((x, y))
    return res


def shrink(pts, k=0.06, cu=0.5, cv=0.5):
    return [(cu + (u - cu) * (1 - k), cv + (v - cv) * (1 - k)) for u, v in pts]


# ----------------------------------------------------------------------------- strings
def string_body(s, stations, neck_end=0.93, scroll=True):
    top = [(u, 0.5 - h) for u, h in stations]
    bot = [(u, 0.5 + h) for u, h in stations][::-1]
    contour = closed_smooth(top + bot, 6)
    s.curve(contour, W_MAIN, closed=True)

    # neck
    a = stations[-1][0]
    hy = stations[-1][1] * 0.42
    s.line([(a - 0.01, 0.5 - hy), (neck_end, 0.5 - hy * 0.75),
            (neck_end, 0.5 + hy * 0.75), (a - 0.01, 0.5 + hy)], W_MAIN, closed=True)
    if scroll:
        s.circle(neck_end + 0.035, 0.5, 0.045, 0.055, W_DET)

    # strings
    for k in (-1.5, -0.5, 0.5, 1.5):
        s.line([(stations[0][0] + 0.02, 0.5 + k * 0.028),
                (neck_end + 0.02, 0.5 + k * 0.020)], W_DET * 0.7)

    # bridge
    bx = stations[1][0] + 0.02
    s.line([(bx, 0.5 - stations[1][1] * 0.72),
            (bx, 0.5 + stations[1][1] * 0.72)], W_DET)

    # f-holes
    fx = stations[1][0] + (stations[2][0] - stations[1][0]) * 0.55
    s.line([(fx, 0.34), (fx - 0.03, 0.40), (fx + 0.01, 0.46), (fx - 0.02, 0.47)], W_DET * 0.9)
    s.line([(fx, 0.66), (fx - 0.03, 0.60), (fx + 0.01, 0.54), (fx - 0.02, 0.53)], W_DET * 0.9)

    # tailpiece
    tx = stations[0][0]
    s.line([(tx + 0.02, 0.5 - 0.05), (tx + 0.09, 0.5 - 0.03),
            (tx + 0.09, 0.5 + 0.03), (tx + 0.02, 0.5 + 0.05)], W_DET, closed=True)


def violin(s):
    string_body(s, [(0.04, 0.10), (0.07, 0.29), (0.13, 0.33), (0.19, 0.235),
                    (0.25, 0.205), (0.31, 0.26), (0.38, 0.28), (0.44, 0.22),
                    (0.49, 0.13)])


def viola(s):
    string_body(s, [(0.04, 0.09), (0.07, 0.30), (0.13, 0.34), (0.19, 0.24),
                    (0.25, 0.21), (0.31, 0.27), (0.38, 0.29), (0.44, 0.23),
                    (0.49, 0.14)], neck_end=0.93)


def cello(s):
    string_body(s, [(0.03, 0.11), (0.06, 0.30), (0.12, 0.35), (0.19, 0.25),
                    (0.25, 0.22), (0.31, 0.28), (0.38, 0.30), (0.44, 0.24),
                    (0.49, 0.15)], neck_end=0.90)


def double_bass(s):
    string_body(s, [(0.03, 0.13), (0.06, 0.34), (0.12, 0.38), (0.19, 0.27),
                    (0.25, 0.24), (0.31, 0.30), (0.38, 0.33), (0.44, 0.26),
                    (0.49, 0.16)], neck_end=0.88)


# ----------------------------------------------------------------------------- keyboard
def grand_piano(s):
    # plan per sketch: wide keyboard band at the top, case below with the
    # bentside on the left and a straight spine on the right, rounded tail
    s.rect(0.04, 0.02, 0.96, 0.16, W_MAIN)
    s.line([(0.94, 0.16), (0.94, 0.76)], W_MAIN)          # spine
    s.curve(bez((0.04, 0.16), (0.10, 0.17), (0.18, 0.22), (0.26, 0.30)), W_MAIN)
    s.line([(0.26, 0.30), (0.26, 0.76)], W_MAIN)          # bentside
    s.arc(0.60, 0.76, 0.34, 0.202, 0, 180, W_MAIN)        # rounded tail

def harpsichord(s):
    # wing-shaped case: tall keyboard on the left, tapering to the tail point
    s.line([(0.02, 0.05), (0.02, 0.95)], W_MAIN)
    s.line([(0.135, 0.05), (0.135, 0.95)], W_MAIN)
    v = 0.08
    while v < 0.94:
        s.line([(0.03, v), (0.125, v)], W_DET * 0.75)
        v += 0.042

    s.line([(0.135, 0.05), (0.965, 0.05), (0.965, 0.16), (0.135, 0.95)],
           W_MAIN, closed=True)
    # lid / soundboard line + rose
    s.line([(0.135, 0.13), (0.90, 0.13)], W_DET * 0.75)
    s.line([(0.135, 0.87), (0.90, 0.20)], W_DET * 0.75)
    s.circle(0.52, 0.52, 0.035, 0.035, W_DET)

def upright_piano(s):
    """The celesta's model, drawn slimmer and longer (70 % width, 130 % length)."""
    def X(u):
        return 0.5 + (u - 0.5) * 0.70

    def Y(v):
        return 0.5 + (v - 0.5) * 1.30

    s.line([(X(0.08), Y(0.06)), (X(0.92), Y(0.06)), (X(0.92), Y(0.94)),
            (X(0.08), Y(0.94))], W_MAIN, closed=True)
    # keyboard strip along the front (bottom) edge
    s.line([(X(0.08), Y(0.68)), (X(0.92), Y(0.68))], W_MAIN)
    x = 0.12
    while x < 0.90:
        s.line([(X(x), Y(0.70)), (X(x), Y(0.92))], W_DET * 0.9)
        x += 0.05
    # the two long body lines of an upright: lid edge + soundboard
    s.line([(X(0.10), Y(0.18)), (X(0.90), Y(0.18))], W_DET)
    s.line([(X(0.10), Y(0.24)), (X(0.90), Y(0.24))], W_DET * 0.75)
    s.line([(X(0.10), Y(0.62)), (X(0.90), Y(0.62))], W_DET * 0.75)


def celesta(s):
    s.rect(0.04, 0.10, 0.96, 0.90, W_MAIN)
    s.line([(0.04, 0.62), (0.96, 0.62)], W_MAIN)
    # key strip
    x = 0.08
    while x < 0.93:
        s.line([(x, 0.64), (x, 0.88)], W_DET * 0.9)
        x += 0.05
    # bars above
    for v in (0.22, 0.32, 0.42, 0.52):
        s.line([(0.10, v), (0.90, v)], W_DET)
    for u in (0.10, 0.90):
        s.line([(u, 0.18), (u, 0.56)], W_DET)


def harp(s):
    # pillar
    s.line([(0.10, 0.94), (0.10, 0.20)], W_MAIN)
    s.line([(0.04, 0.94), (0.24, 0.94)], W_MAIN)
    s.line([(0.10, 0.20), (0.92, 0.58)], W_MAIN)
    s.line([(0.10, 0.90), (0.92, 0.58)], W_MAIN)
    # neck->soundboard strings
    for i in range(1, 11):
        t = i / 11.0
        top = (0.10 + t * 0.82, 0.20 + t * 0.38)
        bot = (0.10 + t * 0.82, 0.90 - t * 0.32)
        s.line([top, bot], W_DET * 0.65)
    # base
    s.line([(0.30, 0.94), (0.55, 0.94)], W_DET)


# ----------------------------------------------------------------------------- woodwind
def flute(s):
    # head joint with raised lip plate, thin body with keys, foot with flange
    T = 0.055
    s.rect(0.03, 0.5 - T, 0.27, 0.5 + T, W_MAIN * 1.4)
    s.rect(0.27, 0.5 - T * 0.75, 0.86, 0.5 + T * 0.75, W_MAIN * 1.4)
    s.rect(0.86, 0.5 - T * 1.1, 0.97, 0.5 + T * 1.1, W_MAIN * 1.4)
    s.line([(0.97, 0.5 - T * 1.1), (1.0, 0.5 - T * 1.5)], W_DET)
    s.line([(0.97, 0.5 + T * 1.1), (1.0, 0.5 + T * 1.5)], W_DET)
    s.rect(0.06, 0.5 - T - 0.11, 0.17, 0.5 - T, W_MAIN * 1.4)   # lip plate
    s.circle(0.115, 0.5 - T - 0.055, 0.026, 0.026, W_DET)         # embouchure
    s.line([(0.34, 0.5 - T), (0.34, 0.5 - T - 0.03)], W_DET)
    for i in range(5):
        u = 0.38 + i * 0.09
        s.line([(u, 0.5 - T * 0.75), (u, 0.5 - T * 0.75 - 0.035)], W_DET)
    s.circle(0.82, 0.5 - T * 0.75, 0.03, 0.03, W_DET)             # G# key


def oboe(s):
    # slim conical tube, bulbous bell, prominent V reed
    T = 0.04
    # reed
    s.line([(0.02, 0.5 - 0.075), (0.19, 0.5 - 0.012)], W_MAIN * 1.4)
    s.line([(0.02, 0.5 + 0.075), (0.19, 0.5 + 0.012)], W_MAIN * 1.4)
    s.line([(0.02, 0.5 - 0.075), (0.02, 0.5 + 0.075)], W_MAIN * 1.4)
    # top joint
    s.line([(0.19, 0.5 - 0.035), (0.42, 0.5 - 0.042)], W_MAIN * 1.4)
    s.line([(0.19, 0.5 + 0.035), (0.42, 0.5 + 0.042)], W_MAIN * 1.4)
    # middle joint
    s.line([(0.42, 0.5 - 0.042), (0.74, 0.5 - 0.05)], W_MAIN * 1.4)
    s.line([(0.42, 0.5 + 0.042), (0.74, 0.5 + 0.05)], W_MAIN * 1.4)
    # bell with bulb
    s.line([(0.74, 0.5 - 0.05), (0.90, 0.5 - 0.13)], W_MAIN * 1.4)
    s.line([(0.74, 0.5 + 0.05), (0.90, 0.5 + 0.13)], W_MAIN * 1.4)
    s.circle(0.92, 0.5, 0.045, 0.115, W_MAIN * 1.4)               # bulb rim
    s.rect(0.24, 0.5 - 0.042 - 0.04, 0.32, 0.5 - 0.042, W_DET)    # octave key
    for i in range(3):
        s.circle(0.48 + i * 0.09, 0.5 - 0.045, 0.024, 0.024, W_DET * 0.9)


def clarinet(s):
    # tapered mouthpiece, barrel ring, big flaring bell
    s.line([(0.02, 0.5 - 0.05), (0.02, 0.5 + 0.05), (0.16, 0.5 + 0.095), (0.16, 0.5 - 0.095)], W_MAIN * 1.4, closed=True)
    s.rect(0.16, 0.5 - 0.10, 0.25, 0.5 + 0.10, W_MAIN * 1.4)        # barrel
    s.rect(0.25, 0.5 - 0.065, 0.72, 0.5 + 0.065, W_MAIN * 1.4)      # joints
    s.line([(0.72, 0.5 - 0.065), (0.93, 0.5 - 0.19), (0.965, 0.5 - 0.19),
            (0.965, 0.5 - 0.15), (0.995, 0.5 - 0.12), (0.995, 0.5 + 0.12),
            (0.965, 0.5 + 0.15), (0.965, 0.5 + 0.19), (0.93, 0.5 + 0.19),
            (0.72, 0.5 + 0.065)], W_MAIN * 1.4)
    for i in range(3):
        s.circle(0.33 + i * 0.11, 0.5 - 0.055, 0.025, 0.025, W_DET * 0.9)
    s.line([(0.56, 0.5 + 0.065), (0.56, 0.5 + 0.14)], W_DET)        # thumb rest


def bassoon(s):
    # long folded bassoon: two parallel joints joined by a boot U at the right,
    # flaring bell at the bottom-left, bocal + reed at the top-left
    s.line([(0.14, 0.32), (0.80, 0.32)], W_MAIN * 1.5)
    s.line([(0.14, 0.44), (0.80, 0.44)], W_MAIN * 1.5)
    s.line([(0.14, 0.56), (0.80, 0.56)], W_MAIN * 1.5)
    s.line([(0.14, 0.68), (0.80, 0.68)], W_MAIN * 1.5)
    # boot
    s.curve(bez((0.80, 0.32), (0.96, 0.32), (0.96, 0.68), (0.80, 0.68)), W_MAIN * 1.5)
    s.curve(bez((0.80, 0.44), (0.885, 0.44), (0.885, 0.56), (0.80, 0.56)), W_DET)
    # bell at the bottom-left
    s.line([(0.14, 0.56), (0.02, 0.47), (0.02, 0.77), (0.14, 0.68)], W_MAIN * 1.5)
    s.line([(0.02, 0.47), (0.02, 0.77)], W_MAIN * 1.5)
    # bocal from the top-left, ending in a forked reed
    s.curve(bez((0.14, 0.38), (0.06, 0.40), (0.05, 0.30), (0.09, 0.26)), W_DET * 2)
    s.line([(0.09, 0.255), (0.17, 0.225)], W_DET)
    s.line([(0.09, 0.255), (0.17, 0.285)], W_DET)
    # key touches
    for i in range(5):
        u = 0.20 + i * 0.115
        s.line([(u, 0.32), (u, 0.27)], W_DET)
    for i in range(3):
        u = 0.30 + i * 0.14
        s.line([(u, 0.68), (u, 0.73)], W_DET)

def horn(s):
    # coiled tubing: bell flaring to the right, mouthpiece on the left
    s.circle(0.40, 0.50, 0.27, 0.31, W_MAIN)
    s.arc(0.40, 0.50, 0.15, 0.19, 40, 320, W_DET)
    # bell on the right side
    s.line([(0.66, 0.42), (0.92, 0.28), (0.92, 0.72), (0.66, 0.58),
            (0.66, 0.42)], W_MAIN, closed=True)
    # mouthpiece on the left side: pipe + cup
    s.line([(0.13, 0.50), (0.05, 0.50)], W_MAIN)
    s.circle(0.04, 0.50, 0.028, 0.045, W_MAIN)

def trumpet(s):
    s.line([(0.5, 0.04), (0.5, 0.40)], W_MAIN)
    s.line([(0.46, 0.04), (0.46, 0.40)], W_DET)
    s.line([(0.54, 0.04), (0.54, 0.40)], W_DET)
    s.rect(0.40, 0.34, 0.60, 0.50, W_MAIN)
    for u in (0.44, 0.50, 0.56):
        s.line([(u, 0.34), (u, 0.50)], W_DET)
    s.line([(0.5, 0.50), (0.5, 0.55)], W_MAIN)
    s.line([(0.5, 0.55), (0.30, 0.96), (0.70, 0.96), (0.5, 0.55)], W_MAIN, closed=True)


def trombone(s):
    s.line([(0.50, 0.06), (0.50, 0.55)], W_MAIN)
    s.line([(0.30, 0.06), (0.70, 0.06)], W_MAIN)
    s.line([(0.30, 0.06), (0.30, 0.10)], W_MAIN)
    s.line([(0.70, 0.06), (0.70, 0.10)], W_MAIN)
    # slide
    s.line([(0.42, 0.40), (0.42, 0.95)], W_MAIN)
    s.line([(0.58, 0.40), (0.58, 0.95)], W_MAIN)
    s.line([(0.42, 0.95), (0.58, 0.95)], W_MAIN)
    s.line([(0.42, 0.62), (0.58, 0.62)], W_DET)
    s.line([(0.42, 0.80), (0.58, 0.80)], W_DET)
    s.line([(0.50, 0.06), (0.58, 0.40)], W_DET)


def tuba(s):
    s.circle(0.44, 0.60, 0.32, 0.34, W_MAIN)
    s.circle(0.44, 0.60, 0.20, 0.22, W_DET)
    s.line([(0.44, 0.26), (0.44, 0.10)], W_MAIN)
    s.line([(0.28, 0.06), (0.60, 0.06)], W_MAIN)
    s.line([(0.28, 0.06), (0.34, 0.20)], W_DET)
    s.line([(0.60, 0.06), (0.54, 0.20)], W_DET)
    s.line([(0.10, 0.60), (0.16, 0.60)], W_MAIN)


# ----------------------------------------------------------------------------- percussion
def timpani(s):
    # a single kettledrum seen from above: rim, head, tuning rods, stand
    s.circle(0.50, 0.50, 0.36, 0.36, W_MAIN)
    s.circle(0.50, 0.50, 0.29, 0.29, W_DET)
    for i in range(6):
        import math as _m
        a = i * _m.pi / 3.0
        x0 = 0.50 + 0.31 * _m.cos(a)
        y0 = 0.50 + 0.31 * _m.sin(a)
        x1 = 0.50 + 0.355 * _m.cos(a)
        y1 = 0.50 + 0.355 * _m.sin(a)
        s.line([(x0, y0), (x1, y1)], W_DET * 1.2)
    s.line([(0.50, 0.86), (0.50, 0.94)], W_DET)
    s.line([(0.40, 0.94), (0.60, 0.94)], W_DET)

def percussion(s):
    # bass drum
    s.circle(0.28, 0.56, 0.24, 0.26, W_MAIN)
    s.circle(0.28, 0.56, 0.10, 0.11, W_DET)
    s.line([(0.28, 0.82), (0.28, 0.94)], W_DET)
    s.line([(0.16, 0.94), (0.40, 0.94)], W_DET)
    # cymbal
    s.arc(0.68, 0.46, 0.26, 0.20, 200, 340, W_MAIN)
    s.line([(0.68, 0.46), (0.68, 0.94)], W_DET)
    s.dot(0.68, 0.46, 0.02)
    # mallets
    s.line([(0.80, 0.10), (0.92, 0.26)], W_DET)


# ----------------------------------------------------------------------------- voice
def person(s, cu, cv, scale=1.0):
    s.circle(cu, cv - 0.16 * scale, 0.085 * scale, 0.085 * scale, W_MAIN)
    s.arc(cu, cv + 0.10 * scale, 0.20 * scale, 0.20 * scale, 180, 360, W_MAIN)
    s.line([(cu - 0.20 * scale, cv + 0.10 * scale),
            (cu + 0.20 * scale, cv + 0.10 * scale)], W_MAIN)


def conductor(s):
    # podium
    s.rect(0.14, 0.70, 0.86, 0.92, W_MAIN)
    # person
    s.circle(0.50, 0.30, 0.075, 0.075, W_MAIN)
    s.arc(0.50, 0.52, 0.20, 0.18, 180, 360, W_MAIN)
    s.line([(0.32, 0.52), (0.68, 0.52)], W_MAIN)
    # baton
    s.line([(0.58, 0.44), (0.86, 0.20)], W_MAIN)
    s.line([(0.54, 0.46), (0.58, 0.44)], W_DET)
    # music stand
    s.line([(0.20, 0.70), (0.20, 0.58)], W_DET)
    s.rect(0.12, 0.50, 0.28, 0.58, W_DET)


def soprano(s):
    person(s, 0.5, 0.55, 1.5)


def tenor(s):
    person(s, 0.5, 0.55, 1.5)


def singer(s):
    # one singer: to build a choir the user places several of these
    person(s, 0.5, 0.55, 1.5)

def bassdrum(s):
    # standing bass drum: round head, shell band, tripod legs
    s.circle(0.50, 0.40, 0.36, 0.36, W_MAIN)
    s.circle(0.50, 0.40, 0.30, 0.30, W_DET)
    s.arc(0.50, 0.58, 0.36, 0.16, 0, 180, W_MAIN)     # shell bottom
    s.line([(0.14, 0.40), (0.14, 0.58)], W_MAIN)
    s.line([(0.86, 0.40), (0.86, 0.58)], W_MAIN)
    s.line([(0.30, 0.72), (0.22, 0.94)], W_MAIN)      # legs
    s.line([(0.70, 0.72), (0.78, 0.94)], W_MAIN)
    s.line([(0.22, 0.94), (0.78, 0.94)], W_MAIN)
    s.line([(0.50, 0.58), (0.50, 0.86)], W_DET)

def snare(s):
    # military snare: shallow shell on a stand, two rims, snare wires
    s.arc(0.50, 0.30, 0.38, 0.15, 0, 360, W_MAIN)
    s.arc(0.50, 0.52, 0.38, 0.15, 0, 360, W_MAIN)
    s.line([(0.12, 0.30), (0.12, 0.52)], W_MAIN)
    s.line([(0.88, 0.30), (0.88, 0.52)], W_MAIN)
    for i in range(5):
        u = 0.20 + i * 0.15
        s.line([(u, 0.345), (u + 0.05, 0.465)], W_DET)   # snare wires
    s.line([(0.50, 0.60), (0.50, 0.70)], W_DET)
    s.line([(0.26, 0.90), (0.74, 0.90)], W_DET)
    s.line([(0.34, 0.66), (0.26, 0.90)], W_DET)
    s.line([(0.66, 0.66), (0.74, 0.90)], W_DET)

def cymbal(s):
    s.circle(0.50, 0.44, 0.38, 0.38, W_MAIN)
    s.circle(0.50, 0.44, 0.11, 0.11, W_DET)
    s.line([(0.50, 0.82), (0.50, 0.95)], W_DET)
    s.line([(0.38, 0.95), (0.62, 0.95)], W_DET)


def xylophone(s):
    s.line([(0.05, 0.30), (0.95, 0.16), (0.95, 0.60), (0.05, 0.74)], W_MAIN, closed=True)
    for i in range(8):
        t = i / 7.0
        x = 0.10 + t * 0.80
        s.line([(x, 0.31 - t * 0.12), (x, 0.73 - t * 0.12)], W_DET)


def glockenspiel(s):
    s.line([(0.04, 0.24), (0.96, 0.24), (0.96, 0.56), (0.04, 0.56)], W_MAIN, closed=True)
    for i in range(10):
        x = 0.08 + i * 0.09
        s.line([(x, 0.26), (x, 0.54)], W_DET)


def gong(s):
    s.circle(0.50, 0.46, 0.42, 0.42, W_MAIN)
    s.circle(0.50, 0.46, 0.35, 0.35, W_DET)
    s.line([(0.50, 0.04), (0.50, 0.11)], W_DET)
    s.circle(0.50, 0.09, 0.04, 0.04, W_DET)


def custom(s):
    s.rect(0.05, 0.05, 0.95, 0.95, W_MAIN * 1.3)


# ----------------------------------------------------------------------------- mics
# ---- stereo technique symbols -----------------------------------------------
def _cardioid(s, cu, cv, rv, ang_deg, w):
    ru = rv * s.H / s.W
    ca = math.cos(math.radians(ang_deg))
    sa = math.sin(math.radians(ang_deg))
    pts = []
    for i in range(49):
        th = i / 48.0 * 2 * math.pi
        r = 0.5 * (1 + math.cos(th))
        x = r * math.cos(th)
        y = r * math.sin(th)
        pts.append((cu + (x * ca - y * sa) * ru, cv + (x * sa + y * ca) * rv))
    s.line(pts, w)


def _fig8(s, cu, cv, rv, ang_deg, w, detail=W_DET):
    ru = rv * s.H / s.W
    ca = math.cos(math.radians(ang_deg))
    sa = math.sin(math.radians(ang_deg))
    for sign in (-1.0, 1.0):
        ox = sign * rv * s.H / s.W * ca
        oy = sign * rv * sa
        s.circle(cu + ox, cv + oy, ru, rv, detail)


def xy(s):
    _cardioid(s, 0.52, 0.52, 0.40, -45, W_MAIN)
    _cardioid(s, 0.48, 0.48, 0.40, 45, W_DET)


def ms(s):
    _cardioid(s, 0.50, 0.50, 0.40, 0, W_MAIN)
    _fig8(s, 0.50, 0.50, 0.22, 90, W_DET)


def blumlein(s):
    _fig8(s, 0.46, 0.50, 0.26, -45, W_MAIN, W_MAIN)
    _fig8(s, 0.54, 0.50, 0.26, 45, W_DET)


def _spaced_pair(s, sep, ang):
    # sep = half capsule spacing in normalised units, ang = capsule half angle
    rv = 0.13
    ru = rv * s.H / s.W
    s.circle(0.5 - sep, 0.64, ru, rv, W_MAIN)
    s.circle(0.5 + sep, 0.64, ru, rv, W_MAIN)
    s.line([(0.5 - sep, 0.64), (0.5 + sep, 0.64)], W_DET)
    rad = math.radians(ang)
    for sign in (-1.0, 1.0):
        cx = 0.5 + sign * sep
        s.line([(cx, 0.51), (cx + sign * math.sin(rad) * 0.34,
                            0.51 - math.cos(rad) * 0.34)], W_MAIN)


def mainmic(s):
    # stereo bar with two capsules and a distinct "M" mark
    rv = 0.15
    ru = rv * s.H / s.W
    s.circle(0.24, 0.66, ru, rv, W_MAIN)
    s.circle(0.76, 0.66, ru, rv, W_MAIN)
    s.line([(0.24, 0.66), (0.76, 0.66)], W_MAIN)
    s.line([(0.24, 0.51), (0.16, 0.36)], W_MAIN)
    s.line([(0.76, 0.51), (0.84, 0.36)], W_MAIN)
    s.line([(0.36, 0.30), (0.36, 0.12), (0.50, 0.25), (0.64, 0.12), (0.64, 0.30)], W_DET)

def ortf(s):
    # 17 cm spacing, +/-55 deg
    _spaced_pair(s, 0.121, 55)


def nos(s):
    # 30 cm spacing, +/-45 deg
    _spaced_pair(s, 0.214, 45)


def din(s):
    # 20 cm spacing, +/-45 deg
    _spaced_pair(s, 0.143, 45)


# ----------------------------------------------------------------------------- mics
def mic(s):
    # capsule circle only; the direction line is a separate darker overlay
    s.circle(0.50, 0.62, 0.21, 0.21, W_MAIN * 1.3)


def micline(s):
    s.line([(0.22, 0.41), (0.78, 0.41)], W_MAIN * 1.3)

def lavalier(s):
    # clip-on lavalier: capsule, clip, cable curl
    s.line([(0.36, 0.16), (0.36, 0.48), (0.64, 0.48), (0.64, 0.16),
            (0.36, 0.16)], W_MAIN * 1.3)
    s.line([(0.36, 0.26), (0.28, 0.26), (0.28, 0.32), (0.36, 0.32)], W_DET * 1.4)
    s.line([(0.36, 0.40), (0.28, 0.40), (0.28, 0.46), (0.36, 0.46)], W_DET * 1.4)
    s.curve(bez((0.50, 0.48), (0.50, 0.62), (0.62, 0.66), (0.70, 0.74)), W_DET * 1.4)
    s.line([(0.70, 0.74), (0.76, 0.82)], W_DET * 1.4)
    for i in range(3):
        s.line([(0.40, 0.22 + i * 0.08), (0.60, 0.22 + i * 0.08)], W_DET * 0.7)

def stereo(s):
    # stereo pair: two capsules joined left-right by a spacing bar
    rv = 0.215
    ru = rv * s.H / s.W
    for cu in (0.26, 0.74):
        s.circle(cu, 0.64, ru, rv, W_MAIN)
        s.line([(cu - 0.07, 0.38), (cu + 0.17, 0.38)], W_MAIN)
    s.line([(0.36, 0.64), (0.64, 0.64)], W_MAIN)
    s.line([(0.36, 0.64), (0.41, 0.59)], W_DET)
    s.line([(0.64, 0.64), (0.59, 0.69)], W_DET)

# ----------------------------------------------------------------------------- catalogue
INSTRUMENTS = [
    # id, zh, en, group, w, h, draw
    ("grand_piano", "三角钢琴", "Grand Piano", "keys", 1.60, 2.70, grand_piano),
    ("harpsichord", "大键琴", "Harpsichord", "keys", 2.10, 1.05, harpsichord),
    ("celesta", "钢片琴", "Celesta", "keys", 1.05, 0.70, celesta),
    ("upright_piano", "立式钢琴", "Upright Piano", "keys", 1.45, 0.55, upright_piano),
    ("violin", "第一小提琴", "Violin I", "strings", 1.05, 0.48, violin),
    ("violin2", "第二小提琴", "Violin II", "strings", 1.05, 0.48, violin),
    ("viola", "中提琴", "Viola", "strings", 1.10, 0.49, viola),
    ("cello", "大提琴", "Cello", "strings", 1.35, 0.64, cello),
    ("bass", "低音提琴", "Double Bass", "strings", 1.65, 0.74, double_bass),
    ("harp", "竖琴", "Harp", "strings", 1.10, 1.45, harp),
    ("flute", "长笛", "Flute", "wood", 1.30, 0.40, flute),
    ("oboe", "双簧管", "Oboe", "wood", 1.15, 0.35, oboe),
    ("clarinet", "单簧管", "Clarinet", "wood", 1.15, 0.40, clarinet),
    ("bassoon", "大管", "Bassoon", "wood", 1.52, 0.45, bassoon),
    ("horn", "圆号", "French Horn", "brass", 0.80, 0.70, horn),
    ("trumpet", "小号", "Trumpet", "brass", 0.50, 0.78, trumpet),
    ("trombone", "长号", "Trombone", "brass", 0.62, 1.03, trombone),
    ("tuba", "大号", "Tuba", "brass", 0.86, 0.86, tuba),
    ("timpani", "定音鼓", "Timpani", "perc", 0.85, 0.85, timpani),
    ("bassdrum", "大鼓", "Bass drum", "perc", 1.10, 1.10, bassdrum),
    ("snare", "军鼓", "Snare drum", "perc", 0.70, 0.70, snare),
    ("cymbal", "钹", "Cymbal", "perc", 0.78, 0.78, cymbal),
    ("xylophone", "木琴", "Xylophone", "perc", 1.30, 0.72, xylophone),
    ("glockenspiel", "钟琴", "Glockenspiel", "perc", 1.00, 0.55, glockenspiel),
    ("gong", "锣", "Gong", "perc", 0.90, 0.90, gong),
    ("percussion", "打击乐", "Percussion", "perc", 1.55, 1.23, percussion),
    ("conductor", "指挥", "Conductor", "voice", 1.02, 1.02, conductor),
    # the two singing characters share the one singer drawing: 独唱歌手 (solo singer)
    # and 合唱歌手 (choir singer — place several to build a choir block)
    ("solo_singer", "独唱歌手", "Solo Singer", "voice", 0.72, 0.72, soprano),
    ("choir_singer", "合唱歌手", "Choir Singer", "voice", 0.72, 0.72, singer),
    ("custom", "自定义", "Custom", "misc", 1.10, 1.10, custom),
]

MICS = [
    ("mainmic", "主话筒", "Main mic", "main"),
    ("mic", "话筒", "Microphone", "mic"),
    ("lavalier", "领夹话筒", "Lavalier", "lavalier"),
    ("ortf", "ORTF", "ORTF", "stereo"),
    ("nos", "NOS", "NOS", "stereo"),
    ("din", "DIN", "DIN", "stereo"),
    ("xy", "XY", "XY", "stereo"),
    ("ms", "MS", "MS", "stereo"),
    ("blumlein", "Blumlein", "Blumlein", "stereo"),
]


def render(w, h, fn, folder, name, flip=False):
    s = S(w, h)
    fn(s)
    mask = s.img.resize((s.W, s.H), Image.LANCZOS)
    if flip:
        mask = mask.transpose(Image.FLIP_LEFT_RIGHT)
    out = Image.new("RGBA", (s.W, s.H), (255, 255, 255, 0))
    out.putalpha(mask)
    os.makedirs(os.path.join(ASSETS, folder), exist_ok=True)
    out.save(os.path.join(ASSETS, folder, name + ".png"))
    if folder in ("instruments", "mics"):
        with open(os.path.join(ASSETS, "vector_icons.txt"), "a", encoding="utf-8") as vf:
            vf.write(f"icon {name} {s.W} {s.H}\n")
            for rec in VECTOR_OUT:
                if rec[0] == "s":
                    pts = " ".join(f"{round(x,5)},{round(y,5)}" for x, y in rec[2])
                    vf.write(f"s {rec[1]:.3f} {pts}\n")
                elif rec[0] == "e":
                    vf.write(f"e {rec[1]:.3f} {rec[2]:.5f} {rec[3]:.5f} {rec[4]:.5f} {rec[5]:.5f}\n")
                else:
                    vf.write(f"a {rec[1]:.3f} {rec[2]:.5f} {rec[3]:.5f} {rec[4]:.5f} {rec[5]:.5f} {rec[6]:.2f} {rec[7]:.2f}\n")
    return out


def make_app_icon():
    # the app mark used in the software's top-left corner: dark tile with the
    # circle + tangent direction line glyph
    N = 1024
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = int(N * 0.02)
    d.rounded_rectangle([pad, pad, N - pad, N - pad], radius=int(N * 0.22),
                        fill=(46, 44, 40, 255))
    wgt = max(2, int(N * 0.042))
    white = (255, 255, 255, 242)
    cx, cy, r = 0.5 * N, 0.60 * N, 0.20 * N
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=white, width=wgt)
    d.line([(cx - 1.38 * r, cy - r), (cx + 1.38 * r, cy - r)], fill=white, width=wgt)
    base = img.resize((256, 256), Image.LANCZOS)
    base.save(os.path.join(ASSETS, "app.png"))
    base.save(os.path.join(ASSETS, "app.ico"), format="ICO",
              sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64),
                     (128, 128), (256, 256)])
    shutil.copyfile(os.path.join(ASSETS, "app.ico"),
                    os.path.join(ROOT, "src", "app.ico"))

def contact_sheet(items):
    cols = 6
    cell = 150
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * cell), (245, 244, 240))
    d = ImageDraw.Draw(sheet)
    for i, (name, img, label) in enumerate(items):
        cx = (i % cols) * cell
        cy = (i // cols) * cell
        thumb = img.copy()
        thumb.thumbnail((cell - 30, cell - 44), Image.LANCZOS)
        rgb = Image.new("RGB", thumb.size, (245, 244, 240))
        rgb.paste(thumb, (0, 0), thumb)
        sheet.paste(rgb, (cx + (cell - thumb.size[0]) // 2,
                          cy + (cell - thumb.size[1]) // 2 - 8))
        d.text((cx + 8, cy + cell - 22), label, fill=(60, 58, 54))
    sheet.save(os.path.join(HERE, "_sheet.png"))


def main():
    items = []
    WSCALE[0] = 1.1
    for (iid, zh, en, grp, w, h, fn) in INSTRUMENTS:
        # EVERY instrument icon: stroke weight ×1.2 (positions/sizes unchanged)
        STROKE_K[0] = 1.2
        img = render(w, h, fn, "instruments", iid, flip=(iid == "violin"))
        items.append((iid, img, zh))
    STROKE_K[0] = 1.0
    render(1.00, 1.00, micline, "mics", "micline")

    WSCALE[0] = 1.5
    mics_fns = {"mainmic": (0.40, 0.35, mainmic), "mic": (1.00, 1.00, mic), "lavalier": (0.60, 0.45, lavalier),
                "ortf": (0.70, 0.50, ortf), "nos": (0.70, 0.50, nos),
                "din": (0.70, 0.50, din), "xy": (0.55, 0.55, xy),
                "ms": (0.55, 0.55, ms), "blumlein": (0.55, 0.55, blumlein)}
    for (mid, zh, en, grp) in MICS:
        w, h, fn = mics_fns[mid]
        # the ORDINARY point microphone reads 1.5× heavier; the lavalier, the
        # intensity-difference pair glyphs and the main-mic symbol keep their weight
        STROKE_K[0] = 1.5 if mid == "mic" else 1.0
        img = render(w, h, fn, "mics", mid)
        items.append((mid, img, zh))
    STROKE_K[0] = 1.0
    make_app_icon()
    contact_sheet(items)
    print("wrote", len(items), "icons")


if __name__ == "__main__":
    main()
