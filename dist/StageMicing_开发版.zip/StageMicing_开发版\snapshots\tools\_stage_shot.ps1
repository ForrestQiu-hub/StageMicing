param(
  [Parameter(Mandatory=$true)][string]$Out,
  [Parameter(Mandatory=$true)][string]$AppArgs,
  [string]$Exe = "E:\Stage Micing Scene\dev\build\Release\StageMicing.exe",
  [int]$SleepMs = 2500
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class StageShotDpi {
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
}
"@
[StageShotDpi]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null

$all = @($AppArgs -split '\s+' | Where-Object { $_ -ne "" })
$p = Start-Process -FilePath $Exe -ArgumentList $all -PassThru
$h = [IntPtr]::Zero
for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 400
    if ($p.HasExited) { throw "app exited, code $($p.ExitCode)" }
    $p.Refresh()
    $h = $p.MainWindowHandle
    if ($h -ne [IntPtr]::Zero) { break }
}
if ($h -eq [IntPtr]::Zero) { throw "no window for pid $($p.Id)" }
Start-Sleep -Milliseconds $SleepMs
$r = New-Object StageShotDpi+RECT
[StageShotDpi]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.R - $r.L; $ht = $r.B - $r.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[StageShotDpi]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc); $g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Stop-Process -Id $p.Id -Force
Write-Output ("saved {0} {1}x{2}" -f $Out, $w, $ht)
