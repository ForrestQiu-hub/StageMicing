"""Compose the measurement proof images for the three stage-symbol fixes.

All coordinates below are IMAGE pixels of the screenshots taken with
tools/shot.ps1 and measured with tools/_measure_scale.py; the metres come from
the ppm that --dump reports for the same zoom.
"""
from PIL import Image, ImageDraw, ImageFont

ARIAL = "C:/Windows/Fonts/arial.ttf"
ARIALB = "C:/Windows/Fonts/arialbd.ttf"
INK = (40, 38, 34)
BACK = (255, 255, 255)
GRID = (222, 217, 208)
ACC = (110, 127, 113)     # theme accent
BAD = (176, 106, 92)


def font(size, bold=False):
    return ImageFont.truetype(ARIALB if bold else ARIAL, size)


def arrow_h(d, x0, x1, y, col, w=2, tick=7):
    d.line([(x0, y), (x1, y)], fill=col, width=w)
    for x in (x0, x1):
        d.line([(x, y - tick), (x, y + tick)], fill=col, width=w)


def scale_bar(d, x, y, ppm, label, col=INK):
    """A 1 m scale bar whose length is the stage grid cell at that zoom."""
    d.line([(x, y), (x + ppm, y)], fill=col, width=2)
    for xx in (x, x + ppm):
        d.line([(xx, y - 6), (xx, y + 6)], fill=col, width=2)
    d.text((x, y + 10), label, font=font(13, True), fill=col)


def mainmic_panel(img, cL, cR, cy, ppm, nominal, drawn_m, ok, note):
    """One annotated crop around the main-mic symbol."""
    half = int(max(abs(cR - cL) * 0.5 + ppm * 0.45, 150))
    cx = int((cL + cR) / 2)
    x0 = max(0, cx - half)
    y0 = max(0, int(cy) - 105)
    crop = img.crop((x0, y0, x0 + 2 * half, y0 + 230)).convert("RGB")
    W, H = crop.size
    canvas = Image.new("RGB", (max(W, 760), 60 + H), BACK)
    canvas.paste(crop, (0, 60))
    d = ImageDraw.Draw(canvas)
    cyx = 60 + (cy - y0)
    mx = lambda v: v - x0

    d.text((10, 8), note, font=font(17, True), fill=INK)
    verdict = "drawn %.3f m for a %.2f m pair  ->  %s" % (
        drawn_m, nominal, "OK" if ok else "WRONG (the 1.6x scale hit the spacing)")
    d.text((10, 32), verdict, font=font(15, True), fill=ACC if ok else BAD)

    d.line([(mx(cL), cyx - 46), (mx(cL), cyx + 46)], fill=ACC, width=2)
    d.line([(mx(cR), cyx - 46), (mx(cR), cyx + 46)], fill=ACC, width=2)
    ax_y = cyx + 62
    arrow_h(d, mx(cL), mx(cR), ax_y, ACC if ok else BAD, 2)
    label = "capsule centre to centre  %.1f px = %.3f m" % (cR - cL, drawn_m)
    tw = d.textlength(label, font=font(14, True))
    d.text((mx(cL) + ((mx(cR) - mx(cL)) - tw) / 2, ax_y + 8), label,
           font=font(14, True), fill=ACC if ok else BAD)
    return canvas


def main():
    ppm5 = 281.2857
    ppm25 = 140.6429

    z5_before = Image.open("tools/_before_z5_main040.png")
    z5_after = Image.open("tools/_after_z5_main040.png")
    z25_before = Image.open("tools/_before_z25_main300.png")
    z25_after = Image.open("tools/_after_z25_main300.png")

    panels = [
        mainmic_panel(z5_before, 798.500, 978.500, 614.55, ppm5, 0.40, 0.6399, False,
                      "BEFORE  —  AB spacing 0.40 m @ zoom 5"),
        mainmic_panel(z5_after, 832.500, 944.905, 614.50, ppm5, 0.40, 0.3996, True,
                      "AFTER  —  AB spacing 0.40 m @ zoom 5"),
        mainmic_panel(z25_before, 551.000, 1226.000, 614.72, ppm25, 3.00, 4.7994, False,
                      "BEFORE  —  AB spacing 3.00 m @ zoom 2.5"),
        mainmic_panel(z25_after, 678.000, 1099.684, 614.62, ppm25, 3.00, 2.9983, True,
                      "AFTER  —  AB spacing 3.00 m @ zoom 2.5"),
    ]
    W = max(p.size[0] for p in panels)
    H = 96 + sum(p.size[1] for p in panels)
    out = Image.new("RGB", (W, H), BACK)
    d = ImageDraw.Draw(out)
    d.text((12, 8), "Bug 1 — the main-mic capsule centre distance must equal it.spacing x ppm",
           font=font(18, True), fill=INK)
    d.text((12, 34), "The 1.6x symbol scale may grow the circles / line art only. "
                     "Scale references (the app's own 1 m grid):",
           font=font(13), fill=INK)
    scale_bar(d, 14, 74, ppm5, "1 m @ zoom 5 = %.1f px" % ppm5)
    scale_bar(d, 360, 74, ppm25, "1 m @ zoom 2.5 = %.1f px" % ppm25)
    y = 96
    for p in panels:
        out.paste(p, (0, y))
        y += p.size[1]
        d.line([(0, y - 1), (W, y - 1)], fill=GRID, width=1)
    out.save("tools/proof_bug1_mainmic_spacing.png")
    print("proof_bug1_mainmic_spacing.png", out.size)

    before = Image.open("tools/_before_z5_points.png").convert("RGB")
    after = Image.open("tools/_after_z5_points.png").convert("RGB")
    px, py = 607.7, 614.3      # point mic at world (6.0, 5.0), zoom 5
    lx, ly = 1003.0, 614.3     # lavalier at world (7.4, 5.0)
    rows = [("point mic  0.3x -> 0.51x   ink box 42x33 px -> 72x56 px  (x1.70)",
             px, py, 120),
            ("lavalier  0.3x1.75 -> 0.51x1.75   ink box 39x40 px -> 67x69 px  (x1.70)",
             lx, ly, 120)]
    rows_img = []
    for label, x, y, half in rows:
        bx0, by0 = int(x - half), int(y - half)
        col = Image.new("RGB", (2 * half * 2 + 34, 2 * half + 74), BACK)
        dd = ImageDraw.Draw(col)
        dd.text((6, 6), label, font=font(13, True), fill=INK)
        for i, src in enumerate((before, after)):
            crop = src.crop((bx0, by0, bx0 + 2 * half, by0 + 2 * half))
            xx = 6 + i * (2 * half + 18)
            col.paste(crop, (xx, 30))
            dd.rectangle([xx, 30, xx + 2 * half - 1, 30 + 2 * half - 1], outline=GRID)
            dd.text((xx, 32 + 2 * half), "BEFORE" if i == 0 else "AFTER",
                    font=font(13, True), fill=BAD if i == 0 else ACC)
        rows_img.append(col)
    W = max(c.size[0] for c in rows_img)
    H = 34 + sum(c.size[1] for c in rows_img)
    out = Image.new("RGB", (W, H), BACK)
    d = ImageDraw.Draw(out)
    d.text((10, 8), "Bug 3 — point-mic symbol x1.7 (same mic, same position)",
           font=font(17, True), fill=INK)
    y = 34
    for c in rows_img:
        out.paste(c, (0, y))
        y += c.size[1]
    out.save("tools/proof_bug3_pointmic_size.png")
    print("proof_bug3_pointmic_size.png", out.size)


if __name__ == "__main__":
    main()
