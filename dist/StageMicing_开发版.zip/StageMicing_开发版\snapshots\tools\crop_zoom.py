# -*- coding: utf-8 -*-
"""Crop a region of a screenshot and upscale it, for "zoom on the fan" shots.

    python tools/crop_zoom.py IN.png OUT.png X0 Y0 X1 Y1 [SCALE]
"""
import sys
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
x0, y0, x1, y1 = (int(v) for v in sys.argv[3:7])
scale = float(sys.argv[7]) if len(sys.argv) > 7 else 2.0
im = Image.open(src).convert("RGB")
crop = im.crop((x0, y0, x1, y1))
crop = crop.resize((int(crop.width * scale), int(crop.height * scale)),
                   Image.LANCZOS)
crop.save(out)
print("saved %s  %dx%d  (crop %d,%d..%d,%d x%.1f)"
      % (out, crop.width, crop.height, x0, y0, x1, y1, scale))
