param(
  [string]$In = "E:\Stage Micing Scene\tools\_acp_zoom25_before.png",
  [string]$Mode = "col",
  [int]$Pos = 326,
  [int]$From = 0,
  [int]$To = 1172,
  [string]$Target = "E5E1D9"
)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($In)
$runs = @()
$inRun = $false
$start = 0
for ($i = $From; $i -le $To; $i++) {
    $c = if ($Mode -eq "col") { $bmp.GetPixel($Pos, $i) } else { $bmp.GetPixel($i, $Pos) }
    $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    $hit = $s -eq $Target
    if ($hit -and -not $inRun) { $inRun = $true; $start = $i }
    elseif (-not $hit -and $inRun) { $inRun = $false; $runs += ("{0}-{1}" -f $start, ($i-1)) }
}
if ($inRun) { $runs += ("{0}-{1}" -f $start, $To) }
Write-Output ("hits of #$Target in {0} {1}: {2}" -f $Mode, $Pos, ($runs -join ", "))
$bmp.Dispose()
