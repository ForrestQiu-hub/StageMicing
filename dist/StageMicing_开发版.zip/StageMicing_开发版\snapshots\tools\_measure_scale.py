"""Measure the drawn microphone symbols in a Stage Micing screenshot.

The main microphone is a procedural symbol: two capsule circles joined by a link
bar, an M mark and (Decca) a centre capsule.  Each capsule ring leaves a sharp
column in the ink mask where the ring turns vertical, and the ink rows at that
column are symmetric about the capsule centre — that is how the symbol is
self-calibrated here (no window-frame offset has to be known):

  * the ink bbox left/right edges are the two capsule outer tangents, so their
    midpoint is the symbol centre (the link bar never reaches past them);
  * the rows of the outermost 3 columns of each side are symmetric about the
    capsule centre row (cy);
  * the TOP arc of each ring is symmetric about its capsule centre in x, so the
    x-centroid of the top ink rows, measured separately left and right of the
    symbol centre, gives the two capsule centres.  The M mark / SRA cone near
    the centre are excluded by a hole of 1.2 x the circle radius.

Point mics are catalogue icons: their drawn ink bounding box is measured.
A Decca centre capsule is measured by the row symmetry of its own ring.

usage: python _measure_scale.py <png> <ppm> <cx> <cy> [--win N] [--points]
                                              [--decca] [--lav CX]
  cx, cy = expected symbol centre in CLIENT coordinates (from --dump, --zoom)
  --win  = half width of the search window in pixels (default 1.6 x ppm + 40)
  --lav  = client x of the lavalier icon (default cx + 1.4 x ppm)
"""
import sys
import numpy as np
from PIL import Image


def load_mask(path, thr=165):
    # the line art is the dark warm mic colour (0x554C42); grid, stage fill and
    # panels are all far lighter, so a plain darkness test isolates the symbol
    a = np.asarray(Image.open(path).convert("RGB")).astype(np.int16)
    return a.max(axis=2) < thr


def arg(name, default, cast=float):
    return cast(sys.argv[sys.argv.index(name) + 1]) if name in sys.argv else default


def main():
    path = sys.argv[1]
    ppm = float(sys.argv[2])
    cx = float(sys.argv[3])
    cy0 = float(sys.argv[4])
    points = "--points" in sys.argv
    mask = load_mask(path)
    H, W = mask.shape
    capR = max(5.0, 0.066 * ppm) * 1.6   # radius of one main-mic capsule circle

    if points:
        print(f"image {W}x{H}  ppm {ppm:.4f}")
        lav = arg("--lav", cx + 1.4 * ppm)
        for name, px in [("point", cx), ("lavalier", lav)]:
            x0, x1 = int(px - 0.95 * ppm), int(px + 0.95 * ppm)
            y0, y1 = int(cy0 - 0.75 * ppm), int(cy0 + 0.75 * ppm)
            x0, y0 = max(0, x0), max(0, y0)
            x1, y1 = min(W, x1), min(H, y1)
            ys, xs = np.nonzero(mask[y0:y1, x0:x1])
            if len(xs) == 0:
                print(f"{name}: no ink")
                continue
            xs = xs + x0
            ys = ys + y0
            w = xs.max() - xs.min() + 1
            h = ys.max() - ys.min() + 1
            print(f"{name}: ink bbox {w} x {h} px = {w/ppm:.3f} x {h/ppm:.3f} m "
                  f"(centre {(xs.min()+xs.max())/2:.1f},{(ys.min()+ys.max())/2:.1f})")
        return

    win = arg("--win", 1.6 * ppm + 40)
    x0, x1 = int(cx - win), int(cx + win)
    y0, y1 = int(cy0 - 120), int(cy0 + 120)
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(W, x1), min(H, y1)
    ys, xs = np.nonzero(mask[y0:y1, x0:x1])
    if len(xs) == 0:
        print("no ink in the measurement window")
        return
    ys = ys + y0
    xs = xs + x0
    xmin, xmax = xs.min(), xs.max()
    mid = (xmin + xmax) / 2.0
    # rows of the outermost columns of each ring are symmetric about its centre
    edge = (xs <= xmin + 3) | (xs >= xmax - 3)
    cy = ys[edge].mean()
    print(f"image {W}x{H}  ppm {ppm:.4f}  window {x0}..{x1} x {y0}..{y1}")
    print(f"symbol centre x {mid:.2f}, capsule centre row {cy:.2f}, "
          f"circle radius {capR:.2f} px")

    if "--decca" in sys.argv:
        # the centre capsule's own ring: take the columns at mid +- capR (the ring
        # turns vertical there, away from the tick / stem) and use their row symmetry
        band = (np.abs(np.abs(xs - mid) - capR) <= 2.5) & (ys < cy - 0.5 * capR)
        if band.sum() < 6:
            print("no Decca centre capsule found above the pair")
            return
        my = ys[band].mean()
        print(f"Decca centre capsule row {my:.2f}  offset {cy - my:.2f} px "
              f"= {(cy - my)/ppm:.4f} m")
        return

    zone = 1.2 * capR
    sel = (np.abs(xs - mid) > zone) & (np.abs(ys - cy) <= capR + 8)
    if sel.sum() < 20:
        print("too few capsule pixels to measure")
        return
    ytop = ys[sel].min()
    print(f"capsule top row {ytop} (cy - top = {cy - ytop:.2f} px)")
    for band in (1, 2, 3):
        s2 = sel & (ys <= ytop + band)
        left, right = xs[s2 & (xs < mid)], xs[s2 & (xs > mid)]
        if len(left) < 3 or len(right) < 3:
            continue
        cL, cR = left.mean(), right.mean()
        print(f"top arc band {band}: capsule centres {cL:.3f} / {cR:.3f} "
              f"(n {len(left)}/{len(right)})  distance {cR - cL:.3f} px "
              f"= {(cR - cL)/ppm:.4f} m")
    s2 = sel & (ys <= ytop + 2)
    left, right = xs[s2 & (xs < mid)], xs[s2 & (xs > mid)]
    if len(left) < 3 or len(right) < 3:
        print("not enough top-arc pixels")
        return
    return (right.mean() - left.mean()) / ppm


if __name__ == "__main__":
    main()
