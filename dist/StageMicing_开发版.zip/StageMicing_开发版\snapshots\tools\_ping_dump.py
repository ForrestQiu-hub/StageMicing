#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarise a StageMicing --dump file: world extents of every object kind."""
import sys


def main(path):
    d = open(path, 'rb').read().decode('utf-16-le', 'replace').splitlines()
    kinds = {}
    for L in d:
        p = L.split()
        if not p:
            continue
        k = p[0]
        try:
            if k == 'devw':
                kinds.setdefault('device', []).append((float(p[2]), float(p[3]), L))
            elif k == 'micw':
                kinds.setdefault('mic', []).append((float(p[2]), float(p[3]), L))
            elif k == 'instw':
                kinds.setdefault('inst', []).append((float(p[2]), float(p[3]), L))
        except (ValueError, IndexError):
            pass
    for k, v in kinds.items():
        xs = [a for a, b, c in v]
        ys = [b for a, b, c in v]
        print(f"{k}: n={len(v)} x=[{min(xs):.3f},{max(xs):.3f}] y=[{min(ys):.3f},{max(ys):.3f}]")
        for a, b, c in v:
            if a < -0.5 or b < -0.5 or a > 18.5 or b > 18.5:
                print("   OUT:", c)
    print("--- non-object lines ---")
    for L in d:
        if L.split() and L.split()[0] not in ('devw', 'micw', 'instw', 'cap', 'mic', 'inst',
                                               'dev', 'micdef', 'micshape', 'micradius',
                                               'micspot', 'instlabel', 'tile', 'add', 'row',
                                               'route', 'routedel', 'routelink', 'filerow',
                                               'stagepreset'):
            print("   ", L[:240])


if __name__ == "__main__":
    main(sys.argv[1])
