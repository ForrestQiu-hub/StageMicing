"""Crops of the two 05/02 screenshots plus a palette proof sheet.

Reads tools/_color_table.txt (written by `StageMicing.exe --dump-colors`) so the
sheet is built from the app's own numbers, not from a copy of the palette.
Outputs (all in tools/):
  _palette_02_stage_crop.png   02 乐器摆位 plot, 2x
  _palette_05_cabling_crop.png 布线 plot, 2x
  _palette_sheet.png           every ordered id: icon chip + ink chip + hex
"""

import os

from PIL import Image, ImageDraw, ImageFont

TOOLS = r"E:\Stage Micing Scene\tools"


def font(px, bold=False):
    for name in ((r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\arialbd.ttf") if bold
                 else (r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\arial.ttf")):
        if os.path.exists(name):
            try:
                return ImageFont.truetype(name, px)
            except OSError:
                pass
    return ImageFont.load_default()


# ------------------------------------------------------------------- crops
for src, dst, box in (
    ("_palette_02_stage.png", "_palette_02_stage_crop.png", (430, 300, 1245, 800)),
    ("_palette_05_cabling.png", "_palette_05_cabling_crop.png", (430, 380, 1245, 830)),
):
    im = Image.open(os.path.join(TOOLS, src)).convert("RGB")
    w, h = im.size
    box = (max(0, box[0]), max(0, box[1]), min(w, box[2]), min(h, box[3]))
    crop = im.crop(box)
    crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    crop.save(os.path.join(TOOLS, dst))
    print("wrote", dst, crop.size)

# --------------------------------------------------------------- proof sheet
rows = []
with open(os.path.join(TOOLS, "_color_table.txt"), encoding="utf-8") as f:
    for line in f:
        parts = line.split()
        if len(parts) >= 6 and parts[0].isdigit():
            rows.append((int(parts[0]), parts[1], parts[2], parts[3],
                         float(parts[4]), float(parts[5])))

pad, chip, gap = 16, 44, 12
colw = 330
rowh = chip + gap + 18
cols = 2
per_col = (len(rows) + cols - 1) // cols
f_title = font(24, True)
f_id = font(17, True)
f_small = font(14)
W = pad * 2 + colw * cols
H = pad * 2 + 72 + per_col * rowh
_probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
_want = _probe.textlength("MutedColor palette — 40 entries, 38 ids, no shared tint / ink",
                          font=f_title)
W = max(W, int(_want) + pad * 2)
sheet = Image.new("RGB", (W, H), "white")
d = ImageDraw.Draw(sheet)

d.text((pad, pad), "MutedColor palette — 40 entries, 38 ids, no shared tint / ink",
       font=f_title, fill=(30, 30, 30))
d.text((pad, pad + 32), "icon = StageMutedColor(defId) — the 01/02 icon tint",
       font=f_small, fill=(90, 90, 90))
d.text((pad, pad + 50),
       "ink = MicInkLine(icon) — cable / marker / tag ink (Rec.601 Y capped at 104)",
       font=f_small, fill=(90, 90, 90))
d.text((pad, pad + 68),
       "keyboard family = slots 0..3 (grand_piano draws pr.instColor instead)",
       font=f_small, fill=(90, 90, 90))

for i, (slot, name, icon, ink, iy, ky) in enumerate(rows):
    cx = pad + (i // per_col) * colw
    cy = pad + 82 + (i % per_col) * rowh
    d.text((cx, cy), "%2d  %s" % (slot, name), font=f_id, fill=(25, 25, 25))
    top = cy + 22
    d.rectangle([cx, top, cx + chip - 1, top + chip - 1], fill=icon)
    d.rectangle([cx, top, cx + chip - 1, top + chip - 1], outline=(190, 190, 190))
    d.text((cx + chip + 6, top + 2), icon, font=f_small, fill=(60, 60, 60))
    d.text((cx + chip + 6, top + 20), "Y %.0f" % iy, font=f_small, fill=(120, 120, 120))
    x2 = cx + chip + 78
    d.rectangle([x2, top, x2 + chip - 1, top + chip - 1], fill=ink)
    d.rectangle([x2, top, x2 + chip - 1, top + chip - 1], outline=(190, 190, 190))
    d.text((x2 + chip + 6, top + 2), ink, font=f_small, fill=(60, 60, 60))
    d.text((x2 + chip + 6, top + 20), "Y %.0f" % ky, font=f_small, fill=(120, 120, 120))

sheet.save(os.path.join(TOOLS, "_palette_sheet.png"))
print("wrote _palette_sheet.png", sheet.size, "rows", len(rows))
