param(
  [string]$In = "E:\Stage Micing Scene\tools\_acp_sel.png",
  [int]$X = 420,
  [int]$Y0 = 0,
  [int]$Y1 = 300
)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($In)
$prev = ""
$start = $Y0
for ($y = $Y0; $y -le $Y1; $y++) {
    $c = $bmp.GetPixel($X, $y)
    $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    if ($s -ne $prev) {
        if ($prev -ne "") { Write-Output ("y {0}-{1} = #{2}" -f $start, ($y-1), $prev) }
        $prev = $s; $start = $y
    }
}
Write-Output ("y {0}-{1} = #{2}" -f $start, $Y1, $prev)
$bmp.Dispose()
