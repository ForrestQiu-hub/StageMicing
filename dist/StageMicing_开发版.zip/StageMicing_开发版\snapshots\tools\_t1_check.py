# -*- coding: utf-8 -*-
# Item 1 verification: the PNG header band is 8x, the text lives inside the band
# and the 1 m grid starts right below the band (never under the header text).
import io
import sys
from PIL import Image

ROOT = r"E:\Stage Micing Scene"
png = sys.argv[1] if len(sys.argv) > 1 else ROOT + r"\tools\_t1_hdr8.png"
diag = sys.argv[2] if len(sys.argv) > 2 else ROOT + r"\tools\_t1_diag.txt"

lines = io.open(diag, "rb").read().decode("utf-16-le").splitlines()
band = [l for l in lines if l.startswith("band ")][0].split()
headerPx = int(band[band.index("headerPx") + 1])
pad = int(band[band.index("pad") + 1])
print("diag: headerPx", headerPx, "pad", pad)

im = Image.open(png).convert("RGB")
W, H = im.size
print("png", W, "x", H)
px = im.load()
bandBottom = pad + headerPx
print("band bottom row:", bandBottom)

# grid colour theme::kGrid = 0xE5E1D9 drawn on the off-stage / stage paper
GRID = (0xE5, 0xE1, 0xD9)
GRIDD = 10


def isDark(c, t=140):
    return (c[0] + c[1] + c[2]) / 3.0 < t


def isGrid(c):
    return all(abs(c[i] - GRID[i]) <= GRIDD for i in range(3))


# --- 1) header text ink rows: dark pixels in x = [pad, W-pad) -----------------
rows = []
for y in range(bandBottom + 40):
    dark = 0
    for x in range(pad, W - pad, 2):
        if isDark(px[x, y]):
            dark += 1
            if dark > 3:
                break
    if dark > 3:
        rows.append(y)
if rows:
    print("header text rows: %d..%d (%d rows of ink)" % (min(rows), max(rows), len(rows)))
    # split into line groups (gap >= 6 rows)
    groups = []
    start = prev = rows[0]
    for y in rows[1:]:
        if y - prev > 6:
            groups.append((start, prev))
            start = y
        prev = y
    groups.append((start, prev))
    for i, (a, b) in enumerate(groups):
        print("  line%d ink y %d..%d  height %d px" % (i + 1, a, b, b - a + 1))
    print("header text inside band:", max(rows) < bandBottom)
else:
    print("header text rows: NONE")

# --- 2) grid: first row below the band that carries kGrid pixels -------------
firstGrid = None
for y in range(bandBottom, min(H, bandBottom + 400)):
    n = 0
    for x in range(pad, W - pad, 3):
        if isGrid(px[x, y]):
            n += 1
            if n > 30:
                break
    if n > 30:
        firstGrid = y
        break
print("first 1 m grid row below band:", firstGrid)
# are there grid pixels inside the band (header area)?
inside = 0
for y in range(0, bandBottom):
    for x in range(pad, W - pad, 3):
        if isGrid(px[x, y]):
            inside += 1
            break
print("grid pixels inside band rows:", inside)

# --- 3) band pixels: exact off-stage fill? -----------------------------------
OFF = (0xEF, 0xEC, 0xE5)
bad = 0
for y in range(0, bandBottom):
    for x in range(0, W, 5):
        c = px[x, y]
        if not isDark(c, 240) and not all(abs(c[i] - OFF[i]) <= 6 for i in range(3)):
            bad += 1
            if bad > 200:
                break
print("band non-paper / non-ink samples:", bad)
