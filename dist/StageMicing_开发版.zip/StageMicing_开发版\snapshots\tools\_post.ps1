param(
    [int[]]$Clicks = @(),      # flat list of CLIENT x,y pairs
    [int]$Right = 0,           # 1 = right button instead of left
    [string]$Out = "E:\Stage Micing Scene\tools\_post.png",
    [int]$Keys = 0             # optional VK to send after the clicks (27 = Esc)
)
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Post {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "SendMessageW")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
}
'@
try { [Post]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}
$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
$WM_MOUSEMOVE = 0x0200
$WM_LBUTTONDOWN = 0x0201
$WM_LBUTTONUP = 0x0202
$WM_RBUTTONDOWN = 0x0204
$WM_RBUTTONUP = 0x0205
$WM_KEYDOWN = 0x0100
$WM_KEYUP = 0x0101
for ($i = 0; $i + 1 -lt $Clicks.Count; $i += 2) {
    $x = $Clicks[$i]; $y = $Clicks[$i + 1]
    $lp = [IntPtr](($y -shl 16) -bor ($x -band 0xFFFF))
    [Post]::SendMessage($h, $WM_MOUSEMOVE, [IntPtr]::Zero, $lp) | Out-Null
    Start-Sleep -Milliseconds 60
    if ($Right -eq 1) {
        [Post]::SendMessage($h, $WM_RBUTTONDOWN, [IntPtr]2, $lp) | Out-Null
        Start-Sleep -Milliseconds 40
        [Post]::SendMessage($h, $WM_RBUTTONUP, [IntPtr]0, $lp) | Out-Null
    } else {
        [Post]::SendMessage($h, $WM_LBUTTONDOWN, [IntPtr]1, $lp) | Out-Null
        Start-Sleep -Milliseconds 40
        [Post]::SendMessage($h, $WM_LBUTTONUP, [IntPtr]0, $lp) | Out-Null
    }
    Start-Sleep -Milliseconds 260
}
if ($Keys -ne 0) {
    [Post]::SendMessage($h, $WM_KEYDOWN, [IntPtr]$Keys, [IntPtr]1) | Out-Null
    Start-Sleep -Milliseconds 40
    [Post]::SendMessage($h, $WM_KEYUP, [IntPtr]$Keys, [IntPtr]0xC0000001) | Out-Null
    Start-Sleep -Milliseconds 300
}
Start-Sleep -Milliseconds 200
$wr = New-Object Post+RECT
[Post]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L; $ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[Post]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc); $g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out ${w}x${ht}"
