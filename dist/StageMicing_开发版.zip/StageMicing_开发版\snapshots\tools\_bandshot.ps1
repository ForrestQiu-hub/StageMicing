﻿param(
    [string]$Drag = "620,380,760,480",   # x1,y1,x2,y2 in CLIENT coordinates
    [string]$Out = "E:\Stage Micing Scene\tools\_shot_band.png",
    [string]$ExeArgs = "--preset 2"
)
$D = @($Drag.Split(",") | ForEach-Object { [int]$_ })
# Rubber-band screenshot: real mouse press + move (the band is still live), grab
# the window with PrintWindow, then release so no capture is left dangling.
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class BandShot {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
}
'@
try { [BandShot]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Process -FilePath "E:\Stage Micing Scene\build\Release\StageMicing.exe" -ArgumentList $ExeArgs -WorkingDirectory "E:\Stage Micing Scene"
Start-Sleep -Seconds 3
$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
[BandShot]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 500

$origin = New-Object BandShot+POINT
[BandShot]::ClientToScreen($h, [ref]$origin) | Out-Null

function MoveTo($cx, $cy) {
    [BandShot]::SetCursorPos($origin.X + $cx, $origin.Y + $cy) | Out-Null
    Start-Sleep -Milliseconds 120
}

MoveTo $D[0] $D[1]
[BandShot]::mouse_event(2, 0, 0, 0, [IntPtr]::Zero)   # left down
Start-Sleep -Milliseconds 150
# a few intermediate moves, so the drag is a real gesture
for ($s = 1; $s -le 4; $s++) {
    $cx = [int]($D[0] + ($D[2] - $D[0]) * $s / 4)
    $cy = [int]($D[1] + ($D[3] - $D[1]) * $s / 4)
    MoveTo $cx $cy
}
Start-Sleep -Milliseconds 400

$wr = New-Object BandShot+RECT
[BandShot]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L
$ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[BandShot]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

# release the button so the app is left in a settled state
[BandShot]::mouse_event(4, 0, 0, 0, [IntPtr]::Zero)
Start-Sleep -Milliseconds 300
Write-Output "saved $Out ${w}x${ht}"



