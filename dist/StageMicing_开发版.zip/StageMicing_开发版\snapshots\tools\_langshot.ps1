# launch StageMicing with args, resize the client to W x H, PrintWindow to a PNG.
# ASCII only (no BOM).  Example:
#   pwsh -File _langshot.ps1 -Out out.png -Args '--de --click 1400 32' -ClientW 1400 -ClientH 900
param(
    [string]$Out = "E:\Stage Micing Scene\dev\tmp_pngfix\_lang.png",
    [string]$Exe = "E:\Stage Micing Scene\dev\build\Release\StageMicing.exe",
    [string]$Arguments = "",
    [int]$ClientW = 0,
    [int]$ClientH = 0,
    [int]$Wait = 1500
)

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class LW {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hh, bool repaint);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
    [DllImport("user32.dll")] public static extern bool UpdateWindow(IntPtr h);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindowW(string cls, string title);
}
'@
Add-Type -AssemblyName System.Drawing
try { [LW]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch { }

$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if ($proc) { $proc.Kill(); Start-Sleep -Milliseconds 400 }

if ($Arguments -eq "") {
    $proc = Start-Process -FilePath $Exe -PassThru
} else {
    $proc = Start-Process -FilePath $Exe -ArgumentList $Arguments -PassThru
}
Start-Sleep -Milliseconds $Wait
$proc.Refresh()
if ($proc.HasExited) { Write-Output ("process exited " + $proc.ExitCode); exit 1 }
$h = [LW]::FindWindowW("StageMicingWnd", $null)
if ($h -eq [IntPtr]::Zero) { $h = $proc.MainWindowHandle }
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; $proc.Kill(); exit 1 }

[LW]::ShowWindow($h, 9) | Out-Null
[LW]::SetForegroundWindow($h) | Out-Null

if ($ClientW -gt 0 -and $ClientH -gt 0) {
    # grow the window until the CLIENT area is exactly W x H
    $cr = New-Object LW+RECT
    [LW]::GetClientRect($h, [ref]$cr) | Out-Null
    $wr = New-Object LW+RECT
    [LW]::GetWindowRect($h, [ref]$wr) | Out-Null
    $dw = ($wr.Right - $wr.Left) - ($cr.Right - $cr.Left)
    $dh = ($wr.Bottom - $wr.Top) - ($cr.Bottom - $cr.Top)
    [LW]::MoveWindow($h, $wr.Left, $wr.Top, $ClientW + $dw, $ClientH + $dh, $true) | Out-Null
    Start-Sleep -Milliseconds 500
}

Start-Sleep -Milliseconds 400
$r = New-Object LW+RECT
[LW]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.Right - $r.Left
$ht = $r.Bottom - $r.Top
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
[LW]::PrintWindow($h, $hdc, 2) | Out-Null
$g.ReleaseHdc($hdc)
$g.Dispose()
$dir = Split-Path -Parent $Out
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

$cr2 = New-Object LW+RECT
[LW]::GetClientRect($h, [ref]$cr2) | Out-Null
Write-Output ("saved " + $Out + " win " + $w + "x" + $ht + " client " + ($cr2.Right - $cr2.Left) + "x" + ($cr2.Bottom - $cr2.Top))
$proc.Kill()
Start-Sleep -Milliseconds 200
