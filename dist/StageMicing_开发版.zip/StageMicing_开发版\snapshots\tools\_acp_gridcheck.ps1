$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
$path = "E:\Stage Micing Scene\tools\_acp_v_zoom25_pan.png"
$bmp = [System.Drawing.Bitmap]::FromFile($path)
$grid = 0; $panel = 0
# left panel band (x 20..330, y 120..1100) must be panel colours only
for ($y = 120; $y -lt 1100; $y += 2) {
    for ($x = 20; $x -lt 330; $x += 2) {
        $c = $bmp.GetPixel($x, $y)
        $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
        if ($s -eq "E5E1D9" -or $s -eq "EAE7DF") { $grid++ }
        if ($s -eq "FAF9F6") { $panel++ }
    }
}
"left-panel band samples: grid=$grid panel=$panel"
$grid2 = 0; $top2 = 0
for ($y = 0; $y -lt 108; $y += 2) {
    for ($x = 340; $x -lt 1380; $x += 2) {
        $c = $bmp.GetPixel($x, $y)
        $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
        if ($s -eq "E5E1D9" -or $s -eq "EAE7DF") { $grid2++ }
        if ($s -eq "FAF9F6") { $top2++ }
    }
}
"top-bar band samples: grid=$grid2 white=$top2"
# inside the canvas: the grid must still be present
$grid3 = 0
for ($y = 200; $y -lt 900; $y += 2) {
    for ($x = 400; $x -lt 1360; $x += 2) {
        $c = $bmp.GetPixel($x, $y)
        $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
        if ($s -eq "E5E1D9" -or $s -eq "EAE7DF") { $grid3++ }
    }
}
"canvas band samples: grid=$grid3"
$bmp.Dispose()
