# -*- coding: utf-8 -*-
"""Compare two --dump-layout dumps on DIFFERENT stage sizes and report how far
every instrument moved in metres, plus the ensemble centroid before / after.

    python tools/fit_delta.py A.txt WA DA B.txt WB DB

Used to prove the "the ensemble stays centred when the stage size changes" rule:
the preset rows are normalised, so a stage resize must translate the world
positions by half the size delta, not scale them.
"""
import io
import re
import sys

ROW = re.compile(r'\s*\{\s*L"([a-z0-9_]+)"\s*,\s*(-?[0-9.]+)\s*,\s*(-?[0-9.]+)\s*,'
                 r'\s*(-?[0-9.]+)\s*\}')


def rows(path, w, d):
    out = []
    for ln in io.open(path, encoding="utf-8"):
        m = ROW.match(ln)
        if m:
            out.append((m.group(1), float(m.group(2)) * w, float(m.group(3)) * d,
                        float(m.group(4))))
    return out


def main():
    a = rows(sys.argv[1], float(sys.argv[2]), float(sys.argv[3]))
    b = rows(sys.argv[4], float(sys.argv[5]), float(sys.argv[6]))
    print("A: %d rows on %s x %s   B: %d rows on %s x %s"
          % (len(a), sys.argv[2], sys.argv[3], len(b), sys.argv[5], sys.argv[6]))
    if len(a) != len(b):
        raise SystemExit("row count differs: %d vs %d" % (len(a), len(b)))
    dx = [q[1] - p[1] for p, q in zip(a, b)]
    dy = [q[2] - p[2] for p, q in zip(a, b)]
    print("dx  %.3f .. %.3f   (mean %.3f)" % (min(dx), max(dx), sum(dx) / len(dx)))
    print("dy  %.3f .. %.3f   (mean %.3f)" % (min(dy), max(dy), sum(dy) / len(dy)))
    ca = (sum(p[1] for p in a) / len(a), sum(p[2] for p in a) / len(a))
    cb = (sum(q[1] for q in b) / len(b), sum(q[2] for q in b) / len(b))
    print("centroid A (%.2f, %.2f)   B (%.2f, %.2f)   delta (%+.2f, %+.2f)"
          % (ca[0], ca[1], cb[0], cb[1], cb[0] - ca[0], cb[1] - ca[1]))
    worst = max(abs(p[3] - q[3]) for p, q in zip(a, b))
    print("largest facing-angle change %.1f deg" % worst)


main()
