param(
  [int]$Layer = 1,
  [int]$Sel = 2,
  [string]$Tag = "L1",
  [switch]$ClickField
)
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class WheelT {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindowW(string cls, string title);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, int dx, int dy, int d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern IntPtr GetDlgItem(IntPtr parent, int id);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool ScreenToClient(IntPtr h, ref POINT p);
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
}
'@
try { [WheelT]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch { }

$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"
$dir = "E:\Stage Micing Scene\tools"
# a dying instance still owns its window: kill and WAIT, otherwise FindWindowW can
# hand back a half-destroyed HWND whose rect is empty
Get-Process StageMicing -ErrorAction SilentlyContinue | ForEach-Object {
    $_ | Stop-Process -Force
    try { $_.WaitForExit(4000) | Out-Null } catch { }
}
Start-Sleep -Milliseconds 600
$proc = Start-Process -FilePath $exe -ArgumentList @("--layer", "$Layer", "--select", "$Sel") -PassThru
$h = [IntPtr]::Zero
for ($try = 0; $try -lt 60 -and $h -eq [IntPtr]::Zero; $try++) {
    Start-Sleep -Milliseconds 300
    $proc.Refresh()
    if ($proc.HasExited) { Write-Output "app exited early"; exit 1 }
    if ($proc.MainWindowHandle -ne [IntPtr]::Zero) { $h = $proc.MainWindowHandle }
}
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }
$r = New-Object WheelT+RECT
for ($try = 0; $try -lt 30; $try++) {
    [WheelT]::GetWindowRect($h, [ref]$r) | Out-Null
    if (($r.Right - $r.Left) -gt 400 -and ($r.Bottom - $r.Top) -gt 400) { break }
    Start-Sleep -Milliseconds 200
}
$w = $r.Right - $r.Left; $ht = $r.Bottom - $r.Top
Write-Output "window ${w}x${ht} at $($r.Left),$($r.Top)"
if ($w -le 400 -or $ht -le 400) { Write-Output "bad window rect"; exit 1 }
[WheelT]::SetForegroundWindow($h) | Out-Null

function Shot([string]$path) {
    $bmp = New-Object System.Drawing.Bitmap $w, $ht
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $g.GetHdc()
    [WheelT]::PrintWindow($h, $hdc, 2) | Out-Null
    $g.ReleaseHdc($hdc); $g.Dispose()
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
}

# dump the inspector EDIT rects, in client coordinates
function Fields() {
    $ids = @(100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,124,125,126,127,128)
    $outLines = @()
    foreach ($id in $ids) {
        $e = [WheelT]::GetDlgItem($h, $id)
        if ($e -eq [IntPtr]::Zero) { continue }
        if (-not [WheelT]::IsWindowVisible($e)) { $outLines += "$id hidden"; continue }
        $er = New-Object WheelT+RECT
        if (-not [WheelT]::GetWindowRect($e, [ref]$er)) {
            $outLines += "$id query-failed"
            continue
        }
        $p1 = New-Object WheelT+POINT; $p1.X = $er.Left; $p1.Y = $er.Top
        $p2 = New-Object WheelT+POINT; $p2.X = $er.Right; $p2.Y = $er.Bottom
        [WheelT]::ScreenToClient($h, [ref]$p1) | Out-Null
        [WheelT]::ScreenToClient($h, [ref]$p2) | Out-Null
        $outLines += ("{0} {1} {2} {3} {4}" -f $id, $p1.X, $p1.Y, $p2.X, $p2.Y)
    }
    return $outLines
}

Shot "$dir\_st_${Tag}_0.png"
Fields | Set-Content -Path "$dir\_st_${Tag}_0.txt" -Encoding ASCII

# put the cursor over the middle of the right inspector and scroll with the real wheel.
# The client rect (not the window rect) is what the layout uses, and the wheel is
# routed by the point: 86 % of the CLIENT width is inside the inspector panel.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class WheelC {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
}
'@
$cr = New-Object WheelC+RECT
[WheelC]::GetClientRect($h, [ref]$cr) | Out-Null
$cwPix = $cr.Right - $cr.Left
$chPix = $cr.Bottom - $cr.Top
$pt = New-Object WheelC+POINT
$pt.X = [int]($cwPix * 0.86); $pt.Y = [int]($chPix * 0.55)
[WheelC]::ClientToScreen($h, [ref]$pt) | Out-Null
$cx = $pt.X; $cy = $pt.Y

# the app must own the FOCUS, otherwise the wheel goes to whatever window has it:
# a plain left click on empty inspector space only sets focus (no control there)
$pt2 = New-Object WheelC+POINT
$pt2.X = [int]($cwPix * 0.96); $pt2.Y = [int]($chPix * 0.96)
[WheelC]::ClientToScreen($h, [ref]$pt2) | Out-Null
[WheelT]::SetCursorPos($pt2.X, $pt2.Y) | Out-Null
Start-Sleep -Milliseconds 200
[WheelT]::mouse_event(0x0002, 0, 0, 0, [IntPtr]::Zero)
[WheelT]::mouse_event(0x0004, 0, 0, 0, [IntPtr]::Zero)
Start-Sleep -Milliseconds 250
[WheelT]::SetCursorPos($cx, $cy) | Out-Null
Start-Sleep -Milliseconds 200
Write-Output "wheel point $cx,$cy (client $cwPix x $chPix)"

if ($ClickField) {
    # a click into the 演出场馆 EDIT (id 101), so the wheel arrives with a focused field
    $e101 = [WheelT]::GetDlgItem($h, 101)
    $er = New-Object WheelT+RECT
    [WheelT]::GetWindowRect($e101, [ref]$er) | Out-Null
    $mp = New-Object WheelT+POINT
    $mp.X = [int](($er.Left + $er.Right) / 2); $mp.Y = [int](($er.Top + $er.Bottom) / 2)
    [WheelT]::SetCursorPos($mp.X, $mp.Y) | Out-Null
    Start-Sleep -Milliseconds 150
    [WheelT]::mouse_event(0x0002, 0, 0, 0, [IntPtr]::Zero)   # left down
    [WheelT]::mouse_event(0x0004, 0, 0, 0, [IntPtr]::Zero)   # left up
    Start-Sleep -Milliseconds 200
    [WheelT]::SetCursorPos($cx, $cy) | Out-Null
    Start-Sleep -Milliseconds 150
}

$script:prevFields = (Fields) -join "`n"
function Wheel([int]$n) {
    for ($i = 0; $i -lt [math]::Abs($n); $i++) {
        [WheelT]::mouse_event(0x0800, 0, 0, $(if ($n -gt 0) { -120 } else { 120 }), [IntPtr]::Zero)
        Start-Sleep -Milliseconds 90
    }
    Start-Sleep -Milliseconds 300
    # The wheel is routed to the window with the FOCUS; if the app lost it nothing
    # scrolled — post the identical message to the window instead and say so.
    $now = (Fields) -join "`n"
    if ($now -eq $script:prevFields) {
        Write-Output "  (no wheel effect: re-sending WM_MOUSEWHEEL with SendMessage)"
        $delta = $(if ($n -gt 0) { -120 } else { 120 })
        $lp = [IntPtr](($cy -shl 16) -bor ($cx -band 0xFFFF))
        for ($i = 0; $i -lt [math]::Abs($n); $i++) {
            [WheelT]::SendMessageW($h, 0x020A, [IntPtr]($delta -shl 16), $lp) | Out-Null
            Start-Sleep -Milliseconds 90
        }
        Start-Sleep -Milliseconds 300
        $now = (Fields) -join "`n"
    }
    $script:prevFields = $now
}

Wheel 3
Shot "$dir\_st_${Tag}_200.png"
Fields | Set-Content -Path "$dir\_st_${Tag}_200.txt" -Encoding ASCII
Wheel 3
Shot "$dir\_st_${Tag}_400.png"
Fields | Set-Content -Path "$dir\_st_${Tag}_400.txt" -Encoding ASCII
Wheel -6
Shot "$dir\_st_${Tag}_back.png"
Fields | Set-Content -Path "$dir\_st_${Tag}_back.txt" -Encoding ASCII

Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force

# pixel diff: 0 vs back.  Fast path: identical PNG bytes (the window is painted
# into an off-screen buffer, so an unchanged state encodes identically).  Slow
# path: a column-restricted GetPixel diff over the inspector panel.
$ha = (Get-FileHash "$dir\_st_${Tag}_0.png" -Algorithm SHA256).Hash
$hb = (Get-FileHash "$dir\_st_${Tag}_back.png" -Algorithm SHA256).Hash
if ($ha -eq $hb) {
    Write-Output "screenshots after scroll-back are BYTE IDENTICAL ($ha)"
} else {
    Write-Output "screenshots differ, counting pixels ($ha vs $hb)"
    $b0 = New-Object System.Drawing.Bitmap "$dir\_st_${Tag}_0.png"
    $b1 = New-Object System.Drawing.Bitmap "$dir\_st_${Tag}_back.png"
    $x0 = [int]($b0.Width * 0.6)
    $n = 0
    for ($y = 0; $y -lt $b0.Height; $y++) {
        for ($x = $x0; $x -lt $b0.Width; $x++) {
            if ($b0.GetPixel($x, $y).ToArgb() -ne $b1.GetPixel($x, $y).ToArgb()) { $n++ }
        }
    }
    $b0.Dispose(); $b1.Dispose()
    Write-Output "differing pixels in the inspector columns: $n"
}
$r0 = Get-Content "$dir\_st_${Tag}_0.txt"
$rb = Get-Content "$dir\_st_${Tag}_back.txt"
if (Compare-Object $r0 $rb) {
    Write-Output "EDIT rects DIFFER after scrolling back:"
    Compare-Object $r0 $rb | Format-Table -AutoSize | Out-String | Write-Output
} else {
    Write-Output "EDIT rects identical after scrolling back ($($r0.Count) controls)"
}
