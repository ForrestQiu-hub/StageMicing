# 工作状态存档（2026-11-09 11:15）

## 构建与产物
- 源码：`src/`（16 个文件，C++20 / Win32 / GDI+，`/utf-8`）
- 构建：`build/`（CMake + MSVC），命令
  `"D:\Program Files\Microsoft Visual Studio\18\Community\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe" --build "E:\Stage Micing Scene\build" --config Release`
- 可执行：`StageMicing.exe`（根目录，11:11 版）＋ `build\Release\StageMicing.exe`
- **备份**：`backup_20261109_1115\`（src / assets / docs / CMakeLists.txt / README.md / exe）

## 当前功能状态
- 页签（6 页，重构已入代码，验收中）：01 项目信息 / 02 乐器摆位 / 03 话筒摆位 / 04 通道表 / 05 拓扑图 / 06 布线
- 舞台：乐器/话筒图标（点话筒 0.3×、主话筒程序绘制 1.6×、无斜线）、舞台内网格已修「溢出到素材栏/顶栏」
- 布线：右键连线（排异矩阵）、无线虚线无长度、删除需确认、线缆标签避让、先竖后横直连（不绕路）、后半台允许 45°
- 长度：05 为实长；03/04/PDF 为标准档向上取整（5/8/10/12/15/18/20/25/30）；可人工输入并标「自定义」；吊装四段（上升/吊顶/沿墙/地面）
- 文件：`.smproj` 保存/打开；旧文件兼容（数字箱→接口箱，ADDA 丢弃）
- 语言：中/英/德/法
- PDF：舞台图 01、通道表 03 均可导出

## 待办 / 进行中
1. 重构代理（5ba37083）正在做 GUI 自查：六页签与 `--layer` 映射、属性栏「标签/框不重叠 + 免滚动」审计、P1/03/2.5× 三张截图 —— **未回报**
2. 右栏滚动重影：本轮已修（控件创建即隐藏、ShowWindow 后立即 Layout、控件窗口区域按面板裁剪、滚动同步重绘），待最终确认
3. 后续可选：线缆清单 CSV/PDF 导出、04 拓扑图拥挤时滚动、PDF 字号统一

## 常用测试钩子
`--layer N`、`--scroll px`、`--zoom f`、`--select id|device id`、`--link aKind aId bKind bId`、`--click/--rclick/--move/--up/--key`、`--dump file`、`--fuzz`、`--linear`、`--nonudge`、`--tech 0..3`、`--turn id deg`
截图：`tools\shot.ps1 -Out <png>`（偶发返回旧帧，需比对哈希）
审计：`tools\_inspcheck.ps1`、`tools\_scroll_test.ps1`

## 2026-11-11 20:10 本轮（四项）
1. **调色板重排（max-min 路径）**：`tools/palette_design.py` 在贪心取色之后加了 `maxmin_order()`
   —— 同 40 色，按哈密顿路径把相邻槽位拉到最远（互补色交错）。相邻槽位最小 dE：
   **icon 31.9 / ink 24.2 / sep 24.2**（旧色轮 5.5；目标 ≥ 12）。`--dump-colors` 新增逐槽
   `iconDE inkDE sepDE` 表 + `min consecutive dE` 行，并在 < 12 时以 exit 2 失败。
   报告 `tools/_palette_report.txt`、色板图 `tools/_palette_order_sheet.png`。
2. **单个对象自定义颜色**：`Item::colorOverride`（0xRRGGBB，0 = 调色板），序列化为 item 记录尾部
   `color 0xRRGGBB`（旧文件无此对 → 0，向后兼容）。属性栏（乐器/声部）新增「颜色」行：色块 + `#RRGGBB`
   +「恢复默认」，点击走 `PickColor`（项目信息页同一个系统取色器），改动 undoable 且受应用锁限制。
   覆盖色同时作用于该对象图标与**绑定到它的**话筒／线缆／标签墨色（`MicBoundInk` → 
   `InstColorOverrideFor`）。
3. **布线页点击连接**：选中话筒后右栏新增「连接」区块（复用右栏），列出声卡／接口箱／无线接收器，
   点一行即连接（`ConnectMicToDevice` → `CreateCable`，改接替换旧线、单步 undo、编组按整组一条线），
   状态栏「已连接到 <设备>」，当前连接行标「已连接」。
4. **通道表「路由」单元格**：点该格（原属拖拽手柄，现只剩「通道」列）弹出小面板，列同一批设备，
   选中即连接（与 3 同一条代码路径）；面板限制在窗口内、最后绘制，Esc／点击外部关闭；该格不打开文本编辑器。

新增测试钩子：`--dump` 增加 `instcolor`、`itemcolor`、`connsec/connrow`、`chrouteitem/chrouterow`。
证据：`tools/_palette_order_sheet.png`、`_final_02.png`、`_final_wiring.png`、`_i2_shot_inspector.png`、
`_i2_02_override.png`、`_i2_wiring_override.png`、`_i2_picker_dialog.png`、`_i3_shot_connect.png`、
`_i4_shot_popup.png`、`_i4_shot_linked.png`、`_i4_table.pdf`。
