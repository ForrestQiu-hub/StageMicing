"""Render the 40-slot palette SHEET: slot order (the max-min path), the icon
tint, the drawn ink, and the CIELab dE to the NEXT slot — proof that
neighbouring slots are far apart.  Reads tools/_color_dump_new.txt (written by
`StageMicing.exe --dump-colors`) and reuses palette_design.py's Lab maths.
"""
import re
import sys

sys.path.insert(0, r"E:\Stage Micing Scene\tools")
import palette_design as pd
from PIL import Image, ImageDraw, ImageFont

SRC = r"E:\Stage Micing Scene\tools\_color_dump_new.txt"
OUT = r"E:\Stage Micing Scene\tools\_palette_order_sheet.png"

font = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 15)
font_s = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 12)
font_b = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 20)

rows = []
for ln in open(SRC, encoding="utf-8-sig"):
    m = re.match(r"^\s*(\d+)\s+(\S+)\s+#([0-9A-F]{6})\s+#([0-9A-F]{6})", ln)
    if m:
        rows.append((int(m.group(1)), m.group(2), m.group(3), m.group(4)))
assert len(rows) == 38, len(rows)


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


pal = [pd.Cand(0.0, 0, pd.DEFAULT_LEVELS) for _ in rows]
for i, (_, _, icon, inkh) in enumerate(rows):
    c = pal[i]
    c.hx = "#" + icon
    c.ihx = "#" + inkh
    c.rgb = rgb(icon)
    c.ink = rgb(inkh)
    c.lab = pd.lab(c.rgb)
    c.ilab = pd.lab(c.ink)

# 8 x 5 grid, each cell: swatch (icon) + ink strip + labels + "→ next dE"
COLS, ROWS = 8, 5
CW, CH, PAD = 190, 138, 10
W = COLS * (CW + PAD) + PAD
TOP = 86
H = TOP + ROWS * (CH + PAD) + PAD + 46
img = Image.new("RGB", (W, H), (250, 248, 243))
g = ImageDraw.Draw(img)
g.text((PAD, 14), "调色板 40 槽：相邻槽位最大化分离（max-min 路径）", font=font_b, fill=(40, 36, 30))
g.text((PAD, 44),
       "每格 = 槽号 / 乐器 id / 图标色 / 绘制墨色；格右下 = 与下一槽的 CIELab dE（图标 dE · 墨 dE）。"
       "最小相邻 dE = 24.2（旧色轮 5.5，目标 ≥ 12）", font=font, fill=(90, 82, 70))

seps = []
for k, (slot, name, icon, inkh) in enumerate(rows):
    r, c = divmod(k, COLS)
    x = PAD + c * (CW + PAD)
    y = TOP + r * (CH + PAD)
    tint = rgb(icon)
    inkc = rgb(inkh)
    g.rectangle([x, y, x + CW, y + 58], fill=tint, outline=(210, 205, 196))
    g.rectangle([x, y + 58, x + CW, y + 68], fill=inkc)
    g.text((x + 4, y + 74), "%d  %s" % (slot, name), font=font_s, fill=(60, 55, 48))
    g.text((x + 4, y + 90), "#%s  →ink #%s" % (icon, inkh), font=font_s, fill=(110, 102, 90))
    if k + 1 < len(rows):
        nxt = pal[k + 1]
        di = pd.de(pal[k].lab, nxt.lab)
        dk = pd.de(pal[k].ilab, nxt.ilab)
        seps.append(min(di, dk))
        g.text((x + 4, y + 106), "→ %d  dE %.1f · %.1f" % (k + 1, di, dk), font=font_s,
               fill=(30, 90, 60))
    else:
        g.text((x + 4, y + 106), "(last slot)", font=font_s, fill=(110, 102, 90))

g.text((PAD, H - 36),
       "min consecutive dE = %.1f   min icon = %.1f   min ink = %.1f   (target >= 12)   "
       "from `StageMicing.exe --dump-colors`" % (
           min(seps), min(pd.de(pal[i].lab, pal[i + 1].lab) for i in range(len(rows) - 1)),
           min(pd.de(pal[i].ilab, pal[i + 1].ilab) for i in range(len(rows) - 1))),
       font=font, fill=(40, 36, 30))
img.save(OUT)
print("wrote", OUT, img.size, "min consecutive dE %.2f" % min(seps))
