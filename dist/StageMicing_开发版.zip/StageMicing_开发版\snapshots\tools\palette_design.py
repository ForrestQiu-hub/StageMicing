"""Design + verify the 40-entry muted palette used by MutedColor() in
src/StageView.cpp, and emit the ready-to-paste C++ literal.

WHY a greedy max-min pick and not a plain hue wheel
---------------------------------------------------
MicInkLine() normalises the DRAWN ink to luminance 104, so a lightness
difference between two palette entries DISAPPEARS in the cable / mic / label
ink: only hue and chroma survive there.  A one-dimensional hue wheel with
alternating lightness therefore still lands pairs 18 deg apart at dE ~2
(cello vs timpani in the previous round).  So the 40 entries are chosen to
maximise the minimum CIELab distance between the ids in BOTH spaces (icon tint
AND drawn ink) while staying inside the old character: Lab chroma <= ~31 (the
old ten sat at 12..22) and Rec.601 luminance 136..161.

Everything is frozen into literal hex values in the C++ file -- no runtime
maths, no hash.  Re-running this script must reproduce identical output.

usage:  python palette_design.py            # write report + C++ literal
        python palette_design.py --compare  # just print variant summary lines
"""

import itertools
import math
import random
import sys

# --------------------------------------------------------------- parameters
PAL_N = 40                   # 38 known ids + 2 spare (grand_piano never tints)
KBD_COUNT = 4                # grand_piano / harpsichord / celesta / upright_piano
KBD_ARC = (18.0, 132.0)      # warm -> green arc holding the keyboard family
KBD_SEED = (54.0, 2)         # (hue, level index) anchoring the keyboard pick
HUE_STEP = 3.0

# level = (target Lab chroma C*, target Rec.601 luminance Y).
# The old ten measured C* 12.0..21.6 / Y 135.6..160.7; the grid below stays just
# outside that: a touch more chroma buys the extra hue resolution that 38 ids
# need (ink keeps only hue+chroma), but it never leaves the muted range.
DEFAULT_LEVELS = [(15.0, 158.0), (22.0, 148.0), (29.0, 138.0)]


# ------------------------------------------------------------- colour maths
def _hv(h, amp):
    hp = h / 60.0
    seg = int(math.floor(hp)) % 6
    x = amp * (1.0 - abs((hp % 2.0) - 1.0))
    return [(amp, x, 0.0), (x, amp, 0.0), (0.0, amp, x),
            (0.0, x, amp), (x, 0.0, amp), (amp, 0.0, x)][seg]


def rgb_from_hue(h, amp, tgt):
    r, g, b = _hv(h, amp)
    w = 0.299 * r + 0.587 * g + 0.114 * b
    m = tgt - w
    return tuple(max(0, min(255, int(round(v + m)))) for v in (r, g, b))


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def ink(c):
    """Mirror of MicInkLine(): cap Rec.601 luminance at 104, scale all channels."""
    y = lum(c)
    if y <= 104.0:
        return c
    k = 104.0 / y
    return tuple(max(0, min(255, int(round(v * k)))) for v in c)


def _lin(v):
    s = v / 255.0
    return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4


def _fv(t):
    return t ** (1.0 / 3.0) if t > 0.008856 else (7.787 * t + 16.0 / 116.0)


def lab(c):
    r, g, b = (_lin(v) for v in c)
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 1.00000
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
    fx, fy, fz = _fv(x), _fv(y), _fv(z)
    return (116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz))


def cstar(c):
    l = lab(c)
    return math.hypot(l[1], l[2])


def de(l1, l2):
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(l1, l2)))


def hexc(c):
    return "#%02X%02X%02X" % c


def solve_amp(h, tgt_c, tgt_y):
    """Bisect the RGB amplitude that hits a target Lab chroma at a target Y."""
    lo, hi = 0.0, 135.0
    for _ in range(40):
        mid = (lo + hi) / 2.0
        if cstar(rgb_from_hue(h, mid, tgt_y)) < tgt_c:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2.0


class Cand:
    __slots__ = ("hue", "level", "rgb", "hx", "lum", "cstar", "ink", "ihx", "lab", "ilab")

    def __init__(self, hue, level, levels):
        tgt_c, tgt_y = levels[level]
        amp = solve_amp(hue, tgt_c, tgt_y)
        self.hue, self.level = hue, level
        self.rgb = rgb_from_hue(hue, amp, tgt_y)
        self.hx = hexc(self.rgb)
        self.lum = round(lum(self.rgb), 1)
        self.cstar = round(cstar(self.rgb), 1)
        self.ink = ink(self.rgb)
        self.ihx = hexc(self.ink)
        self.lab = lab(self.rgb)
        self.ilab = lab(self.ink)

    @property
    def key(self):
        return (self.hue, self.level)


def sep(a, b):
    """Worse of the icon-tint distance and the drawn-ink distance."""
    return min(de(a.lab, b.lab), de(a.ilab, b.ilab))


def pick(sel, pool, min_sep=0.0):
    used = {c.key for c in sel}
    best, best_d = None, -1.0
    for c in pool:
        if c.key in used:
            continue
        d = min((sep(c, s) for s in sel), default=1e9)
        if d < min_sep:
            continue
        if d > best_d:
            best, best_d = c, d
    if best is None:
        raise RuntimeError("candidate pool exhausted (min_sep too high?)")
    return best, best_d


# ---------------------------------------------------------------- ordering
# The palette array is indexed by SLOT, and slot i belongs to ORDER[i] — the
# 02 target / library order.  A hue-wheel array therefore puts near-identical
# hues on NEIGHBOURING slots (the old wheel scored min consecutive dE = 5.5,
# cello vs timpani 18 deg apart).  So the same 40 colours are re-ordered along a
# max-min path: every consecutive pair is put as far apart as possible —
# complementary hues interleaved — so the catalogue reads as alternating tints,
# never as a gradient.  The SET of 40 colours is untouched.
CONSEC_TARGET_DE = 12.0


def maxmin_order(palette, seed=12345, trials=300):
    """Permutation of range(len(palette)) maximising the MINIMUM sep() between
    consecutive entries (a Hamiltonian path, max-min).  Deterministic: the RNG
    is seeded and the search is a fixed greedy + Or-opt descent, so re-running
    this script reproduces the very same order."""
    n = len(palette)
    S = [[sep(a, b) for b in palette] for a in palette]

    def worst(order):
        return min(S[order[i]][order[i + 1]] for i in range(n - 1))

    rnd = random.Random(seed)

    def greedy_far(start, noise):
        used = {start}
        order = [start]
        while len(order) < n:
            last = order[-1]
            cand = [j for j in range(n) if j not in used]

            def key(j):
                base = S[last][j]
                return base + (rnd.uniform(-noise, noise) if noise else 0.0)

            j = max(cand, key=key)
            order.append(j)
            used.add(j)
        return order

    def improve(order, tries):
        best, bestv = list(order), worst(order)
        for _ in range(tries):
            p, q = sorted((rnd.randrange(n), rnd.randrange(n)))
            if p == q:
                continue
            cand = list(best)
            node = cand.pop(q)               # Or-opt: move one entry right after p
            cand.insert(p + 1, node)
            v = worst(cand)
            if v > bestv + 1e-9:
                best, bestv = cand, v
        return best, bestv

    best, bestv = None, -1.0
    for trial in range(trials):
        start = trial % n
        o = greedy_far(start, 6.0 if trial else 0.0)
        o, v = improve(o, 1500)
        if v > bestv:
            best, bestv = o, v
    return best, bestv


def build(levels=DEFAULT_LEVELS, pal_n=PAL_N, kbd_count=KBD_COUNT):
    hues = [i * HUE_STEP for i in range(int(360 / HUE_STEP))]
    pool = [Cand(h, lv, levels) for h in hues for lv in range(len(levels))]

    kbd_pool = [c for c in pool if KBD_ARC[0] <= c.hue <= KBD_ARC[1]]
    seed = [c for c in kbd_pool if c.key == KBD_SEED]
    if not seed:
        raise RuntimeError("keyboard seed candidate missing")
    sel = [seed[0]]
    while len(sel) < kbd_count:
        sel.append(pick(sel, kbd_pool, min_sep=6.0)[0])
    kbd = sorted(sel, key=lambda c: c.hue)          # warm -> green family arc

    rest = []
    while len(kbd) + len(rest) < pal_n:
        rest.append(pick(kbd + rest, pool)[0])
    # rainbow order for the non-keyboard slots: neighbouring instruments read as
    # a progression instead of a random scatter
    rest.sort(key=lambda c: (c.hue, c.level))
    wheel = kbd + rest
    # ... and then the max-min re-order that makes NEIGHBOURING SLOTS far apart
    order, _ = maxmin_order(wheel)
    palette = [wheel[i] for i in order]
    return palette, kbd


# ------------------------------------------------------- the ordered id list
ORDER = [
    # src/Catalog.cpp kInstruments, catalogue order
    "grand_piano", "harpsichord", "celesta", "upright_piano",
    "violin", "violin2", "viola", "cello", "bass", "harp",
    "flute", "oboe", "clarinet", "bassoon",
    "horn", "trumpet", "trombone", "tuba",
    "timpani", "bassdrum", "snare", "cymbal", "xylophone", "glockenspiel", "gong",
    "percussion", "conductor", "solo_singer", "choir_singer", "custom",
    # src/Catalog.cpp kSpotExtras, in its order
    "section_surround", "section_height", "section_side", "section_ambience",
    "section_strings", "section_woodwind", "section_brass", "section_perc",
]


def distinct_stats(palette):
    groups = {}
    for c in palette:
        groups.setdefault(c.hx, []).append(c)
    dup = {h: len(v) for h, v in groups.items() if len(v) > 1}
    pairs = sorted(((sep(a, b), hexc(a.rgb), hexc(b.rgb))
                    for a, b in itertools.combinations(palette, 2)), key=lambda t: t[0])
    return len(groups), dup, pairs


def row_pairs(rows):
    return sorted(((sep(a, b), na, nb)
                   for (_, na, a), (_, nb, b) in itertools.combinations(rows, 2)),
                  key=lambda t: t[0])


def summarise(palette, label):
    n, dup, pal_pairs = distinct_stats(palette)
    rows = [(i, ORDER[i], palette[i]) for i in range(len(ORDER))]
    pairs = row_pairs(rows)
    lums = [c.lum for c in palette]
    cs = [c.cstar for c in palette]
    return ("%-28s distinct %2d/%d  min dE(ids) %4.1f  min dE(pal) %4.1f  "
            "Y %3.0f..%3.0f  C* %4.1f..%4.1f  closest: %s <-> %s" % (
                label, n, len(palette), pairs[0][0], pal_pairs[0][0],
                min(lums), max(lums), min(cs), max(cs), pairs[0][1], pairs[0][2]))


def main():
    compare = "--compare" in sys.argv
    variants = [
        ("A c13/21/29", [(13.0, 158.0), (21.0, 148.0), (29.0, 138.0)]),
        ("B c15/22/29", [(15.0, 158.0), (22.0, 148.0), (29.0, 138.0)]),
        ("C c16/24/32", [(16.0, 158.0), (24.0, 148.0), (32.0, 138.0)]),
        ("D c12/18/24", [(12.0, 158.0), (18.0, 148.0), (24.0, 138.0)]),
        ("E c15/23/31", [(15.0, 158.0), (23.0, 148.0), (31.0, 138.0)]),
        ("F c15/23/31 y158/146/134", [(15.0, 158.0), (23.0, 146.0), (31.0, 134.0)]),
        ("G c13/20/27 y160/150/140", [(13.0, 160.0), (20.0, 150.0), (27.0, 140.0)]),
    ]
    if compare:
        for label, lv in variants:
            palette, kbd = build(lv)
            print(summarise(palette, label))
        return

    palette, kbd = build(DEFAULT_LEVELS)
    rows = [(i, ORDER[i], palette[i]) for i in range(len(ORDER))]
    pal_n = len(palette)

    out = []
    w = out.append
    w("==== %d HEX VALUES (palette order == SLOT order == assignment order) ====" % pal_n)
    w("(max-min path: consecutive slots are as far apart as the fixed set allows)")
    for i in range(0, pal_n, 4):
        w("  " + "  ".join(hexc(c.rgb) for c in palette[i:i + 4]))

    w("")
    w("==== slot / hue / level (C*,Y target) / hex / actual Y, C* ====")
    for i, c in enumerate(palette):
        tgt_c, tgt_y = DEFAULT_LEVELS[c.level]
        w("slot %2d  hue %5.1f  level %d  C*target %4.1f  Ytarget %3.0f  %s  "
          "Y %5.1f  C* %5.1f%s" % (i, c.hue, c.level, tgt_c, tgt_y, c.hx, c.lum,
                                   c.cstar, "   keyboard family" if c in kbd else ""))

    # ---- CONSECUTIVE slots: the max-min target ------------------------------
    cons = [(de(palette[i].lab, palette[i + 1].lab),
             de(palette[i].ilab, palette[i + 1].ilab),
             sep(palette[i], palette[i + 1])) for i in range(pal_n - 1)]
    min_icon = min(t[0] for t in cons)
    min_ink = min(t[1] for t in cons)
    min_sep = min(t[2] for t in cons)
    wi = min(range(pal_n - 1), key=lambda k: cons[k][2])
    w("")
    w("==== CONSECUTIVE slots (target: min sep >= %.0f) ====" % CONSEC_TARGET_DE)
    w("%-4s %-9s %-9s %8s %8s %8s" % ("slot", "this", "next", "icon dE", "ink dE", "sep"))
    for i in range(pal_n - 1):
        a, b = palette[i], palette[i + 1]
        w("%-4d %-9s %-9s %8.1f %8.1f %8.1f" % (i, a.hx, b.hx, cons[i][0], cons[i][1],
                                                cons[i][2]))
    w("min consecutive icon dE ....... %.1f" % min_icon)
    w("min consecutive ink  dE ....... %.1f" % min_ink)
    w("min consecutive sep  dE ....... %.1f   (%s <-> %s, slots %d/%d)" % (
        min_sep, palette[wi].hx, palette[wi + 1].hx, wi, wi + 1))
    w("assert min consecutive dE >= %.0f ... %s" % (
        CONSEC_TARGET_DE, "OK" if min_sep >= CONSEC_TARGET_DE else "FAIL"))

    w("")
    w("==== id -> palette colour -> drawn ink (MicInkLine: Y capped at 104) ====")
    w("%-4s %-18s %-9s %-9s %6s %6s" % ("slot", "defId", "icon", "ink", "iconY", "inkY"))
    for i, name, c in rows:
        w("%-4d %-18s %-9s %-9s %6.1f %6.1f" % (i, name, c.hx, c.ihx, c.lum, lum(c.ink)))

    icon_groups, ink_groups, pal_distinct = {}, {}, distinct_stats(palette)[0]
    for _, n, c in rows:
        icon_groups.setdefault(c.hx, []).append(n)
        ink_groups.setdefault(c.ihx, []).append(n)
    icon_dup = {h: v for h, v in icon_groups.items() if len(v) > 1}
    ink_dup = {h: v for h, v in ink_groups.items() if len(v) > 1}

    w("")
    w("==== ASSERT ====")
    w("palette entries distinct ........ %d/%d" % (pal_distinct, pal_n))
    w("id icon colours distinct ....... %d/%d  duplicates %d" % (
        len(icon_groups), len(rows), len(icon_dup)))
    w("id drawn inks distinct ......... %d/%d  duplicates %d" % (
        len(ink_groups), len(rows), len(ink_dup)))
    for h, v in sorted(icon_dup.items()):
        w("  ICON DUP %s: %s" % (h, ", ".join(v)))
    for h, v in sorted(ink_dup.items()):
        w("  INK  DUP %s: %s" % (h, ", ".join(v)))

    pairs = row_pairs(rows)
    w("")
    w("closest id pairs (min of icon dE / drawn-ink dE):")
    for d, na, nb in pairs[:10]:
        w("  dE %5.1f  %-18s <-> %s" % (d, na, nb))
    w("global min pair dE over the %d ids ... %.1f" % (len(rows), pairs[0][0]))

    pal_pairs = distinct_stats(palette)[2]
    w("global min pair dE over all %d entries .. %.1f  (%s <-> %s)" % (
        pal_n, pal_pairs[0][0], pal_pairs[0][1], pal_pairs[0][2]))
    w("keyboard quartet min dE ........ %.1f  (%s)" % (
        min(sep(a, b) for a, b in itertools.combinations(kbd, 2)),
        ", ".join(c.hx for c in kbd)))

    lums = [c.lum for c in palette]
    cs = [c.cstar for c in palette]
    w("")
    w("muted luminance band ........... %.0f .. %.0f   (old ten: 136 .. 161)" % (min(lums), max(lums)))
    w("Lab chroma band ................ %.1f .. %.1f   (old ten: 12.0 .. 21.6)"
      % (min(cs), max(cs)))
    w("drawn ink luminance band ....... %.0f .. %.0f" % (
        min(lum(c.ink) for c in palette), max(lum(c.ink) for c in palette)))
    w("")
    w("verdict: %s" % ("PASS - every one of the %d ids has its own tint and its own ink, "
                       "and neighbouring slots are >= %.0f dE apart"
                       % (len(rows), CONSEC_TARGET_DE)
                       if not icon_dup and not ink_dup and pal_distinct == pal_n and
                       min_sep >= CONSEC_TARGET_DE else "FAIL"))

    text = "\n".join(out)
    print(text)
    with open(r"E:\Stage Micing Scene\tools\_palette_report.txt", "w",
              encoding="utf-8", newline="\r\n") as f:
        f.write(text + "\r\n")

    lit = ["    static const Rgb pal[%d] = {" % pal_n]
    for i in range(0, pal_n, 3):
        lit.append("        " + " ".join("{%d, %d, %d}," % c.rgb for c in palette[i:i + 3]))
    lit.append("    };")
    with open(r"E:\Stage Micing Scene\tools\_palette_literal.txt", "w",
              encoding="ascii", newline="\r\n") as f:
        f.write("\n".join(lit) + "\r\n")
    print("\nwrote tools/_palette_report.txt and tools/_palette_literal.txt")


if __name__ == "__main__":
    main()
