param(
  [string]$Pattern = "E:\Stage Micing Scene\tools\_seq*.png",
  [string]$OutFile = "E:\Stage Micing Scene\tools\_crop_out.png",
  [int]$X = 0,
  [int]$Y = 0,
  [int]$W = 620,
  [int]$H = 400,
  [int]$Cols = 2,
  [double]$Scale = 1.0
)
Add-Type -AssemblyName System.Drawing
$files = @(Get-ChildItem -Path $Pattern | Sort-Object Name)
Write-Output "crop inputs: $($files.Count)"
foreach ($f in $files) { Write-Output "  $($f.Name)" }
if ($files.Count -eq 0) { exit 1 }
$tw = [int]($W * $Scale); $th = [int]($H * $Scale)
$rows = [int][math]::Ceiling($files.Count / $Cols)
$canvas = New-Object System.Drawing.Bitmap ($tw * $Cols), ($th * $rows)
$g = [System.Drawing.Graphics]::FromImage($canvas)
$g.Clear([System.Drawing.Color]::FromArgb(60, 60, 60))
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$font = New-Object System.Drawing.Font "Consolas", 16
for ($i = 0; $i -lt $files.Count; $i++) {
    $bmp = [System.Drawing.Bitmap]::FromFile($files[$i].FullName)
    $dstX = ($i % $Cols) * $tw; $dstY = [int]([math]::Floor($i / $Cols)) * $th
    $dst = New-Object System.Drawing.Rectangle $dstX, $dstY, $tw, $th
    $src = New-Object System.Drawing.Rectangle $X, $Y, $W, $H
    $g.DrawImage($bmp, $dst, $src, [System.Drawing.GraphicsUnit]::Pixel)
    $bmp.Dispose()
    $g.DrawString($files[$i].BaseName, $font, [System.Drawing.Brushes]::Red, ($dstX + 5), ($dstY + 3))
}
$g.Dispose()
$canvas.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
$canvas.Dispose()
Write-Output "saved $OutFile"
