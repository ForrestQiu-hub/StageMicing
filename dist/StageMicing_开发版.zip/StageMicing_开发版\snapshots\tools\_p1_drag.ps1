param(
    [int]$X1 = 0, [int]$Y1 = 0, [int]$X2 = 0, [int]$Y2 = 0,
    [string]$Out = "E:\Stage Micing Scene\tools\_shot_drag.png",
    [switch]$Keys   # after dragging, press Delete
)

Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Dragger {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, IntPtr extra);
}
'@
try { [Dragger]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
[Dragger]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 400

$origin = New-Object Dragger+POINT
[Dragger]::ClientToScreen($h, [ref]$origin) | Out-Null

# press
[Dragger]::SetCursorPos($origin.X + $X1, $origin.Y + $Y1) | Out-Null
Start-Sleep -Milliseconds 200
[Dragger]::mouse_event(2, 0, 0, 0, [IntPtr]::Zero)   # left down
Start-Sleep -Milliseconds 200

# move in 14 steps so the app sees a real drag
for ($i = 1; $i -le 14; $i++) {
    $x = [int]($origin.X + $X1 + ($X2 - $X1) * $i / 14)
    $y = [int]($origin.Y + $Y1 + ($Y2 - $Y1) * $i / 14)
    [Dragger]::SetCursorPos($x, $y) | Out-Null
    Start-Sleep -Milliseconds 60
}
Start-Sleep -Milliseconds 200
[Dragger]::mouse_event(4, 0, 0, 0, [IntPtr]::Zero)   # left up
Start-Sleep -Milliseconds 400

if ($Keys) {
    # VK_DELETE = 0x2E ; KEYEVENTF_KEYUP = 2
    [Dragger]::keybd_event(0x2E, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 80
    [Dragger]::keybd_event(0x2E, 0, 2, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 500
}

$wr = New-Object Dragger+RECT
[Dragger]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L; $ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[Dragger]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out ${w}x${ht}"
