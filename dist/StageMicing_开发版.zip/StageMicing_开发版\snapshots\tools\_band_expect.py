# -*- coding: utf-8 -*-
# Independent replica of the app's rubber-band hit test for a PRESET-loaded scene:
# the --dump of `--preset 2` prints `instw` rows in the order the preset table
# created them, so the table's defIds zip straight onto the dump's item ids.
#
#   python tools/_band_expect.py <dump.txt> <tableVar> <bandL> <bandT> <bandR> <bandB>
import io
import math
import re
import sys

ROOT = r"E:\Stage Micing Scene"


def catalog():
    cat = {}
    text = io.open(ROOT + r"\src\Catalog.cpp", encoding="utf-8").read()
    for m in re.finditer(
            r'\{\s*L"([a-z0-9_]+)"\s*,\s*L"[^"]*"\s*,\s*L"[^"]*"\s*,\s*L"[a-z0-9_]+"\s*,'
            r'\s*([0-9.]+)\s*,\s*([0-9.]+)\s*\}', text):
        s = 1.0 if m.group(1) == "grand_piano" else 0.90
        cat[m.group(1)] = (float(m.group(2)) * s, float(m.group(3)) * s)
    return cat


def table_rows(var):
    rows = []
    cur = False
    for ln in io.open(ROOT + r"\src\Presets.cpp", encoding="utf-8").read().splitlines():
        if re.search(r"static const PresetRow %s\[\]" % var, ln):
            cur = True
            continue
        if cur:
            if ln.strip() == "};":
                break
            m = re.search(r'\{\s*L"([a-z0-9_]+)"', ln)
            if m:
                rows.append(m.group(1))
    return rows


def sat(band, cx, cy, hw, hh, deg):
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    ux, uy = ca * hw, sa * hw
    vx, vy = -sa * hh, ca * hh
    qx = [cx - ux - vx, cx + ux - vx, cx + ux + vx, cx - ux + vx]
    qy = [cy - uy - vy, cy + uy - vy, cy + uy + vy, cy - uy + vy]
    l, t, r, b = band
    bx = [l, r, r, l]
    by = [t, t, b, b]
    for ax, ay in ((1, 0), (0, 1), (ca, sa), (-sa, ca)):
        q0 = min(px * ax + py * ay for px, py in zip(qx, qy))
        q1 = max(px * ax + py * ay for px, py in zip(qx, qy))
        r0 = min(px * ax + py * ay for px, py in zip(bx, by))
        r1 = max(px * ax + py * ay for px, py in zip(bx, by))
        if min(q1, r1) - max(q0, r0) < -0.001:
            return False
    return True


dump, var, l, t, r, b = sys.argv[1], sys.argv[2], *map(int, sys.argv[3:7])
band = (l, t, r, b)
L = io.open(ROOT + "\\" + dump, "rb").read().decode("utf-16-le").splitlines()
hdr = [x for x in L if x.startswith("dpi ")][0].split()
ppm = float(hdr[hdr.index("ppm") + 1])
ox = float(hdr[hdr.index("ox") + 1])
oy = float(hdr[hdr.index("oy") + 1])
items = []
for x in L:
    if x.startswith("instw "):
        p = x.split()
        items.append((int(p[1]), float(p[2]), float(p[3]), float(p[4])))
rows = table_rows(var)
print("ppm %.4f ox %.3f oy %.3f  items %d  table rows %d" %
      (ppm, ox, oy, len(items), len(rows)))
assert len(items) == len(rows), "table and dump disagree"
cat = catalog()
hits = []
for (iid, wx, wy, ang), defid in zip(items, rows):
    w, h = cat[defid]
    cx = ox + wx * ppm
    cy = oy + wy * ppm
    if sat(band, cx, cy, w * ppm * 0.5, h * ppm * 0.5, ang):
        hits.append((iid, defid))
print("band %dx%d..%dx%d -> %d hits" % (l, t, r, b, len(hits)))
print("ids:", [h[0] for h in hits])
from collections import Counter
print("types:", dict(Counter(h[1] for h in hits)))
