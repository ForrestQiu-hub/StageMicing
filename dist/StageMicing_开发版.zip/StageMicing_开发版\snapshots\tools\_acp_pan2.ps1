$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class AcpPan2 {
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
}
"@
[AcpPan2]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null
$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"
$out = "E:\Stage Micing Scene\tools\_acp_v_zoom25_pan.png"
$p = Start-Process -FilePath $exe -ArgumentList '--layer','1','--zoom','2.5' -PassThru
$h = [IntPtr]::Zero
for ($i = 0; $i -lt 16; $i++) {
    Start-Sleep -Milliseconds 400
    if ($p.HasExited) { throw "app exited" }
    $p.Refresh(); $h = $p.MainWindowHandle
    if ($h -ne [IntPtr]::Zero) { break }
}
if ($h -eq [IntPtr]::Zero) { throw "no window" }
Start-Sleep -Milliseconds 500
function Mklp([int]$x, [int]$y) { $v = ($y -shl 16) -bor $x; return [IntPtr]$v }
[AcpPan2]::PostMessage($h, 0x207, [IntPtr]1, (Mklp 700 500)) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan2]::PostMessage($h, 0x200, [IntPtr]0, (Mklp 740 545)) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan2]::PostMessage($h, 0x200, [IntPtr]0, (Mklp 780 590)) | Out-Null
Start-Sleep -Milliseconds 80
[AcpPan2]::PostMessage($h, 0x208, [IntPtr]0, (Mklp 780 590)) | Out-Null
Start-Sleep -Milliseconds 600
$r = New-Object AcpPan2+RECT
[AcpPan2]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.R - $r.L; $ht = $r.B - $r.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[AcpPan2]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc); $g.Dispose()
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Stop-Process -Id $p.Id -Force
Write-Output ("saved {0} {1}x{2}" -f $out, $w, $ht)
