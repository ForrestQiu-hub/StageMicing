param(
  [string]$In = "E:\Stage Micing Scene\tools\_acp_zoom25_before.png",
  [int]$Y = 200,
  [int]$X0 = 0,
  [int]$X1 = 375
)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($In)
$prev = ""
$start = $X0
for ($x = $X0; $x -le $X1; $x++) {
    $c = $bmp.GetPixel($x, $Y)
    $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    if ($s -ne $prev) {
        if ($prev -ne "") { Write-Output ("x {0}-{1} = #{2}" -f $start, ($x-1), $prev) }
        $prev = $s; $start = $x
    }
}
Write-Output ("x {0}-{1} = #{2}" -f $start, $X1, $prev)
$bmp.Dispose()
