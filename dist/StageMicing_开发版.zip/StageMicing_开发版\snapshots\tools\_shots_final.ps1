# Final evidence shots: launches the app with scripted args and captures the window.
# Cases are hard-coded so no argument array has to survive the command line.
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Fin {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
}
'@
try { [Fin]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch { }
$exe = "E:\Stage Micing Scene\build\Release\StageMicing.exe"
$dir = "E:\Stage Micing Scene\tools"

$cases = @(
    @{ n = "L0_s0";      a = @("--layer", "0") },
    @{ n = "L0_s220";    a = @("--layer", "0", "--scroll", "220") },
    @{ n = "L0_s440";    a = @("--layer", "0", "--scroll", "440") },
    @{ n = "L1_s0";      a = @("--layer", "1", "--select", "3") },
    @{ n = "L1_s220";    a = @("--layer", "1", "--select", "3", "--scroll", "220") },
    @{ n = "L1_s440";    a = @("--layer", "1", "--select", "3", "--scroll", "440") },
    @{ n = "L5_mic_off"; a = @("--layer", "2", "--select", "3", "--link", "1", "3", "0", "3") },
    @{ n = "L5_mic_on";  a = @("--layer", "2", "--select", "3", "--link", "1", "3", "0", "3", "--click", "1740", "470") },
    @{ n = "L1_45";      a = @("--layer", "1", "--link", "1", "3", "0", "3", "--link", "1", "4", "0", "2", "--click", "880", "631", "--move", "880", "408") }
)

foreach ($c in $cases) {
    Get-Process StageMicing -ErrorAction SilentlyContinue | ForEach-Object {
        $_ | Stop-Process -Force
        try { $_.WaitForExit(4000) | Out-Null } catch { }
    }
    Start-Sleep -Milliseconds 400
    $proc = Start-Process -FilePath $exe -ArgumentList $c.a -PassThru
    $h = [IntPtr]::Zero
    for ($i = 0; $i -lt 60 -and $h -eq [IntPtr]::Zero; $i++) {
        Start-Sleep -Milliseconds 250
        $proc.Refresh()
        if ($proc.HasExited) { Write-Output "$($c.n): exited"; break }
        if ($proc.MainWindowHandle -ne [IntPtr]::Zero) { $h = $proc.MainWindowHandle }
    }
    if ($h -eq [IntPtr]::Zero) { continue }
    Start-Sleep -Milliseconds 900
    [Fin]::SetForegroundWindow($h) | Out-Null
    $r = New-Object Fin+RECT
    [Fin]::GetWindowRect($h, [ref]$r) | Out-Null
    $w = $r.Right - $r.Left; $ht = $r.Bottom - $r.Top
    if ($w -le 400) { Write-Output "$($c.n): bad rect"; continue }
    $bmp = New-Object System.Drawing.Bitmap $w, $ht
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $g.GetHdc()
    [Fin]::PrintWindow($h, $hdc, 2) | Out-Null
    $g.ReleaseHdc($hdc); $g.Dispose()
    $bmp.Save("$dir\_fin_$($c.n).png", [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Output "$($c.n) saved (${w}x${ht})"
}
Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
