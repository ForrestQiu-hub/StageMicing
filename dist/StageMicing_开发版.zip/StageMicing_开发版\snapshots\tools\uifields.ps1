param([int[]]$Ids = @(106, 107, 108))
Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Fld {
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindowW(string cls, string title);
    [DllImport("user32.dll")] public static extern IntPtr GetDlgItem(IntPtr parent, int id);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr wp, StringBuilder lp);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
}
'@
$h = [IntPtr]::Zero
$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if ($proc) { $h = $proc.MainWindowHandle }
if ($h -eq [IntPtr]::Zero) { $h = [Fld]::FindWindowW("StageMicingWnd", $null) }
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }
foreach ($id in $Ids) {
    $e = [Fld]::GetDlgItem($h, $id)
    if ($e -eq [IntPtr]::Zero) { Write-Output "$id = <missing>"; continue }
    $sb = New-Object System.Text.StringBuilder 256
    [Fld]::SendMessageW($e, 0x000D, [IntPtr]256, $sb) | Out-Null   # WM_GETTEXT
    $vis = [Fld]::IsWindowVisible($e)
    Write-Output ("{0} = '{1}' visible={2}" -f $id, $sb.ToString(), $vis)
}
