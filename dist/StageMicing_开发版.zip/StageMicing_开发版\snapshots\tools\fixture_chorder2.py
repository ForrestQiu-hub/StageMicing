def item(i, x, y, spot, label, defid='mic'):
    return ('item %d 1 "%s" %.3f %.3f 0.0 1.500 0.000 0.000 0 0 0.900 0.900 "%s" '
            '"M1" "" "" "" "%s" "" 0 6.500 0.000' % (i, defid, x, y, label, spot))

lines = [
    'SMPROJ 1',
    '# Stage Micing project - UTF-8, one record per line',
    'piece "order fixture 2"',
    'venue ""', 'conductor ""', 'sysengineer ""', 'recengineer ""',
    'asstengineer ""', 'notes ""',
    'stage 18.000 12.000 5.000',
    'ceiling 8.000',
    'colors 3A3732 554C42 33302B FBF9F4',
    'samplerate 48000', 'showinstruments 1', 'showmics 1',
    'nextid 40', 'nextdeviceid 1',
    # deliberately shuffled
    item(10, 3.0, 3.0, 'section_ambience', 'Amb'),
    item(11, 4.0, 3.0, 'choir_singer', 'Choir'),
    item(12, 5.0, 3.0, 'solo_singer', 'Solo'),
    item(13, 6.0, 3.0, 'celesta', 'Cel'),
    item(14, 7.0, 3.0, 'harp', 'Harp'),
    item(15, 8.0, 3.0, 'timpani', 'Timp'),
    item(16, 9.0, 3.0, 'horn', 'Horn'),
    item(17, 10.0, 3.0, 'flute', 'Flute'),
    item(18, 11.0, 3.0, 'violin', 'Vln'),
    item(19, 12.0, 3.0, 'section_strings', 'Str'),
    item(20, 13.0, 3.0, 'harpsichord', 'Hpsd'),
    item(21, 2.0, 3.0, 'upright_piano', 'Upr'),
    item(22, 3.5, 3.0, 'grand_piano', 'Grand'),
    item(23, 4.5, 3.0, 'section_side', 'Side'),
    item(24, 5.5, 3.0, 'custom', 'Custom'),
    item(25, 6.5, 3.0, '', 'Unbound'),
    item(26, 7.5, 3.0, 'section_woodwind', 'Wood'),
    item(27, 8.5, 3.0, 'section_brass', 'Brass'),
    item(28, 9.5, 3.0, 'section_perc', 'Perc'),
    item(29, 10.5, 3.0, 'glockenspiel', 'Glock'),
    item(30, 11.5, 3.0, 'conductor', 'Cond'),
    'mainmics 0',
    'topology 0 0',
]
open(r'E:\Stage Micing Scene\tools\fixture_chorder2.smproj', 'w', encoding='utf-8',
     newline='\r\n').write('\n'.join(lines) + '\n')
print('written')
