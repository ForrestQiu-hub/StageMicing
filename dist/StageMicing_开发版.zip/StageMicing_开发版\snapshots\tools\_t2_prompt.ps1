param(
    [ValidateSet("shot", "cancel", "discard", "save", "close")]
    [string]$Action = "shot",
    [string]$Out = "E:\Stage Micing Scene\tools\_t2_prompt.png",
    [int]$Wait = 2500
)
# Item 2 helper: find the running app window, and either screenshot it (PrintWindow,
# so the painted modal is included) or post a left click on one of the three
# prompt buttons / a WM_CLOSE.  The prompt geometry comes from PaintExitPrompt:
#   panel = 620 x 214 design px, centred; buttons 128 x 38, gap 10, right-aligned
#   at panel.right - 24, bottom at panel.bottom - 22.
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class T2 {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr FindWindowW(string cls, string title);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr h, uint msg, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
}
'@
try { [T2]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

# wait for the app window (FindWindowW by class is unreliable under the DSH
# sandbox: it returns 0 here even though the class is registered, so the process
# MainWindowHandle is used instead)
$h = [IntPtr]::Zero
for ($i = 0; $i -lt 60; $i++) {
    $proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
    if ($proc) { $h = $proc.MainWindowHandle; break }
    Start-Sleep -Milliseconds 250
}
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }
Start-Sleep -Milliseconds $Wait

if ($Action -eq "close") {
    [T2]::PostMessageW($h, 0x0010, [IntPtr]::Zero, [IntPtr]::Zero) | Out-Null
    Write-Output "posted WM_CLOSE"
    exit 0
}

$cr = New-Object T2+RECT
[T2]::GetClientRect($h, [ref]$cr) | Out-Null
$cw = $cr.R; $ch = $cr.B
$dpi = [T2]::GetDpiForWindow($h) / 96.0
$ui = [math]::Min(1.0, [math]::Max(0.80, ($ch / $dpi - 86.0) / 800.0))
function d([double]$v) { [int][math]::Round($v * $dpi * $ui, [MidpointRounding]::AwayFromZero) }
$w = d 620.0; $ht = d 214.0
$cx = [int][math]::Floor($cw / 2.0); $cy = [int][math]::Floor($ch / 2.0)
$pl = $cx - [int][math]::Floor($w / 2.0); $pt = $cy - [int][math]::Floor($ht / 2.0)
$pr = $pl + $w; $pb = $pt + $ht
$bw = d 128.0; $bh = d 38.0; $gap = d 10.0
$by = $pb - (d 22.0) - $bh
$cancelR = $pr - (d 24.0)
$cancel = @(($cancelR - $bw), $by, $cancelR, ($by + $bh))
$discardR = $cancelR - $bw - $gap
$discard = @(($discardR - $bw), $by, $discardR, ($by + $bh))
$saveR = $discardR - $bw - $gap
$save = @(($saveR - $bw), $by, $saveR, ($by + $bh))
function center($r) { return @([int](($r[0] + $r[2]) / 2), [int](($r[1] + $r[3]) / 2)) }

switch ($Action) {
    "shot" {
        [T2]::ShowWindow($h, 9) | Out-Null
        [T2]::SetForegroundWindow($h) | Out-Null
        Start-Sleep -Milliseconds 500
        $wr = New-Object T2+RECT
        [T2]::GetWindowRect($h, [ref]$wr) | Out-Null
        $ww = $wr.R - $wr.L; $wh = $wr.B - $wr.T
        $bmp = New-Object System.Drawing.Bitmap $ww, $wh
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $dc = $g.GetHdc()
        [T2]::PrintWindow($h, $dc, 2) | Out-Null
        $g.ReleaseHdc($dc)
        $g.Dispose()
        $bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        Write-Output ("shot {0} {1}x{2} client {3}x{4} dpi {5}" -f $Out, $ww, $wh, $cw, $ch, $dpi)
        exit 0
    }
    "cancel" { $pt2 = center $cancel }
    "discard" { $pt2 = center $discard }
    "save" { $pt2 = center $save }
}
$lp = [IntPtr](($pt2[0] -band 0xFFFF) -bor (($pt2[1] -band 0xFFFF) -shl 16))
[T2]::PostMessageW($h, 0x0201, [IntPtr]1, $lp) | Out-Null
Start-Sleep -Milliseconds 120
[T2]::PostMessageW($h, 0x0202, [IntPtr]0, $lp) | Out-Null
Write-Output ("click {0} at {1},{2} (client {3}x{4})" -f $Action, $pt2[0], $pt2[1], $cw, $ch)
