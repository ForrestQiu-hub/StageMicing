﻿# Stage Micing installer (per-user, no admin required)
# Copies the program to %LOCALAPPDATA%\StageMicing, creates shortcuts,
# optionally registers the .smproj file association, and writes an uninstaller.

param(
    [string]$Target = '',
    [switch]$Silent,
    [switch]$NoAssoc,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
$root   = Split-Path -Parent $MyInvocation.MyCommand.Path
$src    = Join-Path $root 'payload'
$dest   = if ([string]::IsNullOrEmpty($Target)) { Join-Path $env:LOCALAPPDATA 'StageMicing' } else { $Target }
$exe    = Join-Path $dest 'StageMicing.exe'
# when running from the self-extracting Setup.exe the payload arrives as payload.zip
if (-not (Test-Path (Join-Path $src 'StageMicing.exe'))) {
    $zip = Join-Path $root 'payload.zip'
    if (Test-Path $zip) {
        Write-Host '解压程序文件...'
        Expand-Archive -Path $zip -DestinationPath $src -Force
    }
}

function Say($m) { Write-Host $m }

Say ''
Say '=== Stage Micing 安装程序 ==='
Say "安装到: $dest"
Say ''

if (-not (Test-Path (Join-Path $src 'StageMicing.exe'))) {
    Say '安装包不完整：找不到 payload\StageMicing.exe'
    Read-Host '按回车退出'
    exit 1
}

if ($Silent) {
    $doAssoc = -not $NoAssoc
} else {
    Write-Host '是否注册 .smproj 文件关联（双击工程直接打开）？ [Y/n] ' -NoNewline
    $ans = Read-Host
    $doAssoc = ($ans -eq '' -or $ans -match '^[Yy]')
}

# stop a running instance so the files can be replaced
Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

if (Test-Path $dest) {
    Say '清理旧版本（保留 applock.dat 与工程文件）...'
    Get-ChildItem $dest -Force | Where-Object {
        $_.Name -notin @('applock.dat')
    } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $dest -Force | Out-Null

Say '复制文件...'
Copy-Item (Join-Path $src '*') $dest -Recurse -Force
New-Item -ItemType Directory -Path (Join-Path $dest 'samples') -Force | Out-Null

# keep the user's passcode if they had one
Say '完成复制.'

# ---- shortcuts -------------------------------------------------------------
Say '创建快捷方式...'
$ws = New-Object -ComObject WScript.Shell
$startDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$lnk = $ws.CreateShortcut((Join-Path $startDir 'Stage Micing.lnk'))
$lnk.TargetPath = $exe
$lnk.WorkingDirectory = $dest
$lnk.IconLocation = "$exe,0"
$lnk.Description = 'Stage Micing - 舞台拾音设计'
$lnk.Save()

$desk = [Environment]::GetFolderPath('Desktop')
$lnk2 = $ws.CreateShortcut((Join-Path $desk 'Stage Micing.lnk'))
$lnk2.TargetPath = $exe
$lnk2.WorkingDirectory = $dest
$lnk2.IconLocation = "$exe,0"
$lnk2.Save()

# ---- optional file association ---------------------------------------------
if ($doAssoc) {
    Say '注册 .smproj 文件关联...'
    $k1 = 'HKCU:\Software\Classes\.smproj'
    $k2 = 'HKCU:\Software\Classes\StageMicing.Project'
    New-Item -Path $k1 -Force | Out-Null
    Set-ItemProperty -Path $k1 -Name '(default)' -Value 'StageMicing.Project'
    New-Item -Path $k2 -Force | Out-Null
    Set-ItemProperty -Path $k2 -Name '(default)' -Value 'Stage Micing 项目'
    New-Item -Path "$k2\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "$k2\DefaultIcon" -Name '(default)' -Value "`"$exe`",0"
    New-Item -Path "$k2\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path "$k2\shell\open\command" -Name '(default)' -Value "`"$exe`" `"%1`""
}

# ---- uninstaller -----------------------------------------------------------
Say '写入卸载信息...'
$uninst = @'
$ErrorActionPreference = 'SilentlyContinue'
$dest = Join-Path $env:LOCALAPPDATA 'StageMicing'
Get-Process StageMicing | Stop-Process -Force
Remove-Item 'HKCU:\Software\Classes\.smproj' -Recurse -Force
Remove-Item 'HKCU:\Software\Classes\StageMicing.Project' -Recurse -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\StageMicing' -Recurse -Force
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Stage Micing.lnk') -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Stage Micing.lnk') -Force
Remove-Item $dest -Recurse -Force
Write-Host 'Stage Micing 已卸载。'
Start-Sleep -Seconds 2
'@
$uninst | Set-Content -Path (Join-Path $dest 'uninstall.ps1') -Encoding UTF8
$cmd = "@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -File ""%~dp0uninstall.ps1""`r`n"
$cmd | Set-Content -Path (Join-Path $dest '卸载.cmd') -Encoding OEM

$uk = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\StageMicing'
New-Item -Path $uk -Force | Out-Null
Set-ItemProperty -Path $uk -Name 'DisplayName'     -Value 'Stage Micing'
Set-ItemProperty -Path $uk -Name 'DisplayVersion'  -Value '1.0'
Set-ItemProperty -Path $uk -Name 'Publisher'       -Value 'Stage Micing'
Set-ItemProperty -Path $uk -Name 'InstallLocation' -Value $dest
Set-ItemProperty -Path $uk -Name 'DisplayIcon'     -Value "$exe,0"
Set-ItemProperty -Path $uk -Name 'UninstallString' -Value "`"$dest\卸载.cmd`""
Set-ItemProperty -Path $uk -Name 'NoModify'        -Value 1 -Type DWord
Set-ItemProperty -Path $uk -Name 'NoRepair'        -Value 1 -Type DWord

Say ''
Say '安装完成。'
if (-not $Silent -and -not $NoLaunch) {
    Write-Host '现在启动 Stage Micing？ [Y/n] ' -NoNewline
    $run = Read-Host
    if ($run -eq '' -or $run -match '^[Yy]') { Start-Process -FilePath $exe -WorkingDirectory $dest }
}
