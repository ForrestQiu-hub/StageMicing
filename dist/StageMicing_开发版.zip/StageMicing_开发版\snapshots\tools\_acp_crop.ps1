param(
  [string]$In = "E:\Stage Micing Scene\tools\_acp_before_L1.png",
  [string]$Out = "E:\Stage Micing Scene\tools\_acp_crop.png",
  [int]$X = 780,
  [int]$Y = 820,
  [int]$W = 240,
  [int]$H = 160,
  [double]$Scale = 3.0
)
Add-Type -AssemblyName System.Drawing
$src = [System.Drawing.Bitmap]::FromFile($In)
$tw = [int]($W * $Scale); $th = [int]($H * $Scale)
$dst = New-Object System.Drawing.Bitmap $tw, $th
$g = [System.Drawing.Graphics]::FromImage($dst)
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
$g.DrawImage($src, (New-Object System.Drawing.Rectangle 0,0,$tw,$th),
             (New-Object System.Drawing.Rectangle $X,$Y,$W,$H),
             [System.Drawing.GraphicsUnit]::Pixel)
$g.Dispose()
$dst.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$dst.Dispose()
$src.Dispose()
Write-Output "saved $Out ${tw}x${th}"
