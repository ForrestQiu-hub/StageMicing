param(
  [string]$In = "E:\Stage Micing Scene\tools\_acp_pw_z25.png",
  [string]$Mode = "row",
  [int]$Pos = 150,
  [int]$From = 0,
  [int]$To = -1,
  [string]$Target = "E5E1D9"
)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($In)
if ($To -lt 0) { if ($Mode -eq "row") { $To = $bmp.Width - 1 } else { $To = $bmp.Height - 1 } }
$runs = @(); $inRun = $false; $start = 0
for ($i = $From; $i -le $To; $i++) {
    $c = if ($Mode -eq "col") { $bmp.GetPixel($Pos, $i) } else { $bmp.GetPixel($i, $Pos) }
    $s = "{0:X2}{1:X2}{2:X2}" -f $c.R, $c.G, $c.B
    $hit = $s -eq $Target
    if ($hit -and -not $inRun) { $inRun = $true; $start = $i }
    elseif (-not $hit -and $inRun) { $inRun = $false; $runs += ("{0}-{1}" -f $start, ($i-1)) }
}
if ($inRun) { $runs += ("{0}-{1}" -f $start, $To) }
Write-Output ("hits of #$Target in {0} {1}: {2}" -f $Mode, $Pos, ($runs -join ", "))
$bmp.Dispose()
