param(
    [string]$Script = "",       # e.g. "r 886 681; r 756 717; d 700 600 760 640"
    [string]$Out = "E:\Stage Micing Scene\tools\_p3_shot.png"
)
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Inp {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
}
'@
try { [Inp]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
# make sure the window is really on top and active, otherwise the synthetic
# mouse events land on whatever window covers it
[Inp]::ShowWindow($h, 9) | Out-Null
[Inp]::SetWindowPos($h, [IntPtr](-1), 0, 0, 0, 0, 0x0001 -bor 0x0002 -bor 0x0040) | Out-Null
[Inp]::BringWindowToTop($h) | Out-Null
[Inp]::SetForegroundWindow($h) | Out-Null
[Inp]::SetWindowPos($h, [IntPtr](-2), 0, 0, 0, 0, 0x0001 -bor 0x0002 -bor 0x0040) | Out-Null
Start-Sleep -Milliseconds 500
if ([Inp]::GetForegroundWindow() -ne $h) {
    Write-Output "warning: the app window is not the foreground window"
}
$origin = New-Object Inp+POINT
[Inp]::ClientToScreen($h, [ref]$origin) | Out-Null

function MoveTo([int]$x, [int]$y) {
    [Inp]::SetCursorPos($origin.X + $x, $origin.Y + $y) | Out-Null
    Start-Sleep -Milliseconds 90
}

foreach ($step in $Script.Split(';')) {
    $f = $step.Trim() -split '\s+'
    if ($f.Count -lt 3) { continue }
    switch ($f[0]) {
        'r' {
            MoveTo ([int]$f[1]) ([int]$f[2])
            [Inp]::mouse_event(8, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 80
            [Inp]::mouse_event(16, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 400
        }
        'l' {
            MoveTo ([int]$f[1]) ([int]$f[2])
            [Inp]::mouse_event(2, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 60
            [Inp]::mouse_event(4, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 400
        }
        'm' { MoveTo ([int]$f[1]) ([int]$f[2]) }
        'w' {
            MoveTo ([int]$f[1]) ([int]$f[2])
            $delta = [int]$f[3]
            # mouse_event takes a DWORD: a negative delta (wheel up) must be
            # reinterpreted, a plain [uint32] cast throws
            $d32 = if ($delta -lt 0) { [uint32]($delta + 4294967296) } else { [uint32]$delta }
            [Inp]::mouse_event(0x0800, 0, 0, $d32, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 350
        }
        'd' {
            $x1 = [int]$f[1]; $y1 = [int]$f[2]; $x2 = [int]$f[3]; $y2 = [int]$f[4]
            MoveTo $x1 $y1
            [Inp]::mouse_event(2, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 120
            for ($i = 1; $i -le 14; $i++) {
                [Inp]::SetCursorPos($origin.X + [int]($x1 + ($x2 - $x1) * $i / 14),
                                    $origin.Y + [int]($y1 + ($y2 - $y1) * $i / 14)) | Out-Null
                Start-Sleep -Milliseconds 35
            }
            [Inp]::mouse_event(4, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 400
        }
    }
}
Start-Sleep -Milliseconds 400
$wr = New-Object Inp+RECT
[Inp]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L
$ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[Inp]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out"
