param(
    [int[]]$Clicks = @(),   # flat list: x1,y1,x2,y2,... in CLIENT coordinates
    [string]$Out = "E:\Stage Micing Scene\tools\_shot_click.png",
    [switch]$Start
)

Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class Clicker {
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, IntPtr e);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint f);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
}
'@
try { [Clicker]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null } catch {}

if ($Start) {
    Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Process -FilePath "E:\Stage Micing Scene\build\Release\StageMicing.exe"
    Start-Sleep -Seconds 2
}
$proc = Get-Process StageMicing -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $proc) { Write-Output "no process"; exit 1 }
$h = $proc.MainWindowHandle
[Clicker]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 400

$origin = New-Object Clicker+POINT
[Clicker]::ClientToScreen($h, [ref]$origin) | Out-Null

for ($i = 0; $i + 1 -lt $Clicks.Count; $i += 2) {
    $x = $origin.X + $Clicks[$i]
    $y = $origin.Y + $Clicks[$i + 1]
    [Clicker]::SetCursorPos($x, $y) | Out-Null
    Start-Sleep -Milliseconds 120
    [Clicker]::mouse_event(2, 0, 0, 0, [IntPtr]::Zero)  # left down
    Start-Sleep -Milliseconds 60
    [Clicker]::mouse_event(4, 0, 0, 0, [IntPtr]::Zero)  # left up
    Start-Sleep -Milliseconds 450
}

$wr = New-Object Clicker+RECT
[Clicker]::GetWindowRect($h, [ref]$wr) | Out-Null
$w = $wr.R - $wr.L
$ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$dc = $g.GetHdc()
[Clicker]::PrintWindow($h, $dc, 2) | Out-Null
$g.ReleaseHdc($dc)
$g.Dispose()
$bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()
Write-Output "saved $Out ${w}x${ht}"
