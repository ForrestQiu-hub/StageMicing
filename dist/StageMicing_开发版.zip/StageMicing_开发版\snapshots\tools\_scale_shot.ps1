param(
    [string]$Fixture,
    [int]$Zoom = 1,
    [string]$Tag,
    [string]$Layer = '1',
    [string]$Mode = 'ab',
    [int]$Mic = 1
)
$exe = 'E:\Stage Micing Scene\StageMicing.exe'
$shot = 'E:\Stage Micing Scene\tools\shot.ps1'
$png = "E:\Stage Micing Scene\tools\_scale_$Tag.png"
$dump = "E:\Stage Micing Scene\tools\_scale_$Tag.txt"
Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300
Start-Process -FilePath $exe -ArgumentList '--layer', $Layer, '--open', ('"' + $Fixture + '"'), '--zoom', $Zoom
Start-Sleep -Seconds 2
& powershell -ExecutionPolicy Bypass -File $shot -Out $png | Out-Null
Get-Process StageMicing -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300
Start-Process -FilePath $exe -ArgumentList '--layer', $Layer, '--open', ('"' + $Fixture + '"'), '--zoom', $Zoom, '--dump', ('"' + $dump + '"') -Wait
& 'C:\Users\Lenovo\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe' 'E:\Stage Micing Scene\tmp_tests\measure_scale.py' $png $dump $Mic $Mode
