#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Measure stage rect / grid spacing / text columns in a StageMicing PNG export."""
import sys
from PIL import Image
import numpy as np


def main(path):
    im = Image.open(path).convert("RGB")
    a = np.asarray(im)
    h, w, _ = a.shape
    print(f"file={path} size={w}x{h}")

    # stage fill colour: find the most common colour in a central-ish band
    flat = a.reshape(-1, 3)
    packed = (flat[:, 0].astype(np.int32) << 16) | (flat[:, 1].astype(np.int32) << 8) | flat[:, 2]
    vals, counts = np.unique(packed, return_counts=True)
    order = np.argsort(-counts)
    print("top colours:", ["#%06X %d" % (int(vals[o]), counts[o]) for o in order[:4]])

    # the LARGEST-area colour is usually the stage; the outermost colour the page bg
    c0 = int(vals[order[0]])
    rgb = np.array([(c0 >> 16) & 255, (c0 >> 8) & 255, c0 & 255])
    m = np.all(a == rgb[None, None, :], axis=2)
    # column/row occupancy of that colour
    colm = m.sum(axis=0)
    rowm = m.sum(axis=1)
    print("colour #%06X column occupancy: first>50%% of h at %d, last at %d" % (
        c0, int(np.argmax(colm > h * 0.5)), int(len(colm) - 1 - np.argmax(colm[::-1] > h * 0.5))))
    cx = np.where(colm > h * 0.5)[0]
    cy = np.where(rowm > w * 0.5)[0]
    if len(cx):
        print(f"  stage-x span [{cx[0]},{cx[-1]}]")
    if len(cy):
        print(f"  stage-y span [{cy[0]},{cy[-1]}]")

    # grid lines: colour #E5E1D9 etc - detect vertical lines on the offstage band
    # use a horizontal scanline near the top (outside the stage)
    for y in (60, 100, 200):
        row = a[y]
        lum = row.astype(np.int32).sum(axis=1) / 3.0
        dark = np.where(lum < 235)[0]
        # group consecutive
        groups = []
        if len(dark):
            s = dark[0]
            p = dark[0]
            for v in dark[1:]:
                if v > p + 1:
                    groups.append((s, p))
                    s = v
                p = v
            groups.append((s, p))
        print(f"  row y={y}: {len(groups)} vertical line groups, first={groups[:6]}")
        if len(groups) > 3:
            xs = [(g[0] + g[1]) / 2 for g in groups]
            d = np.diff(xs)
            print(f"    spacing median={np.median(d):.2f} min={d.min():.1f} max={d.max():.1f}")

    # text ink: darker than 190
    lum = a.astype(np.int32).sum(axis=2) / 3.0
    dark = lum < 190
    xs = np.where(dark.any(axis=0))[0]
    ys = np.where(dark.any(axis=1))[0]
    print(f"dark<190 bbox x=[{xs[0]},{xs[-1]}] y=[{ys[0]},{ys[-1]}] margins L={xs[0]} R={w-1-xs[-1]} T={ys[0]} B={h-1-ys[-1]}")
    print(f"  ink in border strips: L{int(dark[:,:40].sum())} R{int(dark[:,w-40:].sum())} T{int(dark[:40,:].sum())} B{int(dark[h-40:,:].sum())}")
    colink = dark.sum(axis=0)
    print("  ink cols in the right 300px (per 20px):", [int(colink[i:i+20].sum()) for i in range(w-300, w, 20)])


if __name__ == "__main__":
    main(sys.argv[1])
