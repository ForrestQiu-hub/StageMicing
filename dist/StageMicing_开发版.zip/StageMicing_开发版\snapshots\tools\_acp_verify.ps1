param(
    [string]$Out = "E:\Stage Micing Scene\tools\_acp_top.png",
    [int]$MoveX = -1,
    [int]$MoveY = -1,
    [string]$Click = "",     # "x,y" client physical coords, or "" for none
    [int]$CropH = 96,
    [switch]$NoCrop
)
# TEMPORARY verification helper (delete after use).  Drives the running app with
# posted mouse messages and grabs a crop of the top bar.
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class Vf {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  public delegate bool EnumProc(IntPtr h, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lp);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassNameW(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr PostMessageW(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint f);
  [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr c);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int x, y; }
}
'@
Add-Type -AssemblyName System.Drawing
[Vf]::SetProcessDpiAwarenessContext([IntPtr](-4)) | Out-Null

# FindWindowW misbehaves in this shell, so enumerate by class + owning process.
$ids = @(Get-Process StageMicing -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
$script:h = [IntPtr]::Zero
$cb = [Vf+EnumProc]{
    param($w, $lp)
    $pid2 = [uint32]0
    [Vf]::GetWindowThreadProcessId($w, [ref]$pid2) | Out-Null
    if ($ids -notcontains $pid2) { return $true }
    $sb = New-Object System.Text.StringBuilder 256
    [Vf]::GetClassNameW($w, $sb, 256) | Out-Null
    if ($sb.ToString() -ne "StageMicingWnd") { return $true }
    $rc = New-Object Vf+RECT
    [Vf]::GetClientRect($w, [ref]$rc) | Out-Null
    if ($rc.R -gt 200) { $script:h = $w; return $false }
    return $true
}
[Vf]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null
$h = $script:h
if ($h -eq [IntPtr]::Zero) { Write-Output "no window"; exit 1 }
$cr = New-Object Vf+RECT; [Vf]::GetClientRect($h, [ref]$cr) | Out-Null
$wr = New-Object Vf+RECT; [Vf]::GetWindowRect($h, [ref]$wr) | Out-Null
$co = New-Object Vf+POINT; [Vf]::ClientToScreen($h, [ref]$co) | Out-Null

function MakeLP([int]$x, [int]$y) { return [IntPtr](($y -shl 16) -bor ($x -band 0xFFFF)) }

if ($MoveX -ge 0) {
    [Vf]::PostMessageW($h, 0x0200, [IntPtr]::Zero, (MakeLP $MoveX $MoveY)) | Out-Null
    Start-Sleep -Milliseconds 250
}
if ($Click -ne "") {
    $parts = $Click.Split(",")
    $cx = [int]$parts[0]; $cy = [int]$parts[1]
    [Vf]::PostMessageW($h, 0x0200, [IntPtr]::Zero, (MakeLP $cx $cy)) | Out-Null
    Start-Sleep -Milliseconds 120
    [Vf]::PostMessageW($h, 0x0201, [IntPtr]1, (MakeLP $cx $cy)) | Out-Null
    Start-Sleep -Milliseconds 120
    [Vf]::PostMessageW($h, 0x0202, [IntPtr]::Zero, (MakeLP $cx $cy)) | Out-Null
    Start-Sleep -Milliseconds 350
}

# grab the whole window, then crop the client top bar
$w = $wr.R - $wr.L; $ht = $wr.B - $wr.T
$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$hdc = $g.GetHdc()
[Vf]::PrintWindow($h, $hdc, 2) | Out-Null
$g.ReleaseHdc($hdc); $g.Dispose()

$ox = $co.x - $wr.L; $oy = $co.y - $wr.T
if ($NoCrop) {
    $bmp.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
    Write-Output "saved $Out full ${w}x${ht}"
} else {
    $cw = 1825; $chh = $CropH
    if ($cw -gt $cr.R) { $cw = $cr.R }
    if ($oy + $chh -gt $ht) { $chh = $ht - $oy }
    $crop = New-Object System.Drawing.Bitmap $cw, $chh
    $gc = [System.Drawing.Graphics]::FromImage($crop)
    $gc.DrawImage($bmp, (New-Object System.Drawing.Rectangle 0, 0, $cw, $chh), $ox, $oy, $cw, $chh, [System.Drawing.GraphicsUnit]::Pixel)
    $gc.Dispose()
    $crop.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
    Write-Output "saved $Out crop ${cw}x${chh} client=${cr.R}x${cr.B} dpi=$([Vf]::GetDpiForWindow($h))"
    $crop.Dispose()
}
$bmp.Dispose()
